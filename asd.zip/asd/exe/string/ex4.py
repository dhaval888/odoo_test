#  Write a Python program to change a given string to a newly string where the first and last chars have been exchanged.
# Sample String : 'xyz'
# Expected Result : 'zyx'

st = "xyzabc"
print(st[-1]+st[1:-1]+st[0])