for i in range(10, 0, -2):
    for j in range(i,10,2):
            print("  ", end=" ")
    for j in range(2, i+1):
        if j % 2 == 0:
            print("",j, end=" ")

    print("")


# 2 4 6 8 10
#   2 4 6 8
#     2 4 6
#       2 4
# 		  2
