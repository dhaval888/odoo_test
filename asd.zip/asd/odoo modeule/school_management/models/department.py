from odoo import api, fields, models


class Department(models.Model):
    _name = "department"
    _description = "Department"
    _rec_name = 'department_name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    department_name = fields.Selection(
        selection=[
            ('science', 'Science'),
            ('commerce', 'Commerce'),
            ('arts', 'Arts'),
        ]
    )

    # student_ids = fields.One2many('student', 'department_id')

    student_ids = fields.Many2many('student', 'student_department_rel', 'student', 'department', string="Student Name")
    teacher_ids = fields.Many2many('teacher', 'teacher_department_rel', 'teacher', 'department', string="Teacher Name")

    # teacher_ids = fields.One2many('teacher', 'department_id')
