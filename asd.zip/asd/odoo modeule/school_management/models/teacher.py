from odoo import api, fields, models


class Teacher(models.Model):
    _name = "teacher"
    _description = "Teacher"
    _rec_name = 'name'
    # _order = 'name desc, age'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Teacher Name', copy=False, help='Teacher Name')
    age = fields.Integer(string='Age', copy=False, help='Teacher Age')
    join_date = fields.Date(string="joining Date", copy=False, help='Teacher Date of joining', tracking=True)
    gender = fields.Selection(
        selection=[
            ('male', 'Male'),
            ('female', 'Female'),
        ])
    subject = fields.Selection(
        selection=[
            ('math', 'Math'),
            ('hindi', 'Hindi'),
            ('science', 'Science'),
            ('gujarati', 'Gujarati'),
        ],
        string="Subject", help='Teacher Subject'
    )
    state = fields.Selection(
        selection=[
            ('gujarat', 'Gujarat'),
            ('maharasthra', 'Maharasthra'),
            ('rajasthan', 'Rajasthan'),
            ('punjab', 'Punjab'),
        ], help='State',
    )
    city = fields.Char(compute="_compute_city", store=True)
    salary = fields.Float()

    # student_ids = fields.One2many('student', 'teacher_id')

    student_ids = fields.Many2many('student', 'student_teacher_rel', 'student_id', 'teacher_id', string="Student Name")
    department_id = fields.Many2one(comodel_name='department', string='Department Name')

    @api.onchange('subject')
    def onchange_subject(self):
        for record in self:
            if record.subject == 'math':
                record.name = 'neha'
            if record.subject == 'hindi':
                record.name = 'jack'
            if record.subject == 'science':
                record.name = 'jeel'
            if record.subject == 'gujarati':
                record.name = 'fenil'

    @api.depends('state')
    def _compute_city(self):
        for rec in self:
            if rec.state == 'gujarat':
                rec.city = 'Rajkot'
            if rec.state == 'maharasthra':
                rec.city = 'mumbai'
            if rec.state == 'rajasthan':
                rec.city = 'jaypur'
            if rec.state == 'punjab':
                rec.city = 'gudgeon'

    @api.model_create_multi
    def create(self, vals):
        for vals_rec in vals:
            vals_rec.update({'salary': vals_rec.get('salary', 0.0) + 1000})
        res = super().create(vals)
        for rec in res:
            if rec.gender == 'male':
                rec.name = 'Mr.' + (rec.name).capitalize()
            elif rec.gender == 'female':
                rec.name = 'Mrs.' + (rec.name).capitalize()
            else:
                if rec.name == rec.name:
                    rec.name = (rec.name).capitalize()
            if len(rec.department_id.teacher_ids) >= 3:
                rec.salary += 20000
        return res

    def write(self, vals):
        if not vals:
            vals.update({'salary': vals.get('salary', 0.0) + 5000})
        if vals.get('department_id'):
            department_id = self.env['department'].browse(vals.get('department_id'))
            if len(department_id.student_ids) >= 3:
                vals.update({'salary': vals.get('salary', 0.0) + 20000})
        res = super(Teacher, self).write(vals)
        context = self.env.context.copy()
        if not context.get('is_updated'):
            for rec in self:
                if len(rec.department_id.student_ids) >= 3:
                    context.update({'is_updated': True})
                    rec.with_context(context).salary += 20000
        return res

    # @api.depends('dob')
    # def _compute_age(self):
    #     today = date.today()
    #
    #     for record in self:
    #         if record.dob:
    #             record.age = today.year - record.dob.year
    #         else:
    #             record.age = 0
