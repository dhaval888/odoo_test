import string
from odoo import api, fields, models
import random


class Customer(models.Model):
    _name = 'customer'
    # partner_ids = fields.Many2many('res.partner.extended', string='Customers')
    # product_ids = fields.Many2many('product', string="Product")
    # user_id = fields.Many2one('res.partner', string="User Name")
    # product_detail_id = fields.Many2one('product.template', string="Product Name")

    Select_item = fields.Selection(
        selection=[
            ('customer', 'Customer'),
            ('product', 'Product'),
        ], string='Select', help="Select Product Or Customer"
    )

    model_id = fields.Many2one(comodel_name='ir.model', compute="_compute_model", store=True)

    # @api.depends('Select_item')
    # def _compute_model(self):
    #     for rec in self:
    #         if rec.Select_item == 'customer':
    #             rec.model_id = self.env['ir.model'].search([('name', '=', 'Contact')]).id
    #
    #         elif rec.Select_item == 'product':
    #             rec.model_id = self.env['ir.model'].search([('name', '=', 'Product Variant')]).id

    @api.onchange('Select_item')
    def onchange_state(self):
        for rec in self:
            if rec.Select_item == 'customer':
                rec.model_id = self.env['ir.model'].search([('name', '=', 'Contact')]).id
            elif rec.Select_item == 'product':
                rec.model_id = self.env['ir.model'].search([('name', '=', 'Product Variant')]).id

    field_ids = fields.Many2many('ir.model.fields', string="Fields", domain="[('model_id', '=', model_id)]")

    user_id = fields.Many2one('product.product', string="User Name")

    customer_id = fields.Many2one('res.partner', string="User Name")

    count = fields.Char(string='Count')

    def create_demo_customer(self):

        for res in self:
            rec = res.field_ids
            rec_count = res.count
            customer_id = res.customer_id

            for i in range(int(rec_count)):
                customer_dict = {'name': '', 'city': '', 'vat': '', 'phone': '', 'mobile': '', 'email': '',
                                 'website': ''}

                for temp in rec:
                    if temp.name.lower() == "company_name" or temp.name.lower() == "name":
                        name_len = random.randrange(3, 10)
                        customer_dict['name'] = ''.join(random.choices(string.ascii_letters, k=name_len))

                    elif temp.name.lower() == "city":
                        city_len = random.randrange(6, 12)
                        customer_dict['city'] = ''.join(random.choices(string.ascii_letters, k=city_len))

                    elif temp.name.lower() == "vat":
                        customer_dict['vat'] = "".join(random.choices(string.digits, k=8))

                    elif temp.name.lower() == "email":
                        name_len = random.randrange(3, 10)
                        e_name = ''.join(random.choices(string.ascii_letters, k=name_len))
                        customer_dict['email'] = e_name + '@gmail.com'

                    elif temp.name.lower() == "phone":
                        customer_dict['phone'] = "".join(random.choices(string.digits, k=10))

                    elif temp.name.lower() == "mobile":
                        customer_dict['mobile'] = "".join(random.choices(string.digits, k=12))

                    elif temp.name.lower() == "website":
                        name_len = random.randrange(3, 10)
                        web = ''.join(random.choices(string.ascii_letters, k=name_len))
                        customer_dict['website'] = 'www.' + web + '.com'

                if customer_dict['name'] != "":
                    customer_id.create(customer_dict)

    def create_demo_product(self):
        for res in self:
            rec = res.field_ids
            rec_count = res.count
            customer_id = res.user_id

            for i in range(int(rec_count)):

                product_dict = {'name': "", 'detailed_type': "", 'lst_price': "", 'standard_price': "",
                                'default_code': "", 'barcode': ""}

                for temp in rec:
                    if temp.name.lower() == "name":
                        name_len = random.randrange(3, 10)
                        product_dict['name'] = ''.join(random.choices(string.ascii_letters, k=name_len))

                    elif temp.name.lower() == "detailed_type":
                        product_type = ('consu', 'product', 'service')
                        product_dict['detailed_type'] = "".join(random.choices(product_type))

                    elif temp.name.lower() == "list_price":
                        product_dict['lst_price'] = "".join(random.choices(string.digits, k=3))

                    elif temp.name.lower() == "standard_price":
                        product_dict['standard_price'] = "".join(random.choices(string.digits, k=3))

                    elif temp.name.lower() == "default_code":
                        address_len = random.randrange(4, 7)
                        product_dict['default_code'] = ''.join(
                            random.choices(string.ascii_letters + string.digits, k=address_len))

                    elif temp.name.lower() == "barcode":
                        barcode_len = random.randrange(4, 7)
                        product_dict['barcode'] = "".join(
                            random.choices(string.ascii_letters + string.digits, k=barcode_len))

                if product_dict['name'] != "":
                    customer_id.create(product_dict)

    # @api.model_create_multi
    # def create(self, vals):
    #
    #     res = super(Customer, self).create(vals)
    #     rec = res.partner_ids
    #     rec_count = res.count
    #
    #     customer_id = res.user_id
    #
    #     for i in range(int(rec_count)):
    #         random_name = ""
    #         random_email = ""
    #         random_phone = ""
    #         random_mobile = ""
    #         random_address = ""
    #         for temp in rec:
    #             if temp.name.lower() == "name":
    #                 name_len = random.randrange(3, 10)
    #                 random_name = ''.join(random.choices(string.ascii_letters, k=name_len))
    #             elif temp.name.lower() == "email":
    #                 name_len = random.randrange(3, 10)
    #                 random_name = ''.join(random.choices(string.ascii_letters, k=name_len))
    #                 random_email = random_name + '@gmail.com'
    #
    #             elif temp.name.lower() == "phone":
    #                 random_phone = "".join(random.choices(string.digits, k=10))
    #
    #             elif temp.name.lower() == "mobile":
    #                 random_mobile = "".join(random.choices(string.digits, k=12))
    #
    #             elif temp.name.lower() == "address":
    #                 address_len = random.randrange(6, 20)
    #                 random_address = ''.join(random.choices(string.ascii_letters + string.digits, k=address_len))
    #
    #         if random_name != "" or random_email != "" or random_phone != "" or random_mobile != "" or random_address != "":
    #             customer_id.create(
    #                 {'name': random_name, 'phone': random_phone, 'mobile': random_mobile, 'email': random_email, 'contact_address': random_address})
    #
    #     return res
