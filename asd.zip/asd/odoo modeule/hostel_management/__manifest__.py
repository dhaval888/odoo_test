{
    'name': 'Hostel Management',
    'version': '16.1',
    'depends': ['mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/admin_view.xml',
        'views/student_views.xml',
    ]
}