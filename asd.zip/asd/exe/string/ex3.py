# Write a Python program to get a string from a given string where all occurrences of its first char have been changed to '$', except the first char itself.
# Sample String : 'test'
# Expected Result : 'tes$'

st = "test"

x = st[0:1]
y = st[1:]
print(x + y.replace(x,"$"))
