# import itertools
#
#
# from openpyxl import load_workbook
#
# existing_file = 'stock.xlsx'
# new_data1 = [['ID', 'NAME', 'TYPE', 'PAN']]
#
# for i in new_data1:
#     if i[0] in 'ID':
#         print("hello")
#         print(new_data1)
#     else:
#         print("sorry")
# wb = load_workbook(existing_file)
#
# ws = wb.active
# for row in new_data1:
#     ws.append(row)
# wb.save(existing_file)
#
#
# class customer_master:
#     customer = {}
#     c_id = itertools.count(1)
#     c_name = str()
#     c_type = []
#     c_pan = int()
#
#     def cust_data(self):
#
#         cust_count = next(self.c_id)
#         print('customer id :', cust_count)
#
#         self.c_name = input('customer name :')
#         cust_type = input('enter customer type : ')
#         if cust_type == 'customer' or cust_type == 'vendor' or cust_type == 'customer,vendor':
#             self.c_type = cust_type
#
#             self.c_pan = input('enter pan no:')
#             # for x in self.customer.values():
#             #     if self.c_pan in x.values():
#             #         print("pan no is already exist")
#             #         return customer_master()
#             #         # self.customer.pop()
#
#         else:
#             print("only two values are supported \"customer\" and \"vendor\"")
#             return customer_master()
#
#         new_data = [[cust_count, self.c_name, self.c_type, self.c_pan]]
#
#         wb = load_workbook(existing_file)
#         ws = wb.active
#         for row in new_data:
#             ws.append(row)
#         wb.save(existing_file)
#
#         if cust_count == new_data:
#             print("this id is already exist")
#             return customer_master()
#         if self.c_pan in new_data:
#             print("pan number is already exist")
#             return customer_master
#
#
# class product_master(customer_master):
#     product = {}
#     p_id = itertools.count(1)
#     p_name = str()
#     p_incoming = float()
#     p_outgoing = float()
#     p_onhand = 0.0
#
#     def prod_data(self):
#         prod_count = next(self.p_id)
#         print('customer id :', prod_count)
#
#         self.p_name = input('product name :')
#         for x in self.product.values():
#             if self.p_name in x.values():
#                 print("product name is already exist")
#                 return product_master()
#
#         self.p_incoming = float(input('enter a product incoming : '))
#         self.p_outgoing = float(input('enter a product outgoing : '))
#
#         if self.p_incoming >= self.p_outgoing:
#             self.p_onhand = self.p_incoming - self.p_outgoing
#         else:
#             print("stock is not available")
#             return product_master()
#
#         new_data = [[prod_count, self.p_name, self.p_incoming, self.p_outgoing, self.p_onhand]]
#         wb = load_workbook(existing_file)
#         ws = wb.active
#         for row in new_data:
#             ws.append(row)
#         wb.save(existing_file)
#
#
# class stock_move(product_master, customer_master):
#     stock = {}
#     stock_id = itertools.count(1)
#     product_id = int()
#     cust_id = int()
#     stock_qty = 0
#     stock_type = str()
#     state = str()
#
#     def stock_data(self):
#
#         stock_count = next(self.stock_id)
#         print('stock_id :', stock_count)
#
#         self.cust_id = int(input("enter customer id : "))
#         if self.cust_id not in super().customer.keys():
#             self.product_id = int(input('enter product id : '))
#             if self.product_id not in super().product.keys():
#                 self.stock_qty = float(input('enter qty : '))
#                 if self.stock_qty <= 0:
#                     print('please enter proper qty !..')
#                     return stock_move().stock_data()
#
#                 type = str(input('in or out :'))
#                 if type in 'in':
#                     incoming = self.stock_qty
#                     onhand = self.stock_qty
#                     self.stock_type = "incoming"
#
#                 elif type in 'out':
#                     if self.stock_qty < 0:
#                         print('stock are not available.\n')
#                         return stock_move().stock_data()
#                     outgoing = self.stock_qty
#                     # onhand = super().product[self.product_id].get("onhand") - self.stock_qty
#                     self.stock_type = "outgoing"
#                 else:
#                     print("enter valid option")
#
#             else:
#                 print(self.product_id, 'id is not exist :')
#                 return stock_move().stock_data()
#         else:
#             print(self.cust_id, ' id is not exist')
#             return stock_move().stock_data()
#
#         new_data = [[stock_count, self.cust_id, self.product_id, self.stock_qty, self.stock_type]]
#         x = load_workbook(existing_file)
#         w = x.active
#         for ROW in new_data:
#             w.append(ROW)
#         x.save(existing_file)
#
#
# while True:
#     print("1.customer")
#     print("2.product")
#     print("3.stock")
#     print("4.exit")
#     n = int(input('Choice a number : '))
#
#     if n == 1:
#         customer_master().cust_data()
#     elif n == 2:
#         product_master().prod_data()
#     elif n == 3:
#         stock_move().stock_data()
#     elif n == 4:
#         break
#
from openpyxl import load_workbook

xpath = 'stock_management.xlsx'
ws = load_workbook(xpath)
if "cust" and "prod" and "stock" not in ws.sheetnames:
    ws.create_sheet("cust")
    ws["cust"].append(("ID", "NAME", "TYPE", "PAN"))
    ws.create_sheet("prod")
    ws["prod"].append(("ID", "NAME", "INCOMING", "OUTGOING", "ONHAND"))
    ws.create_sheet("stock")
    ws["stock"].append(("ID", "CUST_ID", "PROD_ID", "QTY", "TYPE"))
    ws.save(xpath)
list1 = []
list2 = []
list3 = []


def input_id(message):
    while True:
        try:
            return input(message)
        except ValueError:
            print("Please enter an integer")
def check_duplicate(data_list, index, value):
    return any(i[index] == value for i in data_list)


class Customer:
    cid = {}
    cname = {}
    ctype1 = {}
    cpan = {}

    @staticmethod
    def customer():
        sheet1 = ws["cust"]
        cid = input("Enter Customer Id:")
        for k in sheet1:
            if cid == str(k[0].value):
                print("Customer already exists")
                return Customer.customer()

        cname = input("Enter Customer Name: ")
        type = int(input("1.customer\n2.vendor\n3.customer,vendor\nchoice option : "))
        if type == 1:
            ctype1 = "customer"
        elif type == 2:
            ctype1 = "vendor"
        elif type == 3:
            ctype1 = "customer,vendor"
        else:
            print("enter a valid option.\n")
            return Customer.customer()

        cpan = str(input("Enter Customer Pan: "))
        for k in sheet1:
            if cpan == str(k[3].value):
                print("pan number already exist\n")
                return Customer.customer()

        sheet1.append((cid, cname, ctype1, cpan))
        ws.save(xpath)
        main()


class Product(Customer):
    pid = {}
    pname = {}
    incoming = {}
    outgoing = {}
    onhand = {}

    @staticmethod
    def product():
        sheet2 = ws["prod"]

        pid = input("Enter Product Id: ")
        for k in sheet2:
            if pid == k[0].value:
                print("Product id already exists")
                return Product.product()

        pname = input("Enter Product Name: ")
        for k in sheet2:
            if pname == k[1].value:
                print("product is already exists")
                return Product.product()

        incoming = int(input("Enter Incoming: "))
        outgoing = int(input("Enter Outgoing: "))
        if outgoing > incoming:
            print("Stock is not available")
            return Product.product()

        onhand = incoming - outgoing
        sheet2.append((pid, pname, incoming, outgoing, onhand))
        ws.save(xpath)
        main()


class Stock(Product):
    sid = {}
    spid = {}
    scid = {}
    sqty = 0
    stype2 = {}

    @staticmethod
    def stock():
        sheet3 = ws["stock"]
        sheet2 = ws["prod"]
        sheet1 = ws["cust"]

        sid = input("Enter Stock Id: ")
        for k in sheet3:
            if sid == k[0].value:
                print("Stock id already exists")
                return Stock.stock()

        spid = input("Enter Product Id:")
        if not check_duplicate(list2, 0, spid) and not check_duplicate(ws["prod"].iter_rows(values_only=True), 0, spid):
            print("This product does not exist.")
            return Stock.stock()
        scid = input("Enter Customer Id:")
        if not check_duplicate(list1, 0, scid) and not check_duplicate(ws["cust"].iter_rows(values_only=True), 0, scid):
            print("Customer does not exist.")
            return Stock.stock()

        sqty = int(input("Enter qty:"))
        stype2 = int(input("1.incoming\n2.outgoing\n choice a type: "))

        if stype2 == 1:
            for k in sheet2:
                if spid == k[0].value:
                    k[2].value += sqty
                    k[4].value += sqty
            stype2 = "incoming"
            sheet3.append((sid, spid, scid, sqty, stype2))

        elif stype2 == 2:
            for i in sheet2:
                if spid == i[0].value:
                    if sqty > i[4].value:
                        print("stock is not available")
                        print("stock available quantity ", i[4].value)
                        return Stock.stock()
                    else:
                        i[3].value += sqty
                        i[4].value -= sqty
            stype2 = "outgoing"
            sheet3.append((sid, spid, scid, sqty, stype2))
        ws.save(xpath)
        main()


def main():
    print("1.customer")
    print("2.product")
    print("3.stock")
    print("4.exit")
    n = int(input("choice a number : "))

    if n == 4:
        exit()
    if n == 1:
        Stock.customer()

    elif n == 2:
        Stock.product()

    elif n == 3:
        Stock.stock()
    return main()


if __name__ == "__main__":
    main()
