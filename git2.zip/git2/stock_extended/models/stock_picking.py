from odoo import api, fields, models
from odoo.odoo.exceptions import UserError


class SaleOrder(models.Model):
    _inherit = "sale.order"
    _description = "Sale Order"

    def _create_invoices(self, grouped=False, final=False, date=None):
        res = super(SaleOrder, self)._create_invoices()
        return res


class StockPicking(SaleOrder, models.Model):
    _inherit = "stock.picking"
    _description = "Stock Picking"

    def button_validate(self):
        res = super(StockPicking, self).button_validate()
        return res

    # @api.onchange('move_ids_without_package')
    # def onchange_sale_id(self):
    #     for records in self:
    #         if records.move_ids_without_package:
    #             for moves in records.move_ids_without_package:
    #                 sale_ids = self.env['stock.picking'].search([('sale_id', '=', self.sale_id.id)])
    #
    #                 if moves.product_id.invoice_policy == "delivery":
    #                     if moves.quantity_done > 0 and moves.product_uom_qty != moves.quantity_done and len(
    #                             sale_ids) == 1:
    #                         self._origin.button_validate()
    #                         if moves.quantity_done <= moves.product_uom_qty:
    #                             backorder_confirmation = self.env['stock.backorder.confirmation'].create(
    #                                 {'pick_ids': records.ids, 'show_transfers': False})
    #
    #                             backorder_confirmation_line = self.env['stock.backorder.confirmation.line'].create({
    #                                 'backorder_confirmation_id': backorder_confirmation.id,
    #                                 'picking_id': backorder_confirmation.pick_ids.id,
    #                                 'to_backorder': True})
    #                             self._origin.button_validate()
    #                             backorder_confirmation.with_context(button_validate_picking_ids=self.ids).process()
    #
    #                     elif len(sale_ids) > 1 and moves.product_uom_qty != moves.quantity_done:
    #                         self._origin.button_validate()
    #
    #                         backorder_confirmation = self.env['stock.backorder.confirmation'].create(
    #                             {'pick_ids': records.ids, 'show_transfers': False})
    #
    #                         backorder_confirmation_line = self.env['stock.backorder.confirmation.line'].create({
    #                             'backorder_confirmation_id': backorder_confirmation.id,
    #                             'picking_id': backorder_confirmation.pick_ids.id, 'to_backorder': True})
    #                         backorder_confirmation.with_context(button_validate_picking_ids=self.ids).process()
    #
    #                     elif moves.product_uom_qty == moves.quantity_done:
    #                         self._origin.button_validate()
