# a = 10
# b = 20
# c = "test"
# print(a,c,b)

# x = "dhd"  # x is type of int
# x = "hello" #  x is type of string
# print(x)

# str1 = str(3) # this specify of datatype this called casting
# print(str1)
# y = float(3) # this specify of datatype this called casting
# print(y)
#
# # get the type of data stored
# z = 20
# s = int("45")
# str2 = str("hello")
# print(type(z))
# print(type(s))
# print(type(str2))
# print(z+s)
# # string in use the single and double quotes
# str3 = 'this is single quetes srting'
# str3 = "this is doube"
#
# print(str3)

# case sensitive
# A = 20
# a=A = "this small letter"
# print(a,a)
#
# #
# # how many type of variable declaration
# myvar = "name1"
# _myvar = "name2"
# _my_var = "name3"
# Myvar = "name4"
# MyVar = "name5"
# myvar2 = "name6"
# MYVAR = "name7"
# print(myvar)
# print(_myvar)
# print(_my_var)
# print(Myvar)
# print(MyVar)
# print(myvar2)
# print(MYVAR)
#
# #camelCaseVariable
# myName = "name8"
# print(myName)
# #PascalCase
# MyName = "name9"
# print(MyName)
# #Snack_case_variable
# my_name = "name10"
# print(my_name)
#
# #multi value multi variable
# x,y,z = "name","name1","name2"
# print(x)
# print(y)
# print(z)

# a=b=c="red"
# print(a,b,c)


# # unpack collaction

# name = ["test","test","test3"]
# a = b = c = name
# print(a)
# print(b)
# print(c)

# #output variable
# x = "hello python"
# print(x)
# a = "lean"
# b = "to"
# c = "python"
# print(a,b,c)
# print(a+b+c)
# a=10
# b = "python"
# print(a,b)
# #
# #global variable
#
# x = "awesome"
# def glb():
#      global x
#      x = 10;
#      print(x)
#
# glb()
# print(x)
