{
    'name': 'Sale Sale',
    'version': '16.1',
    'data': [
        'security/ir.model.access.csv',
        'views/sale_views.xml',
    ]
}