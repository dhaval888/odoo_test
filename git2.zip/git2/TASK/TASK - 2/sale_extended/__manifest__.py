{
    'name': 'Sale Extended',
    'version': '16.1',
    'depends': ['sale_management'],
    'data': [
        'security/security_group_views.xml',
        'security/ir.model.access.csv',
    ]
}