from odoo import models, api


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    @api.onchange('move_ids_without_package')
    def onchange_sale_id(self):
        for records in self:
            for moves in records.move_ids_without_package:

                if moves.product_uom_qty == moves.quantity_done:
                    self.env['stock.move.line'].search([('picking_id', '=', self._origin.id)]).write(
                        {'qty_done': moves.quantity_done})
                    self._origin.button_validate()

                else:
                    backorder_confirmation = self.env['stock.backorder.confirmation'].create(
                        {'pick_ids': records.ids, 'show_transfers': False})

                    backorder_confirmation_line = self.env['stock.backorder.confirmation.line'].create({
                        'backorder_confirmation_id': backorder_confirmation.id,
                        'picking_id': backorder_confirmation.pick_ids.id,
                        'to_backorder': True})

                    self.env['stock.move.line'].search([('picking_id', '=', self._origin.id)]).write(
                        {'qty_done': moves.quantity_done})

                    self._origin.button_validate()
                    backorder_confirmation.with_context(button_validate_picking_ids=self.ids).process()
0
                sale_ids = self.env['sale.order'].browse(records.sale_id.id)
                self.env['sale.advance.payment.inv'].create(
                    {'sale_order_ids': sale_ids, 'company_id': sale_ids.company_id.id,
                     'advance_payment_method': 'delivered'})
                sale_ids._create_invoices()
                invoice_ids = sale_ids.mapped('invoice_ids') if sale_ids.invoice_ids else 0
                account_moves = self.env['account.move'].search([('id', 'in', invoice_ids.ids)])
                for account_move in account_moves:
                    if account_move.state == 'draft':
                        account_move.action_post()
