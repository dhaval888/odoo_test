from odoo import api, fields, models


class Admin(models.Model):
    _name = 'admin'
    _description = 'Admin'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Admin Name", help='Admin Name')
    age = fields.Char(compute="_compute_age", store=True)

    # student_ids = fields.One2many('student', 'admin_id')

    student_ids = fields.Many2many('student', 'student_admin_rel', 'student_id', 'admin_id', String="Student")

    @api.depends('name')
    def _compute_age(self):
        for rec in self:
            if rec.name == 'jack':
                rec.age = '32'
            if rec.name == 'jul':
                rec.age = '26'
            if rec.name == 'lee':
                rec.age = '23'
            if rec.name == 'den':
                rec.age = '24'

    @api.onchange('name')
    def onchange_name(self):
        for record in self:
            if record.name == 'dhaval':
                record.age = '23'
            if record.name == 'jul':
                record.age = '30'
            if record.name == 'lee':
                record.age = '26'
            if record.name == 'den':
                record.age = '20'
