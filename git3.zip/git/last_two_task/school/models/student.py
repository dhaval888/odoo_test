from odoo import api, fields, models


class Student(models.Model):
    _name = "student"
    _description = "Student"
    _rec_name = 'first_name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    first_name = fields.Char(string='First Name', help='First Name')
    last_name = fields.Char(string="Last name", help="Last Name")

    student_id = fields.Many2one(comodel_name='teacher')