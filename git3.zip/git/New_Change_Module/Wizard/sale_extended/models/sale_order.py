from odoo import api, fields, models


class SaleOrder(models.Model):
    _name = 'student'
    _rec_name = 'first_name'

    first_name = fields.Char()
    last_name = fields.Char()

