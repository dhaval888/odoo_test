# [2] Write a Python program to sum all the items in a list.
#
# Input: [10,12,20,22]
#
# Output: 64

lst = [10,12,20,22]
a = 0
for i in lst:
    a = a + i
print(a)