from odoo import api, fields, models
from odoo.exceptions import UserError


class SetuCustomer(models.Model):
    _name = 'setu.customer'
    _rec_name = "customer_name"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    customer_name = fields.Char(required=True, )
    pan_no = fields.Char(string="Pan Number", required=True, )
    purchase_count = fields.Integer(compute="_compute_sale_count")

    sale_order_count = fields.Integer(compute="_compute_sale_count")

    type = fields.Selection(
        selection=[
            ('customer', 'Customer'),
            ('vendor', 'Vendor'),
            ('customer and vendor', 'Customer & Vendor'),
        ], required=True,
    )

    @api.model_create_multi
    def create(self, vals_list):
        for rec in vals_list:
            setu_customer_ids = self.search([('pan_no', '=', rec.get('pan_no'))])
            if setu_customer_ids:
                raise UserError("Customer Pan alredy exist...")
        res = super(SetuCustomer, self).create(vals_list)
        return res

    @api.onchange('pan_no')
    def _onchange_order_type(self):
        for rec in self:
            customer_id = self.env['setu.customer'].search([('pan_no', '=', rec.pan_no)])
            if customer_id:
                raise UserError("Customer Pan alredy exist...")

    def purchase(self):
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Setu Order',
                'view_mode': 'tree,form',
                'view_type': 'form',
                'res_model': 'purchase.order',
                'domain': [('partner_id.name', '=', rec.customer_name)],
                'context': "{'create': False}"
            }

    def order(self):
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Setu Order',
                'view_mode': 'tree,form',
                'view_type': 'form',
                'res_model': 'setu.order',
                'domain': [('customer_id', '=', rec.id)],
                'context': "{'create': False}"
            }

    def _compute_sale_count(self):
        for record in self:
            record.purchase_count = self.env['purchase.order'].search_count(
                [('partner_id.name', '=', record.customer_name)])
            record.sale_order_count = self.env['setu.order'].search_count([('customer_id', '=', record.id)])
