from odoo import api, fields, models


class Student(models.Model):
    _name = "student"
    _description = "Student"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Student Name", help="Student Name")
    age = fields.Char(string="Student Age", help="Student Age", copy=False, )
    roll_no = fields.Char(string="Roll No", help="Roll No", copy=False)
    division = fields.Char(string="division", help="Student Division")

    state = fields.Selection(
        selection=[
            ('gujarat', 'Gujarat'),
            ('rajasthan', 'Rajasthan'),
        ]
    )

    capital = fields.Char(compute='_compute_capital', store=True)

    language = fields.Char(string="Language")
    teacher_id = fields.Many2one(comodel_name='teacher', string="Teacher Name")
    department_id = fields.Many2one(comodel_name='department', string="Department Name")
    country = fields.Char(string='Country', help='Country')
    indian = fields.Boolean(compute="_compute_indian", store=True, string='Indian')

    @api.onchange('state')
    def onchange_state(self):
        for record in self:
            if record.state == 'gujarat':
                record.language = 'Gujarati'
            if record.state == 'rajasthan':
                record.language = 'marwadi'

    @api.depends('country')
    def _compute_indian(self):
        for record in self:
            if record.country == 'india':
                record.indian = True
            if record.country != 'india':
                record.indian = False

    @api.depends('language')
    def _compute_capital(self):
        for record in self:
            if record.language == 'Gujarati':
                record.capital = 'Gandhinagar'
            if record.language == 'marwadi':
                record.capital = 'Jaypur'
