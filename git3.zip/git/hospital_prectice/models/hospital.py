from odoo import api, fields, models


class Hospital(models.Model):
    _name = 'hospital'
    _discription = 'Hospital'

    # select_file_for_import = fields.Binary(string='Select File')

    name = fields.Char(string="Hospital Name")
    location = fields.Char(string="Location")
    address_Original_First_Line = fields.Char(string="Address Original First Line")
    state = fields.Char(string="State")
    district = fields.Char(string="District")
    pincode = fields.Char(string="Pincode")
    telephone = fields.Char(string="Telephone")