from odoo import api, fields, models


class Product(models.Model):
    _name = 'product'

    name = fields.Char(string="Product Fields")
