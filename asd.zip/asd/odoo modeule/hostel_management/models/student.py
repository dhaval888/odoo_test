from odoo import api, fields, models


class Student(models.Model):
    _name = 'student'
    _description = 'Student'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Student Name", help='Student Name')
    age = fields.Integer(compute="_compute_age", store=True)
    join_date = fields.Date(string="Hostel Join Date", help='Student Hostel Join Date')
    end_date = fields.Date(string="Hostel Exit Date", help='Student Hostel Last Date',)

    city = fields.Selection(
        selection=[
            ('rajkot', 'Rajkot'),
            ('ahemadabad', 'Ahemadabad'),
            ('surat', 'Surat'),
            ('amreli', 'Amreli'),
            ('morbi', 'Morbi'),
        ], string="Available in City",
    )
    state = fields.Char(string="State", help="State")

    admin_id = fields.Many2one(comodel_name='admin', string='Room Type',)

    @api.onchange('city')
    def onchange_city(self):
        for rec in self:
            if rec.city == 'rajkot':
                rec.name = 'fenil'
            if rec.city == 'ahemadabad':
                rec.name = 'jeel'
            if rec.city == 'surat':
                rec.name = 'rutvik'
            if rec.city == 'amreli':
                rec.name = 'dhaval'
            if rec.city == 'morbi':
                rec.name = 'neel'

    # @api.depends("name")
    @api.depends('name')
    def _compute_age(self):
        for rec in self:
            if rec.name == 'fenil':
                rec.age = 21
            if rec.name == 'jeel':
                rec.age = 23
            if rec.name == 'rutvik':
                rec.age = 24
            if rec.name == 'dhaval':
                rec.age = 30
            if rec.name == 'neel':
                rec.age = 32