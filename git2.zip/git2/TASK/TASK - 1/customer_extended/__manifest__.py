{
    'name': 'Customer Extended',
    'version': '16.1',
    'depends': ['sale_management'],
    'data': [
        'views/res_partner_views.xml'
    ]
}