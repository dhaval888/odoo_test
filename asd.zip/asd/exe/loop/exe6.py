for i in range(1, 10, 2):
    for j in range(1, i + 1, 2):
        print(j, "", end=" ")
    for j in range(i, 8, 2):
        print("  ", end=" ")

    for j in range(i, 6, 2):
        print("  ", end=" ")
    for j in range(i, 0, -2):
        if j == 9:
            for k in range(7, 0, -2):
                print(k, end="  ")
        if j == 9:
            break
        print(j, "", end=" ")

    print("")

for i in range(8, 0, -2):
    for j in range(1, i + 1, 2):
        print(j, "", end=" ")
    for j in range(i, 10, 2):
        print("   ", end="")

    for j in range(i, 8, 2):
        print("  ", end=" ")
    for j in range(i, 0, -1):
        if j % 2 != 0:
            print(j, "", end=" ")

    print("")
