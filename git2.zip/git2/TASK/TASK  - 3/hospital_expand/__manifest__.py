{
    'name': 'Hospital Expand',
    'version': '16.1',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'wizard/hospital_wizars_view.xml',
        'views/hospital_view.xml',
    ]
}
