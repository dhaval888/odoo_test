# print(10 == 6)
# print(10<12)
# print(2>6)
#
# a = 120
# b = 50
# x=bool(123)
# print(x)
# if a > b:
#     print("a is greter than b")
# else:
#     print("b is smaller than a")
#
#
#
# print(bool("hello"))
# print(bool(5))
#
# x = "bool"
# y = 5
#
# print(bool(x))
# print(bool(y))
#
# print(bool(0))
#
# x = bool((10,20,30,40,50))
# print(x)
# x = bool([10,20,30,40])
# print(x)
# x = bool({"name":"rohit","number":45})
# print(x)
# x= bool({10,20,30,40})
# print(x)
#
#
# x = (10,20,30,40,50)
# print(bool(x))
# x = [10,20,30,40]
# print(bool(x))
# x = {"name":"rohit","number":45}
# print(bool(x))
# x={10,20,30,40}
# print(bool(x))
#
#
# x = ()
# print(bool(x))
# x = []
# print(bool(x))
# x = {}
# print(bool(x))
# x={}
# print(bool(x))
# x = ""
# print(bool(x))
# x = False
# print(bool(x))
# x = None
# print(bool(x))

class Test():
    def __len__(self):
        return 0
t = Test()
print(bool(t))

def test():
    return True
print(test())

def test():
    return 12
if test():
    print("yes")
else:
    print("no")

x = 12
x = str(x)
print(isinstance(x,int))
print(isinstance(x,str))