# a = 20
# b = 50
#
# if b > a :
#     print("b is greater than a")
#
#
# a = 20
# b = 20
#
# if a > b:
#     print("a is greater than b ")
# elif a == b:
#     print("a and b is equals")


# a = 50
# b = 20

# if b > a:
#     print("b is big")
# elif a == b:
#     print("a and b is equals")
# else:
#     print("a is big")
#
#
# if a > b: print("a is greater than b")
#
# a = 2
#
# b = 330
# print("A") if a > b else print("B")

# a = 330
# b = 330
# print("A") if a > b else print("=") if a == b else print("B")


a = 20
b = 30
c = 51
if a < b and c > b:
    print("both condition are True")

if b < a and c > a:
    print("only one condition are true")

if not c > a:
    print("not with if")
else:
    print("this is not operator")

a = 10

if a > 3:
    print("above 10")
    if a > 5:
        print("and also above 10")
    else:
        print("but not above 10")



a = 33
b = 200

if b > a:
  pass