{
    'name': 'Res Partner Extended',
    'version': '16.1',
    'depends': ['sale'],
    'data': [
        'security/ir.model.access.csv',
        'views/customer_views.xml',
    ],
}