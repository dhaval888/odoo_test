from odoo import api, fields, models


class NewFile(models.Model):
    _inherit = "sale.order"
    _description = "Sale Order"


    def action_view_invoice(self):
        res = super(NewFile, self).action_view_invoice()
        print("hello")
        return res
