from odoo import api, fields, models


class ResPartnerExtended(models.Model):
    _name = 'res.partner.extended'

    name = fields.Char(string="Customer Fields")
    # address = fields.Char()
    # phone = fields.Char()
    # mobile = fields.Char()
    # email = fields.Char()
