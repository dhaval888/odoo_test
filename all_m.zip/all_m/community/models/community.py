from odoo import api, fields, models, _
import os, shutil, base64, io


class Community(models.Model):
    _name = 'community'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'edition'

    version = fields.Selection(
        selection=[('15', '15'), ('16', '16'), ('17', '17'), ('18', '18'), ], tracking=True)

    edition = fields.Char(string="Edition", default="Community")

    product_id = fields.Many2one('product.product')

    def git_clone(self):
        print("START")
        repo_url = "https://github.com/odoo/odoo.git"
        branch_name = f"{self.version}.0"

        # repo_url = "https://github.com/dbarnett/python-helloworld.git"
        # branch_name = "py2"

        # clone_dir = "/home/setu52/Desktop/odoo/odoo_new_1"
        #
        # os.chdir('/home/setu52/Desktop/odoo')
        # all_subdirs = [d for d in os.listdir('.') if os.path.isdir(d)]
        # if len(all_subdirs) > 0:
        #     all_subdirs.sort()
        #     all_dict = all_subdirs[-1]
        #     custom_dict = int(all_dict.split("_")[-1]) + 1
        #     clone_dir = f"/home/setu52/Desktop/odoo/odoo_new_{custom_dict}"
        #
        # # if os.path.exists(clone_dir):
        # #     print(f"Nested folders '{clone_dir}' already exist.")
        #
        # command = f"git clone -b {branch_name} {repo_url} {clone_dir}"
        # exit_code = os.system(command)
        # if exit_code == 0:
        #     print("Repository cloned successfully!")
        #
        # print("END")
        # zip_name = f"{self.edition}_{self.version}.0"
        #
        # version_list = []
        # attachment_ids = self.env['ir.attachment'].search([])
        # for attachment_rec in attachment_ids:
        #     if zip_name.split(".")[-2] in attachment_rec.name:
        #         version_list.append(attachment_rec.name.split(".")[-1])
        #
        # if len(version_list) > 0:
        #     version_list.sort()
        #     folder_new_version = int(version_list[-1]) + 1
        #     zip_name = f'{self.edition}_{self.version}.{folder_new_version}'
        #
        # zip_file = shutil.make_archive(zip_name, 'zip', clone_dir)
        #
        # with open(zip_name + ".zip", "rb") as fd:
        #     buf = io.BytesIO(fd.read())
        #     bytes = buf.getvalue()
        # encode_bytes = base64.encodebytes(bytes)
        #
        # attachment = self.env['ir.attachment'].create(
        #     {'name': zip_name, 'datas': encode_bytes, 'res_model': 'community', 'res_id': self.id,
        #      })
        # self.message_post(body='File Attachment', attachment_ids=[attachment.id])

    def new_temp_method(self):
        for rec in self:
            print(rec)

    def name_get(self):
        list = []
        for rec in self:
            name = rec.edition
            if rec.version:
                name = name + " " + f"({rec.version})"
                list.append((rec.id, name))
        return list

    # repo_url = "https://github.com/odoo/odoo.git"
    #   branch_name = f"{self.version}.0"
