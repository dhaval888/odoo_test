{
    'name': 'Community',
    'version': '16.1',
    'depends': ['mail', 'sale'],
    'data': [
        'security/ir.model.access.csv',
        'wizard/hospital_master_data_views.xml',
        'views/community_view.xml',
        'report/ir_actions_report.xml',
        'report/community_report.xml',
    ],
}
