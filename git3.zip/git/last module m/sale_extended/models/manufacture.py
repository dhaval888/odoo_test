from odoo import models, fields, api


class Manufacture(models.Model):
    _inherit = 'mrp.production'

    sale_order_count = fields.Char()
    purchase_count = fields.Char()

    def sale_order(self):
        for rec in self:
            self.ensure_one()
            return {
                'type': 'ir.actions.act_window',
                'name': 'Sale Order',
                'view_type': 'form',
                'view_mode': 'tree,form',
                'view_id': False,
                'res_model': 'sale.order.line',
                'domain': [('product_id', '=', rec.product_id.id)],
                'context': "{'create': False}"
            }

    # def manufacturing(self):
    #     for rec in self:
    #         self.ensure_one()
    #         return {
    #             'type': 'ir.action.act_window',
    #             'name': 'Manufacture',
    #             'view_type': 'form',
    #             'view_mode': 'tree,form',
    #             'view_id': False,
    #             'res_model': 'mrp.production',
    #             'domain'
    #         }

    def purchase(self):
        for rec in self:
            self.ensure_one()
            return {
                'type': 'ir.actions.act_window',
                'name': 'Sale Order',
                'view_type': 'form',
                'view_mode': 'tree,form',
                'view_id': False,
                'res_model': 'purchase.order.line',
                'domain': [('product_id', '=', rec.product_id.id)],
                'context': "{'create': False}"
            }