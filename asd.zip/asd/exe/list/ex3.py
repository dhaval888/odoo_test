# [3] Write a Python program to get the smallest number from a list.
# Input: [10,12,20,22,2]
# Output: 2

lst = [10, 12, 20, 22, 2]

small = lst[0]

for i in lst:
    if i < small:
        small = i
print(small)