from odoo import fields, models, api, _
from odoo.exceptions import UserError


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    # partner_invoice_id = fields.Many2one(comodel_name='res.partner', compute='_compute_partner_invoice_id',
    #                                      domain="[('partner_id', '=', partner_id.id)]")
    # partner_shipping_id = fields.Many2one(comodel_name='res.partner', compute='_compute_partner_shipping_id',
    #                                       domain="[('partner_id', '=', partner_id.id)]")

    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        for record in self:
            domain = [('partner_id', '=', record.partner_id.id)]
            # return {'domain': {'partner_invoice_id': domain, 'partner_shipping_id': domain}}
            if record.partner_id.name == record.partner_id.name:
                for customer in record.partner_id.child_ids:
                    print(customer.name)
                    for child_customer in customer.child_ids:
                        print(child_customer)

            # if record.partner_id.name == record.partner_id.name:
            #     for customer in record.partner_id.child_ids:
            #         # a = {'domain': {'partner_invoice_id': domain}}
            #         #             move_ids = self.env['stock.move'].search([('picking_id', 'in', picking_ids.ids)])
            #         new_var = self.env['sale.order'].search([('', '', '')])
            #         print(customer.name)
            #         for child_customer in customer.child_ids:
            #             b = {'domain': {'partner_shipping_id': domain}}
            #             print(child_customer.name)
            # else:
            #     print("else Part")

            # def unlink(self):
#
#                 picking_ids = self.picking_ids.move_ids
#             move_ids = self.env['stock.move'].search([('picking_id', 'in', picking_ids.ids)])
#             move_ids.unlink()
#             picking_with_search = self.env['stock.picking'].search([('sale_id', '=', self.id)])
# # - search()
# self.env['stock.picking'].search(
#     ['|', '|', ('sale_id', '=', self.id), ('state', '=', 'cancel'), ('name', '=', 'WH/OUT/30')])
#
# ['&', '|', '&',
#  (('designation', '=', 'senior_manager'), ('salary', '>', 70000)) or (('city', '=', 'rajkot')('salary', '<', 50000))]


# partner_invoice_id = fields.Many2one(
#     comodel_name='res.partner',
#     compute='_compute_partner_invoice_id',
#     domain="[('partner_id', '=', 'partner_id')]")
#
# partner_shipping_id = fields.Many2one(
#     comodel_name='res.partner',
#     compute='_compute_partner_shipping_id',
#     domain="[('partner_id', '=', 'partner_id')]", )
