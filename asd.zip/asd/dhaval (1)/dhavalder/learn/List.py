# lst = ["apple", "banana", "cherry"]
# print(lst)
#
# lst = ["apple", "banana", "cherry", "apple", "banana"]
# print(lst[0])
# print(lst[0:])
# print(lst[2:6])
# print(lst[-5:-2 + 1])
# print(lst[::-1])
#
# if "apple" in lst:
#     print("yes apple is there ! ")
# lst = ["apple", "banana", "cherry"]
# lst[1] = "orange"
# print(lst)
#
# lst[1:2] = ["pineapple"]
# print(lst)
#
# lst[1:2] = ["mango", "apple", "apple"]
# print(lst)
#
# lst[0:5] = ["fruits"]
# print(lst)
#
# lst = ["apple", "banana", "cherry"]
# lst.append("mango")
# print(lst)
#
# lst = ["apple", "banana", "cherry"]
# lst.insert(1, "cherry")
# print(lst)
#
# lst = ["apple", "banana", "cherry"]
# num = [10, 20, 30, 40]
#
# lst.extend(num)
# print(lst)
#
# t = ("rohit", "virat", "jaspreet")
# lst.extend(t)
# print(lst)
#
# lst = ["apple", "banana", "cherry", ]
# lst.remove("banana")
# print(lst)
#
# lst = ["apple", "banana", "cherry", "banana"]
# lst.remove("banana")
# print(lst)
#
# lst = ["apple", "banana", "cherry", "banana"]
# lst.pop()
# print(lst)
#
# lst = ["apple", "banana", "cherry", "banana"]
# lst.pop(2)
# print(lst)
#
# lst = ["apple", "banana", "cherry", "banana"]
# lst.pop()
# print(lst)
#
# lst = ["apple", "banana", "cherry", "banana"]
# del lst[0]
# print(lst)
#
# lst = ["apple", "banana", "cherry", "banana"]
# del lst[3]
# print(lst)
#
# lst = ["apple", "banana", "cherry", "banana"]
# del lst
#
# lst = ["apple", "banana", "cherry", "banana"]
# lst.clear()
# print(lst)
#
# lst = ["apple", "banana", "cherry", "banana"]
# for i in range(len(lst)):
#     print(lst[i])
#
# l = ["apple", "banana", "cherry", "banana", "mango"]
#
# i = 0
#
# while i < len(l):
#     print(l[i])
#     i += 3
#
# lst = [10, 20, 30, 10, 50, 20, 30, 30, 10]
# new_lst = []
# for i in lst:
#     if i not in new_lst:
#         new_lst.append(i)
# print(new_lst)
#
# fruits = ["apple", "banana", "cherry", "kiwi", "mango"]
#
# newlist = [x for x in fruits if "a" in x]
#
# print(newlist)
#
# fruits = ["apple", "banana", "cherry", "kiwi", "mango"]
#
# newlist = [x for x in fruits if x != "banana"]
#
# print(newlist)
#
# # sort method
#
# l = ["apple", "banana", "cherry", "banana", "mango"]
# l.sort()
# print(l)
# l.sort(reverse=True)
# print(l)
#
# lst = [99, 65, 20, 10, 80, 1, 3, 40]
# lst.sort()
# print(lst)
# lst.sort(reverse=True)
# print(lst)
#
# l = ["apple", "Banana", "cheRry", "banana", "Mango"]
# l.sort(key=str.lower)
# print(l)
# l = ["apple", "Banana", "cheRry", "banana", "Mango"]
# l.sort()
# print(l)
#
# lst = ["rohit", "virat", "jadeja", "jaspreet", "dravid", "sachin"]
# lst.reverse()
# print(lst)
# lst = ["rohit", "virat", "jadeja", "jaspreet", "dravid", "sachin"]
#
# print(lst[::-1])


#copy list

# lst = ["rohit", "virat", "jadeja", "jaspreet"]
# l = lst.copy()
# print(lst)
# print(l)
#
# lst1 = list(lst)
# print(lst1)

# l1 = [10,20]
# l2 = [30,40]

# lst=l1+l2
# print(lst)
#
# for x in l2:
#     l1.append(x)
# print(l1)
#
# l1.append(l2)
# print(l1)

# lst = [10, 20, 30, 10, 50, 20, 30, 30, 10]
#
# x = lst.count(10)
# print(x)

# lst = ["rohit", "virat", "jadeja", "jaspreet", "dravid", "sachin"]
# lst[1:2] = ["klrahul","sarfraj","sammy"]
# print(lst)

lst = ["rohit", "virat", "jadeja"]
print(len(lst))
