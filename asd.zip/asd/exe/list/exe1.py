# [1] Write a Python program to count the occurrences of each word in a given sentence.
# Input: "Complete sentence Complete exercise"
# Output:Complete - 2
# 		sentence - 1
# 		exercise - 1
#
# st = "Complete sentence Complete exercise"
# x = st.split()
#
# print("Complete",x.count("Complete"))
# print("sentence",x.count("sentence"))
# print("Complete",x.count("exercise"))


st = str.split("Complete sentence Complete exercise")
c = dict()
for i in st:
    if i in c:
        c[i] += 1
    else:
        c[i] = 1
print(c)

