from odoo import api, fields, models


class Employee(models.Model):
    _name = 'employee'
    _description = 'Employee'
    _rec_name = 'name'
    # _order = ' age desc , name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Employee Name", help="Employee Name", copy=True)
    age = fields.Char(compute="_compute_age", store=True)
    salary = fields.Char(string="Employee Salary", help="Salary", copy=False)

    gender = fields.Selection(
        selection=[
            ('male', 'Male'),
            ('female', "Female"),

        ], string='Select Gender', help='Select Gender', default='male'
    )

    admin_id = fields.Many2one(comodel_name='admin', string="Admin Name", help="Admin Name")

    @api.onchange('salary')
    def onchange_salary(self):
        for rec in self:
            if rec.salary == '10000':
                rec.name = 'dhaval'
            if rec.salary == '20000':
                rec.name = 'neha'
            if rec.salary == '30000':
                rec.name = 'jeel'
            if rec.salary == '40000':
                rec.name = 'fenil'

    @api.depends('name')
    def _compute_age(self):
        for record in self:
            if record.name == 'dhaval':
                record.age = '23'
            if record.name == 'neha':
                record.age = '26'
            if record.name == 'jeel':
                record.age = '29'
            if record.name == 'fenil':
                record.age = '30'
