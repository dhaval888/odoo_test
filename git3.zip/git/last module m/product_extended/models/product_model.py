from odoo import models, fields, api


class ProductModel(models.Model):
    _name = 'product.model'

    name = fields.Char(string="Name")

    product_mode_id = fields.Many2one('product.product')


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    @api.model_create_multi
    def create(self, vals):
        res = super(SaleOrder, self).create(vals)
        for rec in res:
            if rec.model_name_id:
                rec.order_line.model_order_line_name = rec.model_name_id.name
        return res
