import itertools


class customer_master:
    customer = {}
    c_id = itertools.count(1)
    c_name = str()
    c_type = []
    c_pan = int()

    def cust_data(self):

        cust_count = next(self.c_id)
        print('customer id :', cust_count)

        self.c_name = input('customer name :')
        cust_type = input('enter customer type : ')
        if cust_type == 'customer' or cust_type == 'vendor' or cust_type == 'customer,vendor':
            self.c_type = cust_type

            self.c_pan = input('enter pan no:')
            for x in self.customer.values():
                if self.c_pan in x.values():
                    print("pan no is already exist")
                    return customer_master()
                    # self.customer.pop()

        else:
            print("only two values are supported \"customer\" and \"vendor\"")
            return customer_master()

        self.customer[cust_count] = {'name': self.c_name, 'type': self.c_type,
                                     'pan': self.c_pan}


class product_master(customer_master):
    product = {}
    p_id = itertools.count(1)
    p_name = str()
    p_incoming = float()
    p_outgoing = float()
    p_onhand = 0.0

    def prod_data(self):
        prod_count = next(self.p_id)
        print('customer id :', prod_count)

        self.p_name = input('product name :')
        for x in self.product.values():
            if self.p_name in x.values():
                print("product name is already exist")
                return product_master()

        self.p_incoming = float(input('enter a product incoming : '))
        self.p_outgoing = float(input('enter a product outgoing : '))

        if self.p_incoming >= self.p_outgoing:
            self.p_onhand = self.p_incoming - self.p_outgoing
        else:
            print("stock is not available")
            return product_master()

        self.product[prod_count] = {'name': self.p_name, 'incoming': self.p_incoming,
                                    'outgoing': self.p_outgoing, 'onhand': self.p_onhand}


class stock_move(product_master, customer_master):
    stock = {}
    stock_id = itertools.count(1)
    product_id = int()
    cust_id = int()
    stock_qty = 0
    stock_type = str()
    state = str()

    def stock_data(self):

        stock_count = next(self.stock_id)
        print('stock_id :', stock_count)

        self.cust_id = int(input("enter customer id : "))
        if self.cust_id in super().customer.keys():
            self.product_id = int(input('enter product id : '))
            if self.product_id in super().product.keys():
                self.stock_qty = float(input('enter qty : '))
                if self.stock_qty < 1:
                    print('please enter proper qty !..')
                    return stock_move().stock_data()

                type = str(input('in or out :'))
                if type in 'in':
                    incoming = self.stock_qty + super().product[self.product_id].get("incoming")
                    onhand = self.stock_qty + super().product[self.product_id].get("onhand")
                    super().product[self.product_id].update({"incoming": incoming, "onhand": onhand})
                    self.stock_type = "incoming"

                elif type in 'out':
                    if self.stock_qty > super().product[self.product_id].get("onhand"):
                        print('stock are not available.\n')
                        return stock_move().stock_data()
                    outgoing = self.stock_qty + super().product[self.product_id].get("outgoing")
                    onhand = super().product[self.product_id].get("onhand") - self.stock_qty
                    super().product[self.product_id].update({"outgoing": outgoing, "onhand": onhand})
                    self.stock_type = "outgoing"
                else:
                    print("enter valid option")

                self.stock[stock_count] = {'product_id': self.product_id, 'customer_id': self.cust_id, 'prod_qty': self.stock_qty, 'type': self.stock_type}

            else:
                print(self.product_id, 'id is not exist :')
                return stock_move().stock_data()
        else:
            print(self.cust_id, ' id is not exist')
            return stock_move().stock_data()


while True:
    print("1.customer")
    print("2.product")
    print("3.stock")
    print("4.check")
    print("5.exit")
    n = int(input('Choice a number : '))

    if n == 1:
        customer_master().cust_data()
    elif n == 2:
        product_master().prod_data()
    elif n == 3:
        stock_move().stock_data()
    elif n == 4:
        print('customer ', customer_master().customer)
        print('product', product_master().product)
        print('stock', stock_move().stock)
    elif n == 5:
        print('customer ', customer_master().customer)
        print('product', product_master().product)
        print('stock', stock_move().stock)
        break

# a = {1: {'cust_name': 'nam', 'cust_type': 'vendor', 'cust_pan': '12'}, 2: {'cust_name': 'n', 'cust_type': 'vendor', 'cust_pan': '12'}}
# a.pop(1)
# print(a)

# a = {1: {'prod_name': 'name', 'prod_in': 20.0, 'prod_out': 10.0, 'prod_on_hand': 10.0}}
# for x in self.product.values():
#     if self. in x.values():
