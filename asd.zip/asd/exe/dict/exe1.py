mylist1 = [{'product': 'furn_0789', 'quantity': 16.0, 'warehouse': 'san francisco'},
          {'product': 'furn_6666', 'quantity': 16.0, 'warehouse': 'san francisco'},
          {'product': 'e-com08', 'quantity': 18.0, 'warehouse': 'san francisco'},
          {'product': 'e-com07', 'quantity': 500.0, 'warehouse': 'san francisco'},
          {'product': 'e-com10', 'quantity': 22.0, 'warehouse': 'san francisco'},
          {'product': 'e-com11', 'quantity': 33.0, 'warehouse': 'san francisco'},
          {'product': 'e-com12', 'quantity': 26.0, 'warehouse': 'san francisco'},
          {'product': 'e-com13', 'quantity': 30.0, 'warehouse': 'san francisco'},
          {'product': 'furn_0096', 'quantity': 45.0, 'warehouse': 'san francisco'},
          {'product': 'furn_0097', 'quantity': 50.0, 'warehouse': 'san francisco'},
          {'product': 'furn_0098', 'quantity': 55.0, 'warehouse': 'san francisco'},
          {'product': 'desk0004', 'quantity': 60.0, 'warehouse': 'san francisco'},
          {'product': 'furn_7800', 'quantity': 60.0, 'warehouse': 'san francisco'},
          {'product': 'furn_0269', 'quantity': 10.0, 'warehouse': 'san francisco'},
          {'product': 'furn_1118', 'quantity': 2.0, 'warehouse': 'san francisco'},
          {'product': 'furn_8855', 'quantity': 80.0, 'warehouse': 'san francisco'},
          {'product': 'e-com07', 'quantity': 200.0, 'warehouse': 'san francisco'},
          {'product': 'furn_8888', 'quantity': 45.0, 'warehouse': 'san francisco'},
          {'product': 'e-com06', 'quantity': 75.0, 'warehouse': 'san francisco'},
          {'product': 'furn_5555', 'quantity': 50.0, 'warehouse': 'san francisco'},
          {'product': 'furn_7777', 'quantity': 35.0, 'warehouse': 'san francisco'},
          {'product': 'furn_7888', 'quantity': 125.0, 'warehouse': 'san francisco'},
          {'product': 'e-com11', 'quantity': 120.0, 'warehouse': 'san francisco'},
          {'product': 'furn_0789', 'quantity': 60.0, 'warehouse': 'chicago'},
          {'product': 'furn_6666', 'quantity': 60.0, 'warehouse': 'chicago'},
          {'product': 'e-com08', 'quantity': 18.0, 'warehouse': 'chicago'},
          {'product': 'e-com07', 'quantity': 500.0, 'warehouse': 'chicago'},
          {'product': 'e-com18', 'quantity': 22.0, 'warehouse': 'chicago'},
          {'product': 'e-com11', 'quantity': 33.0, 'warehouse': 'chicago'},
          {'product': 'e-com12', 'quantity': 26.0, 'warehouse': 'chicago'},
          {'product': 'e-com13', 'quantity': 30.0, 'warehouse': 'chicago'},
          {'product': 'furn_0096', 'quantity': 45.0, 'warehouse': 'chicago'},
          {'product': 'furn_0097', 'quantity': 50.0, 'warehouse': 'chicago'},
          {'product': 'furn_0098', 'quantity': 55.0, 'warehouse': 'chicago'},
          {'product': 'desk0004', 'quantity': 60.0, 'warehouse': 'chicago'},
          {'product': 'furn_7800', 'quantity': 60.0, 'warehouse': 'chicago'},
          {'product': 'furn_0269', 'quantity': 18.0, 'warehouse': 'chicago'},
          {'product': 'furn_1118', 'quantity': 2.0, 'warehouse': 'chicago'},
          {'product': 'furn_8855', 'quantity': 80.0, 'warehouse': 'chicago'},
          {'product': 'e-com07', 'quantity': 200.0, 'warehouse': 'chicago'},
          {'product': 'furn_8888', 'quantity': 45.0, 'warehouse': 'chicago'},
          {'product': 'e-com06', 'quantity': 75.0, 'warehouse': 'chicago'},
          {'product': 'furn_5555', 'quantity': 50.0, 'warehouse': 'chicago'},
          {'product': 'furn_7777', 'quantity': 35.0, 'warehouse': 'chicago'},
          {'product': 'furn_7888', 'quantity': 150.0, 'warehouse': 'chicago'},
          {'product': 'e-com11', 'quantity': 120.0, 'warehouse': 'chicago'},
          {'product': 'furn_8888', 'quantity': 50.0, 'warehouse': 'chicago'},
          {'product': 'e-com18', 'quantity': 25.0, 'warehouse': 'chicago'},
          {'product': 'furn_7777', 'quantity': 45.0, 'warehouse': 'chicago'},
          {'product': 'furn_8888', 'quantity': 50.0, 'warehouse': 'san francisco'},
          {'product': 'e-com10', 'quantity': 25.0, 'warehouse': 'san francisco'},
          {'product': 'furn_7777', 'quantity': 45.0, 'warehouse': 'san francisco'},
          {'product': 'furn_7888', 'quantity': 75.0, 'warehouse': 'san francisco'},
          {'product': 'furn_8855', 'quantity': 15.0, 'warehouse': 'san francisco'},
          {'product': 'furn_8888', 'quantity': 45.0, 'warehouse': 'san francisco'},
          {'product': 'e-com06', 'quantity': 75.0, 'warehouse': 'san francisco'},
          {'product': 'furn_8855', 'quantity': 15.0, 'warehouse': 'san francisco'},
          {'product': 'furn_6666', 'quantity': 10.0, 'warehouse': 'san francisco'},
          {'product': 'furn_7777', 'quantity': 100.0, 'warehouse': 'san francisco'},
          {'product': 'e-com07', 'quantity': 100.0, 'warehouse': 'san francisco'},
          {'product': 'e-com07', 'quantity': 100.0, 'warehouse': 'san francisco'},
          {'product': 'furn_7777', 'quantity': 80.0, 'warehouse': 'san francisco'},
          {'product': 'furn_7800', 'quantity': 16.0, 'warehouse': 'san francisco'},
          {'product': 'furn_7800', 'quantity': 32.0, 'warehouse': 'san francisco'},
          {'product': 'e-com07', 'quantity': 50.0, 'warehouse': 'san francisco'},
          {'product': 'furn_6666', 'quantity': 20.0, 'warehouse': 'san francisco'},
          {'product': 'e-com07', 'quantity': 80.0, 'warehouse': 'san francisco'},
          {'product': 'e-com07', 'quantity': 80.0, 'warehouse': 'san francisco'},
          {'product': 'desk0005', 'quantity': 65.0, 'warehouse': 'san francisco'},
          {'product': 'furn_7800', 'quantity': 8.0, 'warehouse': 'san francisco'},
          {'product': 'furn_6666', 'quantity': 5.0, 'warehouse': 'san francisco'},
          {'product': 'e-com11', 'quantity': 5.0, 'warehouse': 'san francisco'},
          {'product': 'furn_6666', 'quantity': 5.0, 'warehouse': 'san francisco'},
          {'product': 'e-com11', 'quantity': 10.0, 'warehouse': 'san francisco'},
          {'product': 'desk0006', 'quantity': 70.0, 'warehouse': 'san francisco'}]

new_dict = {}
for i in mylist1:

    p = i.get('product')
    q = i.get('quantity')
    w = i.get('warehouse')

    if w in new_dict:
        new_dict[w].append({'product': p, 'quantity': q})

    else:
        new_dict.update({w: [{'product': p, 'quantity': q}]})

print(new_dict)


















# new_dict = {}
# for i in mylist1:
#     product = i.get('product')
#     quantity = i.get('quantity')
#     warehouse = i.get('warehouse')
#
#     if warehouse not in new_dict:
#         new_dict.update({warehouse: [{'product': product, 'quantity': quantity}]})
#
#     else:
#         new_dict[warehouse].append({'product': product, 'quantity': quantity})
#
# print(new_dict)


# data = {
#     'furn_0789': [{'warehouse': 'san francisco', 'quantity': '16'}]}
# d = {}
#
# for i in mylist1:
#     warehouse = i.get('warehouse')
#     product = i.get('product')
#     quantity = i.get('quantity')
#
#     for j in data.values():
#         for k in j:
#             data.keys()
#             warehouse = k.get('warehouse')
#
#         if data.keys() == product and warehouse == k.get('warehouse'):

