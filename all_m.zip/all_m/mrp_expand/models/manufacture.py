from odoo import api, fields, models


class Costing(models.Model):
    _name = "manufacturing"

    product_id = fields.Many2one('product.product')
    product_qty = fields.Float(string="Quantity", help="Please Enter Product Quantity")

    manufacturing_page_id = fields.Many2one('product.product')


class MrpProductiom(models.Model):
    _inherit = 'product.product'

    manufacturing_ids = fields.One2many('manufacturing', 'manufacturing_page_id')


class StockMove(models.Model):
    _inherit = 'stock.move'

    temp_display_name = fields.Char()


