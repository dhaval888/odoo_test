from odoo import models, fields, api


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    model_name_id = fields.Many2one('product.model', string="Model Name", readonly=False)

    def write(self, vals):
        res = super(SaleOrder, self).write(vals)
        for rec in self:
            if rec.order_line:
                rec.order_line.model_order_line_name = rec.model_name_id.name
            if rec.invoice_ids:
                rec.invoice_ids.invoice_line_ids.model_invoice_line_name = rec.model_name_id.name
            if rec.picking_ids:
                rec.picking_ids.move_ids.model_stock_line_name = rec.model_name_id.name
        return res


class OrderLine(models.Model):
    _inherit = 'sale.order.line'

    order_line_sale_id = fields.Many2one('sale.order')

    model_order_line_name = fields.Char(string='Model Name')

    product_id = fields.Many2one()


class PickingLine(models.Model):
    _inherit = 'stock.move'

    model_stock_line_name = fields.Char(string='Model Name')

    @api.model_create_multi
    def create(self, vals):
        res = super(PickingLine, self).create(vals)
        sale_id = self.env['sale.order'].search([('name', '=', res.origin)])
        res.model_stock_line_name = sale_id.model_name_id.name
        return res


class InvoiceLine(models.Model):
    _inherit = 'account.move.line'

    model_invoice_line_name = fields.Char(string='Model Name')


class AccountMove(models.Model):
    _inherit = 'account.move'

    @api.model_create_multi
    def create(self, vals):
        res = super(AccountMove, self).create(vals)
        for val in vals:
            invoice_origin = val.get('invoice_origin')
            sale_id = self.env['sale.order'].search([('name', '=', invoice_origin)])
            res.invoice_line_ids.model_invoice_line_name = sale_id.model_name_id.name
        return res

# product_model_id = fields.Many2one()
# model_name = fields.Selection(selection=[
#     ('', ''), ],
# )
# def _compute_product(self):
#     for rec in self:
#         product_new_id = self.env['product.product'].search([('product_model_name', '!=', rec.product_id.product_model_name)])
#         for product in product_new_id:
#             product_rec = self.product_id
#             if not product_rec:
#                 print(product)
#  @api.onchange('product_id')
#  def onchange_product_id(self):
#      if self.product_id:
#          self.optional_id = False
#          optional_products = self.product_id.optional_product_ids.ids
#          if optional_products:
#              domain = [('id', 'in', optional_products)]
#              return {'domain': {'optional_id': domain}}
#      return {'domain': {'optional_id': [('id', 'in', [])]}}
#

# product_template_id = fields.Many2one('sale.order.line')

# @api.depends('product_id')
# def _compute_product(self):
#     for rec in self:
#         if rec.product_id:
#             print(rec)

# @api.onchange('product_id')
# def _product_onchange(self):
#     for record in self:
#         if record.product_id:
#             """Select fields get product variable"""
#             product_new_id = self.env['product.product'].search(
#                 [('product_model_name', '=', record.product_id.name)])
#             print(product_new_id)

# record.order_line.model_order_line_name = record.product_id.name
# record.invoice_ids.invoice_line_ids.model_order_line_name = record.product_id.name

# for product in product_new_id:
#     rec = (0, 0,
#            {'product_template_id': product.id, 'order_id': product.id,
#             'product_id': product.id, 'customer_lead': 0.0,
#             'name': product.name, 'product_uom_qty': 1,
#             'price_unit': product.lst_price,
#             'price_subtotal': product.lst_price, })
#     return hash(self.origin)
#     record.order_line = rec
#
# for product in product_new_id:
#     order_line = self.env['sale.order.line'].create({
#         'product_template_id': product.id,
#         'order_id': product.id,
#         'product_id': product.id,
#         'customer_lead': 0.0,
#         'name': product.name,
#         'product_uom_qty': 1,
#         'price_unit': product.lst_price,
#         'price_subtotal': product.lst_price * 1,
#     })
#     record.order_line = order_line.ids
