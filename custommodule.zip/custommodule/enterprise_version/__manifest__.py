{
    'name': 'Enterprise Version',
    'version': '16.1',
    'depends': ['mail', 'portal'],
    'data': [
        'security/ir.model.access.csv',
        'views/enterprise_version_views.xml',
    ],
}
