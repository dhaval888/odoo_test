{
    'name': 'Sale Expand',
    'version': '16.1',
    'depends': ['sale_management'],
    'data': [
        # 'security/ir.model.access.csv'
        'views/sale_order_views.xml',
    ]
}