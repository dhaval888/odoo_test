from odoo import api, fields, models
from odoo.exceptions import UserError
from datetime import date, datetime
import datetime


class Costing(models.Model):
    _name = "costing"

    serial_number = fields.Integer(string="Sr.NO", help='Serial Number',
                                   readonly=True, )
    opening_balance = fields.Float(string="Opening Balance", readonly=True, help="Please Enter Opening Balance")
    party_name_id = fields.Many2one('res.partner', string="Party Name", help="Please Enter Party Name", required=True)
    bill_number = fields.Char(string="Bill NO.", required=True)
    start_date = fields.Date(string="Start Date", help="Please Select Date", required=True)
    amount = fields.Float(string="Amount", help="Please Enter Amount", required=True)
    remarks = fields.Html(string="Remark", help="Please Enter Remark", )
    sub_total = fields.Float(string="Total", readonly=True, )

    work_center_id = fields.Many2one('mrp.workcenter')

    # @api.depends('party_name_id', 'bill_number', 'serial_number', 'amount')
    # def _compute_add_new_line(self):
    #     for rec in self:
    # costing_id = self.env['costing'].search([], limit=1, order='id desc')

    # for cost_rec in costing_id:
    #     # cost_rec.sub_total = 0
    #
    #     serial_number = cost_rec.serial_number + 1
    #     opening_balance = rec.sub_total
    #     party_name_id = rec.party_name_id
    #     bill_number = rec.bill_number
    #     start_date = rec.start_date
    #     # rec.amount = 0
    #     # amount = rec.amount
    #     remarks = rec.remarks
    #     sub_total = opening_balance + rec.amount
    #
    #     rec.update({
    #         'serial_number': serial_number,
    #         'opening_balance': opening_balance,
    #         'party_name_id': party_name_id,
    #         'bill_number': bill_number,
    #         'start_date': start_date,
    #         'remarks': remarks,
    #         'sub_total': sub_total
    #     })

    # sub_total = rec.opening_balance + rec.amount
    # rec.update({
    #     'serial_number': rec.serial_number,
    #     'opening_balance': rec.opening_balance,
    #     'party_name_id': rec.party_name_id,
    #     'bill_number': rec.bill_number,
    #     'start_date': rec.start_date,
    #     'amount': rec.amount,
    #     'remarks': rec.remarks,
    #     'sub_total': sub_total
    # })
    #
    # op_balance = 0
    # new_costing_ids = self.env['costing'].search([])
    # costing_id = self.env['costing'].search([], limit=1, order='id desc')
    # seconds_last_ids = self.env['costing'].search([], limit=2, order='id desc')

    # if not rec:
    #     rec.update({
    #         'serial_number': 1
    #     })

    # for sec_last_rec in seconds_last_ids:
    #     if sec_last_rec.id != costing_id.id:
    #         op_balance = sec_last_rec.sub_total
    #
    #         # serial_number = sec_last_rec.serial_number + 1
    #
    # if len(new_costing_ids) != 1:
    #     costing_id.opening_balance = op_balance
    #     # costing_id.serial_number += serial_number

    # @api.onchange('amount', 'party_name_id')
    # def _compute_add_new_line(self):
    #     for rec in self:
    #         rec.sub_total = rec.opening_balance + rec.amount
    #         # rec.temp = 1


class WorkCenter(models.Model):
    _inherit = 'mrp.workcenter'

    temp = fields.Char(compute="_compute_add_line")
    costing_ids = fields.One2many('costing', 'work_center_id')

    @api.depends('tag_ids')
    def _compute_add_line(self):
        list = []  # 1, 2, 3, 4, 5
        for rec in self:
            for cost_rec in rec.costing_ids:
                list.append(cost_rec)
            for index, cost_rec in enumerate(rec.costing_ids):
                if list[0] == cost_rec:
                    cost_rec.opening_balance = 0
                    cost_rec.sub_total = cost_rec.amount + cost_rec.opening_balance
                    cost_rec.serial_number = 1
                else:
                    temp_index = index - 1
                    last_rec = list[temp_index]
                    current_rec = list[index]

                    current_rec.serial_number = last_rec.serial_number + 1
                    current_rec.opening_balance = last_rec.sub_total
                    current_rec.sub_total = current_rec.opening_balance + current_rec.amount

            # if cost_rec.amount < 0:
            #     raise UserError("Invalid Amount !!")
            # if len(rec.costing_ids) == 1:
            #     cost_rec.sub_total = cost_rec.amount + cost_rec.opening_balance  # why for loop required
            #     cost_rec.serial_number = 1
            # else:
            #     if cost_rec.serial_number == 0:
            # if len(list) > 1:
            #     sec_last_rec_ids = list[-2]
            # last_rec_id = rec.costing_ids.search([], limit=1, order='id desc')
            #
            # last_rec_id.serial_number = sec_last_rec_ids.serial_number + 1
            # last_rec_id.opening_balance = sec_last_rec_ids.sub_total
            # last_rec_id.sub_total = last_rec_id.opening_balance + last_rec_id.amount
            rec.temp = 0














