{
    'name': 'Purchase Extended',
    'depends': ['purchase'],
    'version': '16.1',
    'data': [
        'views/purchase_views.xml'
    ]
}