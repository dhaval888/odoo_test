from odoo import api, fields, models


class Student(models.TransientModel):
    _name = 'student.wizard'

    first_name = fields.Char()
    last_name = fields.Char()

    def new_records(self):
        self.env['student'].create({'first_name': self.first_name, 'last_name': self.last_name})
