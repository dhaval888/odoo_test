from odoo import api, fields, models


class Customer(models.Model):
    _name = 'customer'
    # _rec_name = 'city'
    # _order = 'city desc, age'
    _description = 'Customer'
    # _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Customer Name", help='Customer')
    age = fields.Char(string='Age', help='Customer Age')
    product_name = fields.Char(string='Product Name', help='Product Name')
    state = fields.Char(string='State', help='Customer State')

    city = fields.Char(compute='_compute_city', store=True)

    mobile_no = fields.Char(string='Mobile No', help='Mobile No')
    pincode = fields.Char(string='pincode', help='Pincode')

    product_ids = fields.Many2many('product', 'customer_product_rel', 'customer_id', 'product_id')

    @api.onchange('name')
    def onchange_name(self):
        for rec in self:
            if rec.name == 'dhaval':
                rec.age = '30'
            if rec.name == 'fenil':
                rec.age = '21'
            if rec.name == 'jeel':
                rec.age = '23'

    @api.depends('name')
    def _compute_city(self):
        for rec in self:
            if rec.name == 'dhaval':
                rec.city = 'amreli'
            if rec.name == 'fenil':
                rec.city = 'rajkot'
            if rec.name == 'jeel':
                rec.city = 'morbi'
