from odoo import api, fields, models


class Teacher(models.Model):
    _name = "teacher"
    _description = "Teacher"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Teacher Name", help="Teacher Name", copy=False)
    age = fields.Char(compute="_compute_age", store=True)
    joining_date = fields.Date(string="Joining Date", help="Joining Date")
    salary = fields.Float()
    gender = fields.Selection(
        selection=[
            ('male', 'Male'),
            ('female', 'Female'),
        ])

    subject = fields.Selection(
        selection=[
            ('science', 'Science'),
            ('math', 'Math'),
            ('hindi', 'Hindi'),
            ('english', 'English'),
        ], help='Select Subject'
    )

    # student_ids = fields.One2many('student', 'teacher_id')

    student_ids = fields.Many2many('student', 'teacher_student_rel', 'teacher_id', 'student_id', string="Student Name")
    department_id = fields.Many2one(comodel_name='department', string="Department Name")

    # teacher_ids = fields.One2many('teacher', 'teacher_student_rel','')

    @api.onchange('subject')
    def onchange_subject(self):
        for record in self:
            if record.subject == 'science':
                record.name = 'will'
            if record.subject == 'math':
                record.name = 'jack'
            if record.subject == 'hindi':
                record.name = 'jeel'
            if record.subject == 'english':
                record.name = 'fenil'

    @api.depends('name')
    def _compute_age(self):
        for record in self:
            if record.name == 'will':
                record.age = '21'
            if record.name == 'jack':
                record.age = '30'
            if record.name == 'jeel':
                record.age = '25'
            if record.name == 'fenil':
                record.age = '35'

    @api.model_create_multi  # self--- teacher() res--- teacher(138,)
    def create(self, vals):
        for vals_rec in vals:
            vals_rec.update({'salary': vals_rec.get('salary', 0.0) + 5000})
        for new_rec in vals:
            new_rec.update({'salary': new_rec.get('salary', 0.0) + 2000})
            if len(new_rec.department_id.student_ids) >= 3:
                new_rec.salary += 20000
        res = super().create(vals)
        for rec in res:
            if rec.gender == 'male':
                rec.name = 'Mr.' + rec.name
            if rec.gender == 'female':
                rec.name = 'Mrs.' + rec.name
            if len(rec.department_id.teacher_ids) >= 3:
                rec.salary += 20000
        return res

    def write(self, vals):  # self--- teacher(135,) res--- True vals--- {'department_id': 1}
        if vals.get('salary'):
            vals.update({'salary': vals.get('salary', 0.0) + 1000})
        if vals.get('department_id'):
            department_id = self.env['department'].browse(vals.get('department_id'))
            if len(department_id.teacher_ids) >= 3:
                vals.update({'salary': vals.get('salary', 0.0) + 20000})
        res = super(Teacher, self).write(vals)
        return res

        # context = self.env.context.copy()
        #       if not context.get('is_updated'):
        #           for rec in self:
        #               if len(rec.section_id.appointment_ids) >= 3:
        #                   context.update({'is_updated': True})
        #                   rec.with_context(context).salary += 20000
        #
        # context = self.env.context.copy()
        # if not context.get('is_updated'):
        #     for rec in self:
        #         if len(rec.department_id.teacher_ids) >= 3:
        #             context.update({'is_updated': True})
        #             rec.with_context(context).salary += 20000

# if rec.gender == 'male':
#              rec.name = 'Mr.' + (rec.name).capitalize()
#          elif rec.gender == 'female':
#              rec.name = 'Mrs.' + (rec.name).capitalize()
