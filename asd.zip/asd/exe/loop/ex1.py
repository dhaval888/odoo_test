for i in range(1,10,2):
    for j in range(1,i+1,2):
        print(j,"",end=" ")
    print("")
