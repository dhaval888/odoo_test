from odoo import api, fields, models


class Department(models.Model):
    _name = 'department'
    _description = 'Department'

    name = fields.Char(string='Department Name', help='Department Name')

    # teacher_ids = fields.One2many('teacher', 'department_id')

    teacher_ids = fields.Many2many('teacher', 'teacher_department_rel', 'teacher', 'department', string="Teacher")
