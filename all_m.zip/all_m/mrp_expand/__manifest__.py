{
    'name': 'MRP Expand',
    'version': '16.1',
    'depends': ['mrp'],
    'data': [
        'seucrity/ir.model.access.csv',
        'views/manufacturing_views.xml'
    ]
}