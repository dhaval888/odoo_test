from odoo import models, fields, api


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    sale_order_count = fields.Char()
    purchase_count = fields.Char()
    manufacturing_count = fields.Char()

    # compute="_compute_smart_button_sale_order")

    def sale_order(self):
        for rec in self:
            self.ensure_one()
            return {
                'type': 'ir.actions.act_window',
                'name': 'Sale Order',
                'view_mode': 'tree,form',
                'view_type': 'form',
                'res_model': 'sale.order',
                'domain': [('partner_id', '=', rec.partner_id.id)],
                'context': "{'create': False}"
            }

    def manufacturing(self):
        for rec in self:
            for record in rec.order_line:
                self.ensure_one()
                return {
                    'type': 'ir.actions.act_window',
                    'name': 'Manufacturing',
                    'view_mode': 'tree,form',
                    'view_type': 'form',
                    'res_model': 'mrp.production',
                    'domain': [('product_id', '=', record.product_id.id)],
                    'context': "{'create': False}"
                }

    def purchase(self):
        for rec in self:
            self.ensure_one()
            return {
                'type': 'ir.actions.act_window',
                'name': 'Sale Order',
                'view_mode': 'tree,form',
                'view_type': 'form',
                'res_model': 'purchase.order',
                'domain': [('partner_id', '=', rec.partner_id.id)],
                'context': "{'create': False}"
            }

    def _compute_sale_count(self):
         for record in self:
             record.sale_order_count = self.env['sale.order'].search_count([('partner_id', '=', record.partner_id.id)])
             record.manufacturing_count = self.env['mrp.production'].search_count(
                 [('product_id', '=', record.order_line.product_id.id)])
             record.purchase_count = self.env['purchase.order'].search_count([('partner_id', '=', record.partner_id.id)])


    #
    # def manu_fac(self):
    #     for sale_rec in self:
    #         sale_rec._compute_smart_button_sale_order()
    #         # sale_ids = self.env['sale.order'].search(['partner_id', '=', sale_rec.partner_id.id])
    #         # print("hhsdf")

# def action_view_delivery(self):
#     return self._get_action_view_picking(self.picking_ids)






