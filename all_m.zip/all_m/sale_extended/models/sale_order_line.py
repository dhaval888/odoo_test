from odoo import api, fields, models, _


class SaleOrderLine(models.Model):
    _name = 'picking.sale.line'
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(required=True, copy=False, readonly=True,
                       default=lambda self: _('New'))
    partner_id = fields.Many2one('res.partner', string="Delivery Address")
    location_id = fields.Many2one('stock.location', string="source_location")

    date = fields.Datetime(string="Scheduled Date", )
    products_availability = fields.Char(string="Product Availability", readonly=True)
    origin = fields.Char(string="Source Document")

    student_id = fields.Many2one('student')

    operation_ids = fields.One2many('picking.line.line', 'order_id')

    # delivery_count = fields.Integer(compute="_compute_sale_count")
    #
    # def _compute_sale_count(self):
    #     for record in self:
    #         record.sale_order_count = self.search_count([('name', '=', record.)])

    selection = fields.Selection(
        selection=[
            ('draft', 'Draft'),
            ('waiting', 'Waiting Another Operation'),
            ('confirm', 'Waiting'),
            ('done', 'Done'),
            ('cancel', 'Cancel'),

        ], default='draft', tracking=True,
    )

    def action_confirm(self):
        for rec in self:
            print(rec)

    def Records(self):
        for rec in self:
            print(rec)

    # def create_invoice(self):
    #     for rec in self:
    #         print(rec)
    #
    # def cancel(self):
    #     for rec in self:
    #         print(rec)
    #
    # def lock(self):
    #     for rec in self:
    #         print(rec)
    #
    # def unlock(self):
    #     for rec in self:
    #         print(rec)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', _('New')) == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code('picking.sale.line') or _("New")
        return super().create(vals_list)


# class Student(models.Model):
#     _inherit = 'student'
#
#     def action_confirm(self):
#         res = super(Student, self).action_confirm()
#         for rec in self:
#
#
#         return res
