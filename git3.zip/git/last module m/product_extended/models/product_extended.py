from odoo import models, fields, api


class ProductExtended(models.Model):
    _inherit = 'product.product'
    _rec_name = 'product_model_name'

    product_model_name = fields.Char(string="Model Name")

    product_model_name_id = fields.Many2one('product.model')

    product_sale_id = fields.Many2one('sale.order')
