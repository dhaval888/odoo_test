from odoo import api, fields, models
from odoo.exceptions import UserError


class MrpWorkorder(models.Model):
    _inherit = 'mrp.workorder'

    next_work_order_id = fields.Many2one('mrp.workorder')

    def open_tablet_view(self):
        res = super(MrpWorkorder, self).open_tablet_view()
        workorder_id = self.search([('id', '=', self.next_work_order_id.id)])
        if workorder_id:
            if workorder_id.state != 'done':
                raise UserError(f"Sorry  \"{workorder_id.name}\"  Process is not Done...")
        return res

        # mo_operation_ids = self.production_id.workorder_ids
        # list = []
        # for rec in mo_operation_ids:
        #     list.append(rec)
        # for index, work_order_rec in enumerate(mo_operation_ids):
        #     if work_order_rec == self and list[0] != self and list[index - 1].state != 'done':
        #         raise UserError(f"Sorry  \"{list[index - 1].name}\"  Process is not Done.....")
        # return res


class MrpProduction(models.Model):
    _inherit = 'mrp.production'

    def action_confirm(self):
        res = super(MrpProduction, self).action_confirm()
        list = []
        for rec in self.workorder_ids:
            list.append(rec)
            if len(list) > 1:
                last_rec = list[-2].id
                rec.write({'next_work_order_id': last_rec})
        return res
