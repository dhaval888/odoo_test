# single inheritence
# class RBI():
#
#     def rbi(self):
#         print("I am a rbi class")
#
# class SBI(RBI):
#     def sbi(self):
#         print("I am a sbi class ")
#
# bank = SBI()
# bank.sbi()
# bank.rbi()
#
#
# #multilevel
#
# class RBI():
#
#     def rbi(self):
#         print("I am a rbi class")
#
# class SBI(RBI):
#     def sbi(self):
#         print("I am a sbi class ")
#
# class BOB(SBI):
#     def bob(self):
#         print("I am a bob class")
#
# bank = BOB()
# bank.bob()
# bank.sbi()
# bank.rbi()
#
# #multiple
#
# class RBI():
#
#     def rbi(self):
#         print("I am a rbi class")
#
# class SBI():
#     def sbi(self):
#         print("I am a sbi class ")
#
# class BOB(RBI,SBI):
#     def bob(self):
#         print("I am a bob class")
#
#
# bank = BOB()
# bank.bob()
# bank.sbi()
# bank.rbi()
#
#
# # #hierarchical
#
# class RBI():
#
#     def rbi(self):
#         print("I am a rbi class")
#
# class SBI(RBI):
#     def sbi(self):
#         print("I am a sbi class ")
#
# class BOB(RBI):
#
#     def __init__(self):
#         print("I Am contructor")
#     def bob(self):
#         print("I am a bob class")
#
#
# bank = BOB()
# bank_sbi = SBI()
# bank_sbi.sbi()
# bank.bob()
# bank.rbi()

# class person():
#
#     def __init__(self,name,age):
#         self.name = name
#         self.age = age
#
#     def printable(self):
#         print(self.name,self.age)
#
# class student(person):
#     def __init__(self,fname,age,year):
#         person.__init__(self,fname,age)
#         self.greduationyear = year
#
#
# p = student('rohit','35', 1989)
# p.printable()
# print(p.greduationyear)

# class RBI():
#
#     def rbi(self):
#         print("I am a rbi class")
#
#
# class SBI(RBI):
#     def sbi(self):
#         print("I am a sbi class ")
#
#
# class BOB():
#
#     def bob(self):
#         print("I am a bob class")
#
#
# class HDFC(SBI, BOB):
#
#     def hdfc(self):
#         print("I am a hdfc Class")
#
#
# bank = HDFC()
# bank.hdfc()
# bank.bob()
# bank.sbi()
# bank.rbi()

# bank.bob()
# bank.rbi()

class RBI():
    def rbi_method(self):
        print("I am a RBI")

class SBI(RBI):

    def sbi_method(self):
        print("I am A SBI method")

class BOB:

    def bob_method(self):
        print("I am a bob method")

class AXIX(SBI,BOB):
    def axix_method(self):
        print("I am A AXIX method")

class HDFC():

    def __init__(self,name,age):
        self.name = name
        self.age = age
        print("I am a hdfc class")


bank = AXIX()
bank.sbi_method()
bank.rbi_method()
bank.bob_method()
bank.axix_method()