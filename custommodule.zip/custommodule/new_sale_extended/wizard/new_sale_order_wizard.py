from importlib.resources import _
from odoo import models, fields, api
from odoo.exceptions import UserError


class NewSaleOrderWizard(models.TransientModel):
    _name = "new.sale.order.wizard"

    amount = fields.Float()
    percentage = fields.Float()

    # @api.model_create_multi
    # def create(self, vals):
    #     print(self)
    #     print(vals)
    #     res = super(NewSaleOrderWizard, self).create(vals)
    #     return res

    def new_method(self):
        for rec in self:
            rec.env.context = dict(self.env.context)
            rec.env.context.update({
                'test': 'test_value',
            })

            a = rec.env.context
            print(rec.env.context)
            id_value = a['active_id']

            sale_id = rec.env['sale.order'].search([('id', '=', id_value)])

            order_id = self.env['account.payment'].search([('order_id', '=', sale_id.id)])

            if rec.amount:
                if rec.amount > sale_id.amount_total:
                    raise UserError(
                        _(f'Your Advance Payment Amount Greter Than Order Total Amount is {sale_id.amount_total}'))
                else:
                    if len(order_id) == 0:
                        a = self.env['account.payment'].create({'amount': rec.amount,
                                                                'partner_id': sale_id.partner_id.id,
                                                                'order_id': sale_id.id})
                        a.action_post()

                if len(order_id) != 0:
                    temp = 0
                    for i in order_id:
                        temp += i.amount_company_currency_signed
                    temp += rec.amount
                    if sale_id.amount_total < temp:
                        raise UserError(
                            _(f'Your Advance Payment Amount Greter Than Order Total Amount is {sale_id.amount_total}'))

                    else:
                        a = self.env['account.payment'].create({'amount': rec.amount,
                                                                'partner_id': sale_id.partner_id.id,
                                                                'order_id': sale_id.id})
                        a.action_post()

            if rec.percentage:
                per = rec.percentage * sale_id.amount_total / 100
                if per > sale_id.amount_total:
                    raise UserError(
                        _(f'Your Advance Payment Amount Greter Than Order Total Amount is {sale_id.amount_total}'))
                else:
                    if len(order_id) == 0:
                        a = self.env['account.payment'].create({'amount': per,
                                                                'partner_id': sale_id.partner_id.id,
                                                                'order_id': sale_id.id})
                        a.action_post()

                if len(order_id) != 0:
                    temp = 0
                    for i in order_id:
                        temp += i.amount_company_currency_signed
                    per = rec.percentage * sale_id.amount_total / 100
                    temp += per
                    if sale_id.amount_total < temp:
                        raise UserError(
                            _(f'Your Advance Payment Amount Greter Than Order Total Amount is {sale_id.amount_total}'))

                    else:
                        a = self.env['account.payment'].create({'amount': per,
                                                                'partner_id': sale_id.partner_id.id,
                                                                'order_id': sale_id.id})
                        a.action_post()

        # else:
        # print(f"amount = {self.amount}, difference == {sale_id.amount_total - self.amount}")
        # payment_id = self.env['account.payment'].search(['', '=', sale_id.])
        # print(payment_id)

        # print(self.env.context)
        # self.env.context.get('id')
        # self.env['account.payment'].create({
        #     'name': str(self.get('Hospital_Name', ''))
        # })

        # if rec.amount:
        #     print(f"amount = {rec.amount}, difference == {sale_id.amount_total - rec.amount}")
