# a = int(5)
# b = int(5.6)
# c = int ("5")
# print(a)
# print(type(a))
# print(b)
# print(type(b))
# print(c)
# print(type(c))
#
# a = float(5)a
# b = float(5.6)
# c = float ("5")
# d = float("5.5")
#
#
# print(a)
# print(type(a))
# print(b)
# print(type(b))
# print(c)
# print(type(c))

#
#
# x = str("15")
# y = str(2)
# z = int("6")
#
# a =str(z)
# print(a)

#
# x =int(1)
# y = int(12.54)
# z = int("45")
#
# print(x)
# print(y)
# print(z)
#
#
# x=float(1)
# y = float(1.2)
# z = float("12")
# a = float("3.2")
#
# print(x)
# print(y)
# print(z)
# print(a)


x = str("10")
y = str(2)
z = str(3.0)


print(x)
print(y)
print(z)