{
    'name': 'Hotel Management',
    'version': '16.1',
    'depends':['mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/admin_views.xml',
        'views/customer_views.xml',
    ]
}