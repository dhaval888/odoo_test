from odoo import api, fields, models


class Student(models.model):
    _inherit = 'sale.order'
