import itertools
from openpyxl import load_workbook

ws = load_workbook('stock.xlsx')
if "CUST_MASTER" and "PRODUCT_MASTER" and "STOCK_MASTER" not in ws.sheetnames:

    ws.create_sheet("cust")
    ws["cust"].append(("ID", "NAME", "TYPE", "PAN"))
    ws.create_sheet("prod")
    ws["prod"].append(("ID", "NAME", 'INCOMING', 'OUTGOING', 'ONAHND'))
    ws.create_sheet("stock")
    ws["stock"].append(("STOCK_ID", "CUST_ID", "PROD_ID", "QUANTITY", "TYPE"))
    ws.save('stock.xlsx')
    cut = ws["cust"].max_row
    pro = ws["prod"].max_row
    sto = ws["stock"].max_row


class Customer_Master:
    id = ws["cust"].max_row
    cust_id = itertools.count(id)
    cust_name = str()
    cust_type = []
    cust_pan = str()
    sheet1 = ws["cust"]

    @classmethod
    def cust(self):
        cust_id_count = next(self.cust_id)
        print("customer id :- ", cust_id_count)
        self.cust_name = input("customer name :- ")

        type_c = int(input("1.customer\n2.vendor\n3.customer,vendor\nchoice option :-"))
        if type_c == 1:
            self.cust_type = ["customer"]
        elif type_c == 2:
            self.cust_type = ["vendor"]
        elif type_c == 3:
            self.cust_type = ["customer", "vendor"]
        else:
            print("enter a valid option.\n")
            self.id = -1
            return Customer_Master().cust()

        self.cust_pan = input("customer pan :- ")
        for k in self.sheet1:
            if self.cust_pan == str(k[3].value):
                print("pan number already exist\n")
                self.id = -1
                return Customer_Master().cust()

        self.sheet1.append((cust_id_count, self.cust_name, ",".join(self.cust_type), self.cust_pan))
        ws.save('stock.xlsx')


class Product_Master(Customer_Master):
    id1 = ws["prod"].max_row
    PROD_ID = itertools.count(id1)
    p_name = str()
    p_incoming = float()
    p_outgoing = float()
    onhand = float()
    sheet2 = ws["prod"]

    def product(self):

        prod_id_count = next(self.PROD_ID)
        print("product id :- ", prod_id_count)
        self.p_name = input("product name :- ")
        for a in self.sheet2:
            if self.p_name == a[1].value:
                print("product is already exist")
                self.id1 = -1
                return Product_Master().product()

        self.sheet2.append((prod_id_count, self.p_name, self.p_incoming, self.p_outgoing, self.onhand))
        ws.save('Cust_Master.xlsx')


class Stock_Master(Product_Master, Customer_Master):
    id2 = ws["prod"].max_row
    s_id = itertools.count(id2)
    PROD_ID = 0
    cust_id = 0
    qty = float()
    s_type = str()
    State = str()
    sheet3 = ws["stock"]

    def stock(self):

        stock_id_count = next(self.s_id)
        print("stock id :- ", stock_id_count)
        self.cust_id = int(input("customer id:- "))
        lis_cust_id = []
        for e in self.sheet1:
            lis_cust_id.append(e[0].value)

        self.PROD_ID = int(input("enter a product id :- "))
        lis_prod_id = []
        for j in self.sheet2:
            lis_prod_id.append(j[0].value)

        self.qty = float(input("enter a quantity  :- "))
        choice_prod_i_o = int(
            input("1.incoming\n2.outgoing\nchose option :- "))

        if choice_prod_i_o == 1:
            for k in self.sheet2:
                if self.PROD_ID == k[0].value:
                    print("hello")
                    # k[2].value += self.qty
                    # k[4].value += self.qty
            self.s_type = "incoming"

        elif choice_prod_i_o == 2:
            for j in self.sheet2:
                if isinstance(j[-1].value, str):
                    continue
                if self.PROD_ID == j[0].value:
                    if self.qty > int(j[-1].value):
                        print('PLEASE CHECK STOCK.\n')
                        self.id2 = -1
                        return Stock_Master().stock()
                    j[3].value += self.qty
                    j[4].value -= self.qty
                self.s_type = "outgoing"
        else:
            self.id2 = -1
            print("Enter valid option")
        self.sheet3.append((stock_id_count, self.cust_id, self.PROD_ID, self.qty, self.s_type))
        ws.save('Cust_Master.xlsx')


while True:
    i = int(input(
        "1.Customer\n2.Product\n3.Stock\n4.Exit\nchoice option :- "))
    if i == 1:
        Customer_Master().cust()
    elif i == 2:
        Product_Master().product()
    elif i == 3:
        Stock_Master().stock()
        ws.close()
    elif i == 4:
        break
