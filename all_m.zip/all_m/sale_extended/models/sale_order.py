from odoo import api, fields, models, _
from datetime import date


class SaleOrder(models.Model):
    _name = 'student'
    _rec_name = 'reference'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char()
    pan_no = fields.Char()

    sale_create_date = fields.Datetime(default=fields.Datetime.now)
    reference = fields.Char(required=True, copy=False, readonly=True,
                            default=lambda self: _('New'))

    teacher_id = fields.Many2one('test', string='teacher')
    active = fields.Boolean(string='Active', default=True)
    record_count = fields.Integer()
    messages = fields.Html(string="Message")
    partner_id = fields.Many2one('res.partner', string="Customer", )
    order_lines = fields.One2many(comodel_name='sale.order.line.extended', inverse_name='order_id', )

    delivery_count = fields.Integer(compute="_compute_sale_count")

    def _compute_sale_count(self):
        for record in self:
            record.delivery_count = 0
            record.delivery_count = self.env['picking.sale.line'].search_count([('origin', '=', record.reference)])

    selection = fields.Selection(
        selection=[
            ('draft', 'Draft'),
            ('confirm', 'Confirm'),
            ('done', 'Done'),
            ('cancel', 'Cancel'),

        ], default='draft', tracking=True,
    )

    def action_confirm(self):
        for rec in self:
            rec.selection = 'confirm'
            sale_line = self.env['picking.sale.line'].create(
                {'partner_id': rec.partner_id.id, 'date': rec.sale_create_date, 'products_availability': 10,
                 'origin': rec.reference})

            self.env['picking.line.line'].create(
                {'order_id': sale_line.id, 'product_id': rec.order_lines.product_id.id, 'demand_qty': 20, 'done': 10,
                 'reserved': 1})

            count = self.env['student'].search([])
            rec.record_count = len(count)

    def create_invoice(self):

        today = date.today()
        new_date = today.strftime("%m/%d/%Y")
        for rec in self:

            rec.selection = 'done'
            sale_line = self.env['invoice'].create(
                {'partner_id': rec.partner_id.id})

    def cancel(self):
        for rec in self:
            rec.selection = 'cancel'

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('reference', _('New')) == _('New'):
                vals['reference'] = self.env['ir.sequence'].next_by_code('student') or _("New")
        return super().create(vals_list)

    def sale_order(self):
        for rec in self:
            self.ensure_one()
            return {
                'type': 'ir.actions.act_window',
                'name': 'Sale Order',
                'view_mode': 'tree,form',
                'view_type': 'form',
                'res_model': 'picking.sale.line',
                'domain': [('origin', '=', rec.reference)],
                'context': "{'create': False}"
            }

    # def write(self, val):
    #     res = super(SaleOrder, self).write(val)
    #     for rec in self:
    #         if rec.order_lines:
    #             rec.order_lines.price = rec.order_lines.product_id.lst_price
    #     return res

    temp_counts = fields.Integer(compute="_compute_subtotal")

    def _compute_subtotal(self):
        for record in self:
            record.temp_counts = 0
            for rec in record.order_lines:
                rec.price = rec.product_id.lst_price
                if rec.product_qty == 0:
                    rec.product_qty = 1

                rec.sub_total = rec.product_qty * rec.product_id.lst_price

    # def _name_get(self):
    #     result = []
    #     for rec in self:
    #         name = rec.reference + rec.name
    #         result.append((rec.id, name))
    #     return result


class ResCountry(models.Model):
    _inherit = 'res.country'

    city_counts = fields.Integer(compute="_compute_city_count")

    @api.depends('currency_id')
    def _compute_city_count(self):
        for rec in self:
            state = self.env['res.country.state'].search([('country_id.name', '=', rec.name)])
            rec.city_counts = len(state)

            '''simple way'''
            # rec.city_counts = len(rec.state_ids)
