from odoo import api, fields, models


class Student(models.Model):
    _name = "student"
    _description = "Student"
    _rec_name = 'first_name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    first_name = fields.Char(string='First Name', help='First Name')
    last_name = fields.Char(string="Last name", help="Last Name")
    division = fields.Char(string='Division', help='division')

    roll_no = fields.Integer(string='Roll No', help='Roll No')

    city = fields.Selection(
        selection=[
            ('rajkot', 'Rajkot'),
            ('jaypur', 'Jaypur'),
            ('shreenagar', 'Shreenagar')
        ]
    )
    state = fields.Selection(
        selection=[
            ('gujarat', 'Gujarat'),
            ('rajasthan', 'Rajasthan'),
            ('kashmir', 'Kashmir')
        ]
    )
    pincode = fields.Char(compute="_compute_pincode", store=True)

    # teacher_id = fields.Many2one(comodel_name='teacher', string='Teacher Name')
    # department_id = fields.Many2one(comodel_name='department', string='Department Name')

    # hieght = fields.Float(string="student hieght", help='Hieght', )
    # date_of_birth = fields.Date(string="Date of birth", help='Date of Birth', )
    # city = fields.Char(string="City", help='City', )
    # state = fields.Char(string="State", help='State', )
    # pincode = fields.Char(string='Pincode', help='Pincode', )
    #
    # mobile = fields.Char(string='Mobile No', help='Mobile No', required=True)
    # attendence_regular = fields.Boolean(string='Attendence Regular', help='Student Active', required=True,
    #                                     tracking=True)
    #
    # gender = fields.Selection(
    #     selection=[
    #         ('male', 'Male'),
    #         ('female', 'Female'),
    #     ], default='male', string='Gender'
    # )

    @api.onchange('state')
    def onchange_state(self):
        for record in self:
            if record.state == "gujarat":
                record.city = "rajkot"
            if record.state == "rajasthan":
                record.city = "jaypur"
            if record.state == "kashmir":
                record.city = "shreenagar"

    @api.depends('state')
    def _compute_pincode(self):
        for record in self:
            if record.state == "gujarat":
                record.pincode = "123456"
            if record.state == "rajasthan":
                record.pincode = "252525"
            if record.state == "kashmir":
                record.pincode = "555562"

