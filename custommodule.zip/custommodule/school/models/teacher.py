from odoo import api, fields, models


class Teacher(models.Model):
    _name = "teacher"
    _description = "Teacher"
    _rec_name = 'name'
    _order = 'join_date desc'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Teacher Name', help='Teacher Name', required=True, tracking=True)
    age = fields.Integer(string='Age', help='Teacher Age', required=True, tracking=True)
    join_date = fields.Date(string="joining Date", help='Joining Date', required=True, tracking=True)
    # hieght = fields.Float(string="Teacher hieght", help='hieght')

    subject = fields.Selection(
        selection=[
            ('math', 'Math'),
            ('hindi', 'Hindi'),
            ('science', 'Science'),
            ('gujrati', 'Gujrati'),
        ],
        string="Subject", default='science', help='subject', tracking=True
    )

    salary = fields.Float()

    subject_code = fields.Char(compute="_compute_subject_code", store=True)

    # student_ids = fields.One2many('student', 'teacher_id')
    # department_id = fields.Many2one(comodel_name='department', string='Department Name')

    @api.onchange('name')
    def onchange_name(self):
        for rec in self:
            if rec.name == 'neha':
                rec.subject = 'math'
            if rec.name == 'dhaval':
                rec.subject = 'hindi'
            if rec.name == 'jeel':
                rec.subject = 'science'
            if rec.name == 'fenil':
                rec.subject = 'gujrati'

    @api.depends('subject')
    def _compute_subject_code(self):
        for rec in self:
            if rec.subject == 'math':
                rec.subject_code = '001'
            if rec.subject == 'hindi':
                rec.subject_code = '002'
            if rec.subject == 'science':
                rec.subject_code = '003'
            if rec.subject == 'gujrati':
                rec.subject_code = '004'
