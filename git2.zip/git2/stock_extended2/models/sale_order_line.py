from odoo import models, api


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    @api.depends('qty_invoiced', 'qty_delivered', 'product_uom_qty', 'state')
    def _compute_qty_to_invoice(self):
        """
        Override The Sale-Order-Line Method For Invoice Policy.
        """
        res = super(SaleOrderLine, self)._compute_qty_to_invoice()
        for line in self:
            if line.state in ['sale', 'done'] and not line.display_type:
                line.qty_to_invoice = line.qty_delivered - line.qty_invoiced
        return res
