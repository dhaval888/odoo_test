from odoo import api, fields, models


class Product(models.Model):
    _name = 'product'
    _rec_name = 'product_name'
    _description = 'Product'
    # _inherit = ['mail.thread', 'mail.activity.mixin']

    product_name = fields.Char(string='Product Name', help='Product Name', )
    mfd = fields.Datetime(string='manufacturing Date', help='Select Manufacturing Date')
    best_before = fields.Date(string='Expiry Date', help='Expiry Date')
    quantity = fields.Integer(string='Quantity', help='Quantity')
    price = fields.Float(compute="_compute_price", store=True)

    customer_ids = fields.Many2many('customer', 'customer_product_rel', 'product_id', 'customer_id')

    total = fields.Float(compute="_compute_total")

    @api.onchange('product_name')
    def onchange_product_name(self):
        for record in self:
            if record.product_name == 'pen':
                record.quantity = 60
            if record.product_name == 'book':
                record.quantity = 100
            if record.product_name == 'bottle':
                record.quantity = 500
            if record.product_name == 'leptop':
                record.quantity = 55
            if record.product_name == 'bet':
                record.quantity = 150

    @api.depends('product_name')
    def _compute_price(self):
        for record in self:
            if record.product_name == 'pen':
                record.price = 10
            if record.product_name == 'book':
                record.price = 40
            if record.product_name == 'bottle':
                record.price = 48
            if record.product_name == 'leptop':
                record.price = 37000
            if record.product_name == 'bet':
                record.price = 600

    @api.depends('total')
    def _compute_total(self):
        for record in self:
            record.total = record.quantity * record.price

