from odoo import api, fields, models


class Student(models.Model):
    _name = "student"
    _description = "Student"
    _rec_name = 'first_name'
    # _order = 'division , roll_no desc'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    first_name = fields.Char(string='First Name',  copy=False, help='First Name',)

    # last_name = fields.Char(string="Last name", required=True, copy=False, help='Last Name')
    division = fields.Char(string='Division', copy=False, help='Division')
    # enrollment_no = fields.Char(string='Enrollment No', help='Enrollment No', required=True)

    roll_no = fields.Char(string='Roll No', copy=False, help='Student Roll no')
    # hieght = fields.Float(string="student hieght", required=True, copy=False, help='Student hieght', tracking=True)

    # date_of_birth = fields.Date(string="Date of birth", required=True, copy=False, help='Student Date Of Birth',
    #                             tracking=True)
    city = fields.Char(string="City", copy=False, help='City', default='Rajkot')
    # state = fields.Char(string="State", copy=False, help="State", )
    # pincode = fields.Integer(string='Pincode', help='Pincode', required=True, copy=False)

    # mobile = fields.Char(string='Mobile No', help='Mobile No', required=True, copy=False)
    # attendence_regular = fields.Boolean(string='Attendence Regular', help='Attendence Regular', tracking=True,
    #                                     required=True, copy=False)

    gender = fields.Selection(
        selection=[
            ('male', 'Male'),
            ('female', 'Female'),
        ], default='male', string='Gender', help='Student Gender'
    )

    teacher_id = fields.Many2one(comodel_name='teacher', string='Teacher Name')
