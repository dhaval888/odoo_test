from odoo import models, fields, api


class HospitalMaster(models.TransientModel):
    _name = "custom.wizard"

    first_name = fields.Char()
    last_name = fields.Char()
    product_id = fields.Many2one('community')

    def new_method(self):
        for rec in self:
            print(rec)
