from odoo import api, fields, models


class Product(models.Model):
    _name = 'custom.product'

    product_name = fields.Char()
    product_price = fields.Float()
    sale_price = fields.Float()
