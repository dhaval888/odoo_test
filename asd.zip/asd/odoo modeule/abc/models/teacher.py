from odoo import api, fields, models


class Teacher(models.Model):
    _name = "teacher"
    _description = "Teacher"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Teacher Name', help='Teacher Name',)
    course_name = fields.Char(string='Course Name', help='Course Name', )

    join_date = fields.Date(string="joining Date", help='Joining Date',)

    subject = fields.Selection(
        selection=[
            ('math', 'Math'),
            ('hindi', 'Hindi'),
            ('science', 'Science'),
            ('gujrati', 'Gujrati'),
        ],
        string="Subject",  help='subject',
    )
    gender = fields.Selection(
        selection=[
            ('male', 'Male'),
            ('female', 'Female'),
        ], String='Select Gender', help='Select Gender', default='male'
    )

    student_ids = fields.One2many('student', 'teacher_id')
    # student_ids = fields.Many2many('student', 'student_teacher_rel', 'student_id', 'teacher_id', string="Student")

    department_id = fields.Many2one(comodel_name='department', string='Department Name')
