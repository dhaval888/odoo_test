{
    'name': 'College Management',
    'version': '16.1',
    'depends': ['mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/student_views.xml',
        'views/teacher_view.xml'
    ]
}
