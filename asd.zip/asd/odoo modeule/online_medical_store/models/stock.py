from odoo import api, fields, models


class Stock(models.Model):
    _name = 'stock'
    _description = 'Stock'
    # _rec_name = 'pincode'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', help='Name', copy=False, required=True, tracking=True)
    mobile_no = fields.Char(string='Mobile No', help='Mobile No', copy=False, required=True, tracking=True)
    email = fields.Char(string='Email', help='Email', copy=False, required=True, tracking=True)
    address = fields.Char(string='Address', help='Address', copy=False, required=True, tracking=True)
    pincode = fields.Char(string='Pincode', help='Pincode', copy=False, required=True, tracking=True)
    # medicine = fields.Char(string='Medicine', help='Medicine', copy=False, required=True, tracking=True)
    sub_total = fields.Char(string='Sub Total', help='Sub Total', copy=False, required=True)

    companies_id = fields.Many2one(comodel_name='companies', string='Companies')
    category_id = fields.Many2one(comodel_name='category', string='Category')

