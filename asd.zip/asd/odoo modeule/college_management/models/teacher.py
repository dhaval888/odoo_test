from odoo import api, fields, models


class Teacher(models.Model):
    _name = "teacher"
    _description = "Teacher"
    _rec_name = "subject"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Teacher Name', help='Teacher Name', copy=False)
    age = fields.Char(string='Age', help='Age', copy=False)

    subject = fields.Selection(
        selection=[
            ('science', 'Science'),
            ('english', 'English'),
            ('gujrati', 'Gujrati'),
            ('math', 'Math'),
        ], default="science"
    )

    city = fields.Char(string="City", help="City", copy=False, default="Rajkot")

    student_ids = fields.Many2many('student', 'student_teacher_rel', 'teacher', 'student', string="Student Name")

