{
    'name': 'Purchase Extended',
    'version': '16.1',
    'depends': ['purchase'],
    'data': [
        'views/purchase_field_views.xml',
    ],
}
