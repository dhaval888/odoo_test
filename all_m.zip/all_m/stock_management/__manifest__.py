{
    'name': 'Stock Management',
    'version': '16.1',
    'depends': ['sale', 'mail'],
    'data': [
        'security/ir.model.access.csv',
        'data/sequence_view.xml',
        'views/setu_customer_views.xml',
        'views/setu_product_views.xml',
        'views/setu_order_views.xml',
    ],
}
