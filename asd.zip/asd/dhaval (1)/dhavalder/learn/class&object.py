class Myclass():
    x = 5


print(Myclass)


class test():
    x = 5


m = Myclass
print(m.x)


class test():

    def __init__(self, name, age):
        self.name = name
        self.age = age


t = test('rohit', 21)
print(t.name)
print(t.age)


class test2():
    name = 'sachin'
    age = 21

    def fun(self):
        print(self.name)
        print(self.age)


t = test2()
print(t.age)
t.fun()


class test():

    def __init__(self, name, age):
        self.name = name
        self.age = age

    def show(self):
        print(self.name + " is cricketer and age is " + self.age)
        print("joursy no is 7")


t = test("ms dhoni", "41")
t.show()


class test():
    def __init__(self, name, company):
        self.name = name
        self.company = company

    def __str__(self):
        return f"my name is {self.name} and my company name is {self.company}"


t = test("virat", "one8")
print(t)


class cat:

    def __init__(self, type, color):
        self.type = type
        self.color = color


n = cat("normal", "black")
s = cat("special", 'white')

print('normal cat details:')
print('type: ', n.type)
print('Color: ', n.color)

print("Special Cat Details:")
print("type: ", s.type)
print("type", s.color)
