from odoo import api, fields, models
from odoo.exceptions import UserError


class MrpWorkorder(models.Model):
    _inherit = 'mrp.workorder'

    next_work_order_id = fields.Many2one('mrp.workorder')

    def open_tablet_view(self):
        res = super(MrpWorkorder, self).open_tablet_view()
        workorder_id = self.search([('id', '=', self.next_work_order_id.id)])
        if workorder_id:
            if workorder_id.state != 'done':
                raise UserError(f"Sorry  \"{workorder_id.name}\"  Process is not Done...")
        return res


class MrpProduction(models.Model):
    _inherit = 'mrp.production'

    # compute = '_compute_add_mo_line'
    # @api.depends('product_id')
    # raw_material_production_id data create time use
    # location_id

    # def _compute_add_mo_line(self):
    #     list = []
    #     if self._origin:
    #         for bom_name in self.move_raw_ids:
    #             list.append(bom_name.temp_display_name)
    #
    #         for mo_product_rec in self.product_id.manufacturing_ids:
    #             if mo_product_rec.display_name not in list:
    #                 new_id = self.env['stock.move'].create(
    #                     {'product_id': mo_product_rec.product_id.id, 'product_uom_qty': mo_product_rec.product_qty,
    #                      'raw_material_production_id': self.id, 'temp_display_name': mo_product_rec.display_name})
    #                 new_id.state = 'done'
    #             # 'raw_material_production_id': self.id,
    #
    #         list = []
    #         for bom_name in self.move_raw_ids:
    #             list.append(bom_name.temp_display_name)
    #             for manu_page_qry in self.product_id.manufacturing_ids:
    #                 if bom_name.temp_display_name == manu_page_qry.display_name:
    #                     bom_name.product_uom_qty = self.product_qty * manu_page_qry.product_qty
    #                     manu_page_qry.product_id.stock_quant_ids[
    #                         0].quantity = manu_page_qry.product_id.qty_available - bom_name.product_uom_qty
    #                     # bom_name.quantity_done =
    #                     # warning_id = self.env['mrp.consumption.warning'].search([('mrp_production_ids', '=', self.id)])
    #                     # if not warning_id:
    #                     #     warning_ids = self.env['mrp.consumption.warning'].create(
    #                     #         {'display_name': 'abc', 'mrp_production_ids': self})
    #                     #
    #                     # warning_line_id = self.env['mrp.consumption.warning.line'].create(
    #                     #     {'product_id': manu_page_qry.product_id.id, 'product_expected_qty_uom': 0,
    #                     #      'mrp_consumption_warning_id': warning_ids.id,
    #                     #      'mrp_production_id': self.id,
    #                     #      'product_consumed_qty_uom': bom_name.product_uom_qty})
    #
    #     self.temp = "0"

    def action_confirm(self):
        res = super(MrpProduction, self).action_confirm()
        list = []
        for rec in self.workorder_ids:
            list.append(rec)
            if len(list) > 1:
                last_rec = list[-2].id
                rec.write({'next_work_order_id': last_rec})
        return res

    def button_mark_done(self):
        res = super(MrpProduction, self).button_mark_done()
        if res == True:
            for mo_product_rec in self.product_id.manufacturing_ids:
                product_filtered = self.move_raw_ids.filtered(lambda x: x.product_id == mo_product_rec.product_id)
                if not product_filtered:
                    new_id = self.env['stock.move'].create(
                        {'product_id': mo_product_rec.product_id.id, 'product_uom_qty': mo_product_rec.product_qty,
                         'raw_material_production_id': self.id, 'temp_display_name': mo_product_rec.display_name})
                    new_id.state = 'done'
                    new_id.product_uom_qty = self.product_qty * mo_product_rec.product_qty
                    new_id.quantity_done = new_id.product_uom_qty
                else:
                    product_filtered.product_uom_qty += self.product_qty * mo_product_rec.product_qty
                    product_filtered.quantity_done = product_filtered.product_uom_qty
        return res

    def process(self):
        res = super(MrpProduction, self).process()
        for manufacture_product_rec in self.product_id.manufacturing_ids:
            mo_product_id = self.move_raw_ids.filtered(lambda x: x.product_id == manufacture_product_rec.product_id)
            if not mo_product_id:
                stock_id = self.env['stock.move'].create({'product_id': manufacture_product_rec.product_id.id,
                                                          'product_uom_qty': manufacture_product_rec.product_qty,
                                                          'raw_material_production_id': self.id,
                                                          'temp_display_name': manufacture_product_rec.display_name})
        return res

# class MrpImmediateProduction(models.TransientModel):
#     _inherit = 'mrp.immediate.production'
#
#     def process(self):
#         res = super(MrpImmediateProduction, self).process()
#         ctx = self.env.context
#         for context in ctx['active_ids']:
#             mrp_production_id = self.env['mrp.production'].search([('id', '=', context)])
#             # mrp_production_id._compute_add_mo_line()
#             # mrp_production_id.action_confirm()
#             # mrp_production_id.button_mark_done()
#         return res


#
# class MrpConsumptionWarning(models.TransientModel):
#     _inherit = 'mrp.consumption.warning'
#
#     @api.model_create_multi
#     def create(self, vals):
#         res = super(MrpConsumptionWarning, self).create(vals)
#         print(res)
#         res.action_confirm()
#         return res
