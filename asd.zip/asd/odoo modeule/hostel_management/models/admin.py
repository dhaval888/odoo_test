from odoo import api, fields, models


class Admin(models.Model):
    _name = 'admin'
    _description = 'Admin'
    _rec_name = 'room_type'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    admin_name = fields.Char(string='Name', help='Name')

    room_type = fields.Selection(
        selection=[
            ('normal', 'Normal'),
            ('A/C', 'A/C'),
            ('royal', 'Royal'),
            ('sweet', 'Sweet'),
        ], string="Room Type"
    )
    capacity = fields.Char(string='Member Capacity', help='Member Capacity')
    price = fields.Char(compute="_compute_price", store=True)
    available = fields.Boolean(string="Room Available")

    # student_ids = fields.One2many('student', 'admin_id')

    student_ids = fields.Many2many('student', 'student_admin_rel', 'student', 'admin', string="Student")

    @api.depends('room_type')
    def _compute_price(self):
        for record in self:
            if record.room_type == 'normal':
                record.price = '1000'
            if record.room_type == 'A/C':
                record.price = '2000'
            if record.room_type == 'royal':
                record.price = '3000'
            if record.room_type == 'sweet':
                record.price = '4000'

    @api.onchange('room_type')
    def onchange_room_type(self):
        for record in self:
            if record.room_type == 'normal':
                record.admin_name = 'dhaval'
            if record.room_type == 'A/C':
                record.admin_name = 'jeel'
            if record.room_type == 'royal':
                record.admin_name = 'fenil'
            if record.room_type == 'sweet':
                record.admin_name = 'jack'
