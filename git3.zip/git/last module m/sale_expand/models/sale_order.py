from odoo import models, fields, api


class SaleOrder(models.Model):
    _inherit = 'sale.order'
#
#     credit_limit = fields.Float(compute="_compute_domain")
#
#     # @api.depends('order_id')
#     def _compute_domain(self):
#         for rec in self:
#             sale_ids = self.env['sale.order'].search(['|', ('amount_total', '<', 1000), ('create_date', '>=' '1-7-2024'), ('name', '=', 'cust1')])
#             print(sale_ids)
#             self.credit_limit = 0

    # domain = ['|', '&', ('name', '=', 'cust1'), ('amount_total', '<', 1000), ('create_date', '>=' '1-7-2024')]
    # domain = ['|', '&', ('name', '=', 'cust2'), ('amount_total', '>', 1000), ('create_date', '<=' '2-7-2024')]

    # domain = ['|', ('amount_total', '<', 1000), ('create_date', '>=' '1-7-2024'), ('name', '=', 'cust1')]
    # domain = ['|', ('amount_total', '>', 1000), ('create_date', '<=' '2-7-2024'), ('name', '=', 'cust2')]


        # @api.depends('id')  # You can also depend on other fields if necessary
        # def _compute_computed_field(self):
        #     for record in self:
        #         # Your computation logic here
        #         record.computed_field = 100  # Example value
        #
        # @api.model
        # def read(self, fields=None, load='_classic_read'):
        #     records = super(SaleOrder, self).read(fields, load)
        #     for record in records:
        #         # Trigger the computation explicitly
        #         record['computed_field'] = self.browse(record['id'])._compute_computed_field()
        #     return records
        #
        #
