for i in range(10,0,-2):
    for j in range(2,i+1):
        if j % 2 == 0:
            print(j,"",end=" ")
    print("")
