from odoo import api, fields, models


class Student(models.Model):
    _name = 'student'
    _description = 'Student'
    _rec_name = 'student_name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    student_name = fields.Char(string="Student Name", help="Student Name")
    age = fields.Char(compute="_compute_age", store=True)
    book_name = fields.Char(string="Book Name", help="Book Name")

    start_date = fields.Date(string="Start Date", help="Start Date")
    submit_date = fields.Date(string="Book Submit Date", help="Book submit Date")

    admin_id = fields.Many2one(comodel_name="admin", string="Admin Name")

    @api.depends('student_name')
    def _compute_age(self):
        for rec in self:
            if rec.student_name == 'dhaval':
                rec.age = '32'
            if rec.student_name == 'jeel':
                rec.age = '26'
            if rec.student_name == 'fenil':
                rec.age = '23'
            if rec.student_name == 'riken':
                rec.age = '24'


