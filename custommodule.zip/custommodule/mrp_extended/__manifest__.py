{
    'name': 'MRP Extended',
    'version': '16.1',
    'depends': ['sale','sale_management','mrp'],
    'data': [
        'views/sale_order.xml',
        # 'views/mrp_production.xml',

    ],
}