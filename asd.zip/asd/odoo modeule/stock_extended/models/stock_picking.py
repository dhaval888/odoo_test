from odoo import models, api


class StockPicking(models.Model):
    _inherit = 'stock.picking'
    _description = 'Stock Picking'

    @api.onchange('move_ids_without_package')
    def onchange_sale_id(self):
        for records in self:
            for moves in records.move_ids_without_package:
                if moves.product_uom_qty == moves.quantity_done:
                    self.env['stock.move.line'].search([('picking_id', '=', self._origin.id)]).write(
                        {'qty_done': moves.quantity_done})
                    self._origin.button_validate()

                if moves.product_uom_qty != moves.quantity_done:
                    # backorder_confirmation = self.env['stock.backorder.confirmation'].create(
                    #     {'pick_ids': records.ids, 'show_transfers': False})

                    # backorder_confirmation_line = self.env['stock.backorder.confirmation.line'].create({
                    #     'backorder_confirmation_id': backorder_confirmation.id,
                    #     'picking_id': backorder_confirmation.pick_ids.id,
                    #     'to_backorder': True})

                    self.env['stock.move.line'].search([('picking_id', '=', self._origin.id)]).write(
                        {'qty_done': moves.quantity_done})

                    self._origin.button_validate()
                    # backorder_confirmation.with_context(button_validate_picking_ids=self.ids).process()

                sale_ids = self.env['sale.order'].browse(records.sale_id.id)
                self.env['sale.advance.payment.inv'].create(
                    {'sale_order_ids': sale_ids, 'company_id': sale_ids.company_id.id,
                     'advance_payment_method': 'delivered'})

                sale_ids._create_invoices()
                invoice_ids = sale_ids.mapped('invoice_ids') if sale_ids.invoice_ids else 0
                account_moves = self.env['account.move'].search([('id', 'in', invoice_ids.ids)])

    # def button_validate(self):
    #     global backorder_confirmation
    #     for records in self:
    #         for moves in records:
    # if moves.product_uom_qty == moves.quantity_done:
    #     self.env['stock.move.line'].search([('picking_id', '=', self._origin.id)]).write(
    #         {'qty_done': moves.quantity_done})
    #     self._origin.button_validate()
    # sale_ids = self.env['sale.order'].browse(records.sale_id.id)

    # if moves.product_uom_qty != moves.quantity_done:
    #     backorder_confirmation = self.env['stock.backorder.confirmation'].create(
    #         {'pick_ids': records.ids, 'show_transfers': False})
    #
    #     backorder_confirmation_line = self.env['stock.backorder.confirmation.line'].create({
    #         'backorder_confirmation_id': backorder_confirmation.id,
    #         'picking_id': backorder_confirmation.pick_ids.id,
    #         'to_backorder': True})
    #
    #     self.env['stock.move.line'].search([('picking_id', '=', self._origin.id)]).write(
    #         {'qty_done': moves.quantity_done})
    #
    # self._origin.button_validate()
    # backorder_confirmation.with_context(button_validate_picking_ids=self.ids).process()

    # sale_ids = self.env['sale.order'].browse(records.sale_id.id)
    # self.env['sale.advance.payment.inv'].create({'sale_order_ids': sale_ids, 'company_id': sale_ids.company_id.id, 'advance_payment_method': 'delivered'})
    #
    # invoice_ids = sale_ids.mapped('invoice_ids') if sale_ids.invoice_ids else 0
    # account_moves = self.env['account.move'].search([('id', 'in', invoice_ids.ids)])
    # sale_ids._create_invoice()
    #
    # backorder_confirmation = self.env['stock.backorder.confirmation.line'].create({
    #     'backorder_confirmation': backorder_confirmation.id,
    # })
    #     res = super(StockPicking, self).button_validate()
    #     return res

# class Stock(models.TransientModel):
#     _inherit = 'stock.backorder.confirmation'
#     _description = 'Stock Backorder Confirmation'

# def process(self):
#     print(self)
#     res = super(Stock, self).process()
#     print(res)
#     return res

# @api.model_create_multi
# def create(self, vals):
#     for rec_vals in vals:
#         for new in rec_vals:
#             print(new)
#             print(rec_vals)
#     res = super(Stock, self).create(vals)
#     print(res)
#     return res

# def write(self, vals):
#     print("up")
#     res = super(StockPicking, self).write(vals)
#     print("down")
#     return res

# def button_validate(self):
#     res = super(StockPicking, self).button_validate()
#     return res

# def process(self):
#     # self.env['stock.move.line'].search([('picking_id', '=', self._origin.id)]).write(
#     #     {'qty_done': moves.quantity_done})
#
#     sale_ids = self.env['sale.order'].browse(self.sale_id.id)
#     self.env['sale.advance.payment.inv'].create({'sale_order_ids': sale_ids, 'company_id': sale_ids.company_id.id,
#                                                  'advance_payment_method': 'delivered'})

#     sale_ids._create_invoices()
#     invoice_ids = sale_ids.mapped('invoice_ids') if sale_ids.invoice_ids else 0
#     account_moves = self.env['account.move'].search([('id', 'in', invoice_ids.ids)])
#     res = super(StockPicking, self).process()
#
# return res

# @api.onchange('move_ids_without_package')
# def onchange_sale_id(self):
#     for records in self:
#         for moves in records.move_ids_without_package:
#             if moves.product_uom_qty == moves.quantity_done:
#                 self.env['stock.move.line'].search([('picking_id', '=', self._origin.id)]).write(
#                     {'qty_done': moves.quantity_done})
#                 self._origin.button_validate()
#
#             if moves.product_uom_qty != moves.quantity_done:
#                 backorder_confirmation = self.env['stock.backorder.confirmation'].create(
#                     {'pick_ids': records.ids, 'show_transfers': False})
#
#                 backorder_confirmation_line = self.env['stock.backorder.confirmation.line'].create({
#                     'backorder_confirmation_id': backorder_confirmation.id,
#                     'picking_id': backorder_confirmation.pick_ids.id,
#                     'to_backorder': True})
#
#                 self.env['stock.move.line'].search([('picking_id', '=', self._origin.id)]).write(
#                     {'qty_done': moves.quantity_done})
#
#                 self._origin.button_validate()
#                 backorder_confirmation.with_context(button_validate_picking_ids=self.ids).process()
#
#             sale_ids = self.env['sale.order'].browse(records.sale_id.id)
#             self.env['sale.advance.payment.inv'].create(
#                 {'sale_order_ids': sale_ids, 'company_id': sale_ids.company_id.id,
#                  'advance_payment_method': 'delivered'})
#
#             sale_ids._create_invoices()
#             invoice_ids = sale_ids.mapped('invoice_ids') if sale_ids.invoice_ids else 0
#             account_moves = self.env['account.move'].search([('id', 'in', invoice_ids.ids)])

# for account_moves in account_moves:
#     if account_moves.state == 'draft':
#         account_moves.action_post()


# class Stock(models.TransientModel):
#     _inherit = 'stock.backorder.confirmation'
#     _description = 'Stock Backorder Confirmation'
#
#     def process(self):
#         res = super(Stock, self).process()
#
#         print("down")
#         return res
