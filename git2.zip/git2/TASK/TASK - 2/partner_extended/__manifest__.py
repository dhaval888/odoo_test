{
    'name': 'Partner Extended',
    'version': '16.1',
    'depends': ['sale_management', 'contacts'],
    'data': [
        # 'views/res_partner_view.xml'
    ]
}