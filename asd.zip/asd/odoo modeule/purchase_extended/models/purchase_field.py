from odoo import fields, models


class PurchaseField(models.Model):
    _inherit = 'purchase.order'

    currency_into_rupee = fields.Float(string="Currency To Rupee", compute="_compute_currency_into_rupee")

    def _compute_currency_into_rupee(self):
        for rec in self:
            rec.currency_into_rupee = 80
