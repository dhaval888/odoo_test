from odoo import fields, models, api


class Doctor(models.Model):
    _name = "hospital.data"

    name = fields.Char(required=True)

    # address fields
    location = fields.Char()
    address_original_first_line = fields.Char()
    district = fields.Char()
    pincode = fields.Char()
    telephone = fields.Char()
    state_id = fields.Integer()
