from odoo import api, fields, models


class MrpProduction(models.Model):
    _inherit = 'mrp.production'

    order_id = fields.Many2one(comodel_name='sale.order')

class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    mrp_id = fields.Many2one(comodel_name='mrp.production')

# class SaleOrderLine(models.Model):
#     _inherit = 'sale.order'
#
#     sale_order_line_id = fields.Many2one(comodel_name='sale.order.line')