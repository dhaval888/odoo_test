from odoo import api, fields, models


class Medicine(models.Model):
    _name = 'medicine'
    _description = 'Medicine'
    _rec_name = 'name'
    _order = 'medicine_category'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Medicine Name', help='Medicine Name', required=True, copy=False)
    medicine_category = fields.Char(string='Medicine Category', help='Medicine Category', required=True, copy=False,
                                    tracking=True)
    medicine_companies = fields.Char(string='Medicine Companies', help='Medicine Companies', required=True, copy=False,
                                     tracking=True)
    pack_per_unit = fields.Char(string='Package of Unit', help='Package of Unit', required=True, copy=False,
                                tracking=True)
    price_per_unit = fields.Char(string='Price per Unit', help='Price of Unit', required=True, copy=False,
                                 tracking=True)
