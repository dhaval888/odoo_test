{
    'name': 'Sale Extended',
    'version': '16.1',
    'depends': ['sale_management', 'base'],
    'data': [
        'security/ir.model.access.csv',
        'wizard/import_record_view.xml',
        'views/res_partner_views.xml',
        # 'views/sale_order_view.xml',
    ],
}