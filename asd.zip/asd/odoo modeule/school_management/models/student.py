from odoo import api, fields, models
from datetime import date, time
import datetime


class Student(models.Model):
    _name = "student"
    _description = "Student"
    _rec_name = 'first_name'
    # _order = 'division desc'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    first_name = fields.Char(string='First Name', help='First Name', tracking=True)
    last_name = fields.Char(string="Last name", copy=False, help='Last Name')

    division = fields.Char(string='Division', copy=False, help='Division')

    roll_no = fields.Integer(string='Roll No', copy=False, help='Student Roll no', tracking=True)

    date_of_birth = fields.Date(string="Date of Birth", copy=False, help='Student Date Of Birth',
                                tracking=True)

    year = fields.Integer(compute="_compute_year", store=True)
    month = fields.Integer()
    day = fields.Integer()

    city = fields.Selection(
        selection=[
            ('rajkot', 'Rajkot'),
            ('mumbai', 'Mumbai'),
            ('jaypur', 'Jaypur'),
            ('chandigarh', 'Chandigarh'),
            ('lucknow', 'Lucknow'),
            ('thiruvananthapuram', 'Thiruvananthapuram'),
        ], help='State',
    )

    state = fields.Selection(
        selection=[
            ('gujarat', 'Gujarat'),
            ('maharasthra', 'Maharasthra'),
            ('rajasthan', 'Rajasthan'),
            ('punjab', 'Punjab'),
            ('up', 'UP'),
            ('kerala', 'Kerala'),
        ], help='State',
    )

    pincode = fields.Char(compute="_compute_pincode", store=True)

    mobile = fields.Char(string='Mobile No', help='Mobile No', copy=False)
    attendence_regular = fields.Boolean(string='Attendence Regular', help='Attendence Regular', copy=False)

    gender = fields.Selection(
        selection=[
            ('male', 'Male'),
            ('female', 'Female'),
        ], default='male', string='Gender', help='Student Gender',
    )

    teacher_id = fields.Many2one(comodel_name='teacher', string='Teacher')

    department_id = fields.Many2one(comodel_name='department', string='Department Name')

    @api.onchange('state')
    def onchange_state(self):
        for record in self:
            if record.state == 'gujarat':
                record.city = 'rajkot'
            if record.state == 'maharasthra':
                record.city = 'mumbai'
            if record.state == 'rajasthan':
                record.city = 'jaypur'
            if record.state == 'punjab':
                record.city = 'chandigarh'
            if record.state == 'up':
                record.city = 'lucknow'
            if record.state == 'kerala':
                record.city = 'thiruvananthapuram'

    @api.onchange('city')
    def onchange_city(self):
        for record in self:
            if record.city == 'rajkot':
                record.state = 'gujarat'
            if record.city == 'mumbai':
                record.state = 'maharasthra'
            if record.city == 'jaypur':
                record.state = 'rajasthan'
            if record.city == 'chandigarh':
                record.state = 'punjab'
            if record.city == 'lucknow':
                record.state = 'up'
            if record.city == 'thiruvananthapuram':
                record.state = 'kerala'

    @api.depends('city')
    def _compute_pincode(self):
        for record in self:
            if record.city == 'rajkot':
                record.pincode = '562345'
            if record.city == 'mumbai':
                record.pincode = '569845'
            if record.city == 'jaypur':
                record.pincode = '325645'
            if record.city == 'chandigarh':
                record.pincode = '569845'
            if record.city == 'lucknow':
                record.pincode = '326520'
            if record.city == 'thiruvananthapuram':
                record.pincode = '305482'

    @api.depends('date_of_birth')
    def _compute_year(self):
        today = date.today()
        for record in self:
            if record.date_of_birth:
                record.year = today.year - record.date_of_birth.year
            else:
                record.year = 0

        today_month = date.today()
        for record in self:
            if record.date_of_birth:
                if today_month.month >= record.date_of_birth.month:
                    a = today_month.month - record.date_of_birth.month
                    record.month = a
                elif today_month.month <= record.date_of_birth.month:
                    b = record.date_of_birth.month - today_month.month
                    record.month = b

        today_day = date.today()
        for record in self:
            if record.date_of_birth:
                if today_day.day >= record.date_of_birth.day:
                    a = today_day.day - record.date_of_birth.day
                    record.day = a
                elif today_day.day <= record.date_of_birth.day:
                    b = record.date_of_birth.day - today_day.day
                    record.day = b

        x = datetime.datetime.now()
        print(x.strftime("%X"))
        x = datetime.datetime.now()
        print(x)

    # @api.onchange('state', 'city')
    # def onchange_state(self):
    #     for record in self:
    #         if record.state == 'gujarat':
    #             record.city = 'rajkot'
    #         elif record.state == 'maharasthra':
    #             record.city = 'mumbai'
    #         elif record.state == 'rajasthan':
    #             record.city = 'jaypur'
    #
    #         else:
    #             if record.city == 'rajkot':
    #                 record.state = 'gujarat'
    #
    #             elif record.city == 'mumbai':
    #                 record.state = 'maharasthra'
    #
    #             elif record.city == 'jaypur':
    #                 record.state = 'rajasthan'

# if record.state == 'punjab':
#     record.city = 'chandigarh'
# else:
#     if record.city == 'punjab':
#         record.state = 'rajasthan'
#
# if record.state == 'up':
#     record.city = 'lucknow'
# else:
#     if record.city == 'lucknow':
#         record.state = 'up'
#
# if record.state == 'kerala':
#     record.city = 'thiruvananthapuram'
# else:
#     if record.city == 'thiruvananthapuram':
#         record.state = 'kerala'
