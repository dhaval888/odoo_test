{
    'name': 'Sequence Extended',
    'version': '16.1',
    'depends': ['l10n_latam_account_sequence', 'base'],
    'data': [
        'views/account_move_views.xml',
    ],
}