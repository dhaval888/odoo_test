# t = (10,20,30,40)
# print(len(t))
# t = (10,)
# print(type(t))
#
# t1 = ("apple", "banana", "cherry")
# t2 = (1, 5, 7, 9, 3)
# t3 = (True, False, False)
# print(t1,t2,t3)
#
# t = tuple((10,20,30))
# print(t)
#
# t = ("apple", "banana", "cherry", "orange", "kiwi", "melon", "mango")
# print(t[-4:-1])
#
# t = ("apple", "banana", "cherry", "orange", "kiwi", "melon", "mango")
# print(t[2:])
#
# t = ("apple", "banana", "cherry")
# if "apple" in t:
#   print("Yes, 'apple' is in the fruits tuple")

# t = (10, 20, 30, 40)
# a = list(t)
# a[2] = 99
# a.append(100)
# t = tuple(a)
# print(t)
# print(type(t))


# t = (10, 20, 30, 40)
# x = (202,)
# t = t+x
# x = list(t)
# x.remove(40)
# t = tuple(x)
# print(t)

# t = ("apple", "banana", "cherry")
# (a, b, c) = t
# print(a,b,c)
# print(type(a))
#
# t = ("apple", "banana", "cherry")
# (a, *b) = t
# print(b)

# t = ("apple", "banana", "cherry")
#
# for i in range(len(t)):
#     print(t[i])
#
# i = 0
#
# while i < len(t):
#
#     print(t[i])
#
#     i = i + 1

# t = ("apple", "banana", "cherry")
# t1 = (10,20,30,40)
#
# t2 = t+t1
# print(t2)
#
# mytuple = t2*2
# print(mytuple)
#
# tuple = mytuple.count(10)
# print(tuple)
# tuple = mytuple.index(20)
# print(tuple)
#
# set = {"apple", "banana", "cherry","apple"}
# print(set)
# set = {"apple", "banana", "cherry","apple",True,1,2}
# print(set)
#
# set = {"apple", "banana", "cherry","apple",True,False,0,2}
# print(set)
# set = {"apple", "banana", "cherry","apple",True,False,0,2}
# print(len(set))
#
# set1 = {"apple", "banana", "cherry"}
# set2 = {1, 5, 7, 9, 3}
# set3 = {True, False, False}
# print(set1,set2,set3)
# set1 = {"abc", 34, True, 40, "male"}
# print(set1)


# set = {"apple", "banana", "cherry","apple"}
# for i in set:
#     print(i)
# print("apple" in  set)
#
# set = {"apple", "banana", "cherry", "apple"}
# lst = [10,20,30,40]
# set.update(lst)
# print(set)
#
#
# set = {"apple", "banana", "cherry", "apple"}
# set.remove("banana")
# print(set)
#
#
# set = {"apple", "banana", "cherry"}
# set.discard("banana")
# print(set)
#
#
# set = {"apple", "banana", "cherry"}
# x = set.pop()
# print(x)
# print(set)
#
#
# set = {"apple", "banana", "cherry"}
# set.clear()
# print(type(set))

# s1 = {"apple", "banana", "cherry"}
# del s1
# print(s1)

# thisset = {"apple", "banana", "cherry"}
#
# for x in thisset:
#   print(x)

# s = {"apple", "banana", "cherry"}
# s1 = {10,20,30,40}
# a = s.union(s1)
# print(a)


# s = {"apple", "banana", 10,"cherry"}
# s1 = {10,20,30,40,"apple"}
# s.update(s1)
# print(s)

# s = {"apple", "banana", 10,"cherry"}
# s1 = {10,20,30,40,"apple"}
# x= s.intersection_update(s1)
# print(s)
#
# s = {"banana", 10,"cherry"}
# s1 = {10,20,30,40,"apple"}
# x= s1.intersection(s)
# print(s1)
#
# x = {"apple", "banana", "cherry"}
# y = {"banana", "microsoft", "facebook"}
#
# z = x.isdisjoint(y)
#
# print(z)



x = {"a", "b", "c"}
y = {"f", "e", "d", "c", "b", "a"}

z = x.issubset(y)

print(z)