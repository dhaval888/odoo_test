from uaclient.cli import action_config
from xlwt.ExcelMagic import ptgInt

from odoo import api, fields, models, _


class SaleOrder(models.Model):
    _name = 'picking.line.line'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char()
    demand_qty = fields.Integer(string="Demand")
    reserved = fields.Float('Reserved')
    done = fields.Char(string="Done")

    picking_line_id = fields.Many2one('picking.sale.line')
    product_id = fields.Many2one('product.product')

    order_id = fields.Many2one('picking.sale.line')


# class Student(models.Model):
#     _inherit = 'student'
#
#     def action_confirm(self):
#         res = super(Student, self).action_confirm()
#         picking_line_line_ids = self.env['picking.sale.line'].search([('origin', '=', self.reference)], limit=1)
#
#         self.env['picking.line.line'].create(
#             {'order_id': picking_line_line_ids.id, 'demand_qty': 20, 'done': 10})
#
#         print(picking_line_line_ids.operation_ids)
#         # = rec.product_id.id
#         return res
