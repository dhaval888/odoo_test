# d = {"name": "rohit", "age": 35, "run": 264,"age":20}
# print(d)
# d = {"name": "rohit", "age": 35, "run": 264,"age":20}
# print(len(d))
#
# d = {"name": "rohit", "age": 35, "run": 264,"recodes": [265, 45, 12, 451]}
# print(d)

#
# d = dict(name = "John", age = 36, country = "Norway")
# print(d)

# d = {"name": "rohit", "age": 35, "run": 264,"age":20}
# x = d["name"]
# print(x)
# x = d.get("name")
# print(x)
# x = d.keys()
# print(x)

# d = {"name": "rohit", "age": 35, "run": 264}

# d["bet_brand"] = "CEAT"
# print(d.values())
# print(d.keys())
# print(d)
#
# car = {
#     "brand": "Ford",
#     "model": "Mustang",
#     "year": 1964
# }
# x = car.values()
# print(x)
# car["color"] = "red"
# print(x)
#
# d = {"name": "rohit", "age": 35, "run": 264}
# print(d.items())
# d["recode"] = 465,454,120,451
#
# if ("recode") in d:
#     print("yes")
# else:
#     print("no")
# print(d)


# d = {"name": "rohit", "age": 35, "run": 264}
# d.update({"color": "red"})
# print(d)
#
# d = {"name": "rohit", "age": 35, "run": 264}
# d.update({"color": "red"})
# d.popitem()
# del d["age"]
# print(d)
# d.clear()
# print(d)

#
# for x in d:
#   print(x)
#
# for x in d:
#   print(d[x])

# for i in d.keys():
#     print(i)
#
# for i in d.values():
#     print(i)
#
# for i,j in d.items():
#     print(i,j)
#
# for i in d.items():
#     print(i)

# d = {"name": "rohit", "age": 35, "run": 264}
#
# a = d.copy()
# print(d)
#
# b = dict(d)
# print(b)

cricket = {
    "players1": {"name": "rohit", "age": 36, "run": 264},
    "players2": {"name": "virat", "age": 35, "run": 150},
    "players3": {"name": "sachin", "age": 44, "run": 100}
}
print(cricket["players2"]["name"])

players1 = {"name": "rohit", "age": 36, "run": 264}
players2 = {"name": "virat", "age": 35, "run": 150}
players3 = {"name": "sachin", "age": 44, "run": 100}

cricket = {
    "players1": players1,
    "players2": players2,
    "playear3": players3
}

print(cricket)

a = {"a": 10, "b": 20, "x": 5}
b = {"a": 5, "c": 20, "d": 20}
