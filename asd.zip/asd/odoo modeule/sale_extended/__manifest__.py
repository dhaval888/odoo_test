{
    'name': 'Sale Extended',
    'version': '16.1',
    'depends': ['sale_management'],
    'data': [
        # 'views/sale_order_views.xml',
    ]
}
