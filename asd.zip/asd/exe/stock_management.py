# def cust(self):
#     for i in range(1, 3):
#         id = int(input("customer id : "))
#         if id in id_list:
#             print(id, "id is already exist")
#         else:
#             id_list.append(id)
#
#         name = str(input("customer name : "))
#         name_list.append(name)
#
#         temp = str(input("enter customer type :"))
#
#         # if temp == "customer" and temp == "vendor":
#         c_type.append(temp)
#         # else:
#         #     print("only two values are supported \"customer\" and \"vendor\"")
#
#         pan = str(input("enter customer pan no.: "))
#         if pan in pan_list:
#             print("pan number is already exist")
#         else:
#             pan_list.append(pan)
#     print(id_list, name_list, c_type, pan_list)
# def product(self):
#     for i in range(1,):
#         id = int(input("product id :"))
#         if id in p_id:
#             print(id,"id is already exist")
#         else:
#             p_id.append(id)
#
#         p_name = str(input("enter a product name :"))
#         if p_name in pname_list:
#             print(p_name,"name is already exist")
#         else:
#             pname_list.append(p_name)
#
#         p_incoming = float(input("enter incoming :"))
#         p_incoming_list.append(p_incoming)
#
#         p_outgoing = float(input("enter outgoing :"))
#         p_outgoing_list.append(p_outgoing)
#
#         p_onhand = p_incoming - p_outgoing
#         p_onhand_list.append(p_onhand)
p_id = []
pname_list = []
p_incoming_list = []
p_outgoing_list = []
p_onhand_list = []
a = 1002112114561

id_list = []
name_list = []
c_type = []
pan_list = []

stock_id_list = []
product_id_list = []
customer_id_list = []
product_qty_list = []
product_type_list = []
temp = []


class Customer_master:

    @staticmethod
    def cust():
        id = int(input("customer id : "))
        if id not in id_list:
            id_list.append(id)
            name = str(input("customer name : "))
            name_list.append(name)
            type = str(input("enter type \"customer or vendor\" :"))
            if type == 'customer' or type == 'vendor' or type == 'customer,vendor' or type == 'vendor,customer':
                c_type.append(type)
                pan = str(input("enter customer pan no. : "))
                if pan not in pan_list:
                    pan_list.append(pan)
                else:
                    c_type.pop()
                    name_list.pop()
                    id_list.pop()
                    print("pan number is already exist")
            else:
                name_list.pop()
                id_list.pop()
                print("only two values are supported \"customer\" and \"vendor\"")
        else:
            print(id, "id is already exist")


class Product_master(Customer_master):

    @staticmethod
    def product():
        global p_onhand
        global p_incoming, p_outgoing
        id = int(input("product id :"))
        if id not in p_id:
            p_id.append(id)
            p_name = str(input("enter a product name :"))
            if p_name not in pname_list:
                pname_list.append(p_name)
                p_incoming = float(input("enter incoming :"))
                p_incoming_list.append(p_incoming)
                p_outgoing = float(input("enter outgoing :"))

                p_onhand = p_incoming - p_outgoing
                p_onhand_list.append(p_onhand)

                if p_outgoing <= p_incoming:
                    p_outgoing_list.append(p_outgoing)
                else:
                    p_incoming_list.pop()
                    pname_list.pop()
                    p_id.pop()
                    print("stock is not available")
            else:
                p_id.pop()
                print(p_name, "name is already exist")
        else:
            print(id, "id is already exist")

    @staticmethod
    def stock():
        global p_incoming_list, p_outgoing_list, p_onhand_list, i, p_onhand
        global p_incoming, p_outgoing
        global customer_qty_list, product_type, product_qty
        stock_id = int(input("enter stock id : "))
        stock_id_list.append(stock_id)
        product_id = int(input("enter a product id : "))
        if product_id in p_id:
            product_id_list.append(product_id)
            customer_id = int(input("enter a customer id :"))
            if customer_id in id_list:
                customer_id_list.append(customer_id)
                product_qty = float(input("enter a quantity : "))
                product_qty_list.append(product_qty)
                temp.append(product_qty)
                product_type = str(input("enter a type \"incoming\" or \"outgoing\" : "))
                if product_type == "incoming" or product_type == "outgoing":
                    product_type_list.append(product_type)

                    for i in product_id_list:
                        pass
                    if product_type == 'incoming':
                        p_incoming_list[i - 1] += temp[0]
                        p_onhand_list[i - 1] += temp[0]

                    elif product_type == 'outgoing':

                        if p_incoming_list[i - 1] >= p_outgoing_list[i - 1] + temp[0]:
                            p_outgoing_list[i - 1] += temp[0]
                            p_onhand_list[i - 1] -= temp[0]
                        else:
                            # p_outgoing_list[i - 1] -= temp[0]
                            # p_onhand_list[i - 1] += temp[0]
                            stock_id_list.pop()
                            product_id_list.pop()
                            customer_id_list.pop()
                            product_qty_list.pop()
                            product_type_list.pop()
                            print("stock are not available")

                    temp.clear()

                else:
                    stock_id_list.pop()
                    product_id_list.pop()
                    customer_id_list.pop()
                    product_qty_list.pop()
                    print("only two type are available \"incoming\" and \"outgoing\"")

            else:
                product_id_list.pop()
                stock_id_list.pop()
                print(customer_id, "this id not exist")
        else:
            stock_id_list.pop()
            print(product_id, "this id is not exist")


p = Product_master()
for i in range(1, a):
    print("1 Customer")
    print("2 Product")
    print("3 check")
    print("4 Stock")
    print("5 exit")
    n = int(input("enter a number "))
    if n == 1:
        p.cust()

    elif n == 2:
        p.product()
    elif n == 3:
        # x = int(input("enter a product id : "))
        # if x in p_id:
        #     print(p_onhand_list[x - 1])
        # else:
        #     print(x, "this id is not exist")

        print('customer id =', id_list, 'customer name =', name_list, 'type =', c_type, 'customer pan =', pan_list)
        print('Product id =', p_id, 'product name =', pname_list, 'incoming =', p_incoming_list, 'outgoing',
              p_outgoing_list,
              'onhand =', p_onhand_list)
        print('stock id =', stock_id_list, 'product id =', product_id_list, 'customer id =', customer_id_list, 'qty =',
              product_qty_list, 'type =', product_type_list)
    elif n == 4:
        p.stock()
    elif n == 5:
        break

print('customer id =', id_list, 'customer name =', name_list, 'type =', c_type, 'customer pan =', pan_list)
print('Product id =', p_id, 'product name =', pname_list, 'incoming =', p_incoming_list, 'outgoing', p_outgoing_list,
      'onhand =', p_onhand_list)
print('stock id =', stock_id_list, 'product id =', product_id_list, 'customer id =', customer_id_list, 'qty =',
      product_qty_list, 'type =', product_type_list)
