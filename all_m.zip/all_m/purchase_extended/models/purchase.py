from odoo import api, fields, models


class SaleOrder(models.Model):
    _inherit = 'purchase.order.line'

    product_id = fields.Many2one()
