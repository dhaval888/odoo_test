from odoo import api, fields, models
from odoo.exceptions import UserError


class SetuProduct(models.Model):
    _name = 'setu.product'
    _rec_name = 'product_name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    product_name = fields.Char()
    reference_number = fields.Char()

    incoming = fields.Float()
    outgoing = fields.Float()
    onhand = fields.Float()

    @api.model_create_multi
    def create(self, vals_list):
        for rec in vals_list:
            setu_product_ids = self.search([('reference_number', '=', rec.get('reference_number'))])
            if setu_product_ids:
                raise UserError("Product Reference Number alredy exist...")
            else:
                rec.update({'onhand': rec.get('incoming') - rec.get('outgoing')})
                # product_all_rec_ids = self.env['product.product'].search([('name', '=', rec.get('product_name'))])
                # if not product_all_rec_ids:
                product_id = self.env['product.product'].create(
                    {'name': rec.get('product_name'), 'detailed_type': 'product',
                     'default_code': rec.get('reference_number')})
        res = super(SetuProduct, self).create(vals_list)
        return res

    @api.onchange('reference_number')
    def _onchange_order_type(self):
        for rec in self:
            if len(rec._origin) > 0:
                setu_product_ids = self.env['setu.product'].search([('reference_number', '=', rec.reference_number)])
                if setu_product_ids:
                    raise UserError("Product Reference Number alredy exist...")

    @api.onchange('incoming', 'outgoing')
    def _onchange_onhand_calculate(self):
        for rec in self:
            rec.onhand = rec.incoming - rec.outgoing
            if rec.onhand < 0:
                raise UserError("Stock are not available...")

            #     qty = rec.outgoing - rec.incoming
            #     vendor_id = self.env['res.partner'].search([], limit=1)
            #     product_product_id = self.env['product.product'].search([('name', '=', rec.product_name)])
            #     purchase_order_id = self.env['purchase.order'].create({'partner_id': vendor_id.id})
            #     self.env['purchase.order.line'].create(
            #         {'product_id': product_product_id.id, 'name': product_product_id.display_name,
            #          'product_qty': qty,
            #          'price_unit': 1, 'price_subtotal': qty * 1, 'order_id': purchase_order_id.id})
            #     purchase_order_id.button_confirm()
            #     purchase_order_id.picking_ids.action_set_quantities_to_reservation()
            #     purchase_order_id.picking_ids.button_validate()
            #     rec.incoming += qty
            #     rec.onhand = 0

    @api.onchange('onhand')
    def _onchange_onhand(self):
        for rec in self:
            outgoing = rec.incoming - rec.onhand
            # if outgoing < 0:
            #     qty = rec.onhand - rec.incoming
            #     vendor_id = self.env['res.partner'].search([], limit=1)
            #     product_product_id = self.env['product.product'].search([('name', '=', rec.product_name)])
            #     purchase_order_id = self.env['purchase.order'].create({'partner_id': vendor_id.id})
            #     self.env['purchase.order.line'].create(
            #         {'product_id': product_product_id.id, 'name': product_product_id.display_name,
            #          'product_qty': qty,
            #          'price_unit': 1, 'price_subtotal': qty * 1, 'order_id': purchase_order_id.id})
            #     purchase_order_id.button_confirm()
            #     purchase_order_id.picking_ids.action_set_quantities_to_reservation()
            #     purchase_order_id.picking_ids.button_validate()
            #     rec.incoming += rec.onhand
            # else:
            if rec.incoming - rec.outgoing > rec.onhand or rec.incoming - rec.outgoing < rec.onhand:
                raise UserError("Onhand can not Change.")
