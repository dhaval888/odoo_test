# #arithmetic oprators
# a = 5
# b = 3
# print(a+b)
# print(a-b)
# print(a*b)
# # print(a%b)
# print(a**b)
# print(a/b)
# print(a//b)

#assinment oprators
# x = 5
# print(x)
# x += 2
# print(x)
#
# x = 5
# x -= 2
# print(x)
#
# x = 5
# x *= 2
# print(x)
#
# x = 5
# x /= 2
# print(x)
#
# x = 5
# x //= 2
# print(x)
#
# x = 5
# x **= 4
# print(x)
#
# x = 13
# x %= 5
# print(x)

# x = 5
# x &= 2
# print(x)
#
# x = 5
# x |= 2
# print(x)
#
# x = 5
# x ^= 2
# print(x)
#
# x = 5
# x >>= 3
# print(x)
#
# x = 5
# x <<= 3
# print(x)




# Comparison Operators
# a = 10
# b = 5
# print(a != b)
# print(a == b)
# print(a < b)
# print(a > b)
# a = 10
# b = 10
# print(a <= 5)
# print(a >= b)

#logical operators

# x = 5
# print(x > 3 and x < 10) # two condition True
# print(x > 3 or x < 2) # only one condition True
# print(not(x > 11 or x < 10)) # reverse output true to false and false to true

#identify operators

# a = ["rohit","virat","jaspeet"]
# b = ["rohit","virat","jaspreet"]
# c = a
#
# print(a is c) # object are same true
# print( a is b) # object are not same false value are same
#
# print( a is not c)
# print(a is not b)


#membership operators
#
# a = ["rohit","virat","jaspeet"]
# print("rohit" in a)
# print("rahul" in a)
#
# print("virat" not in a)
# print("rahul" not in a)

#bitwise operators
# print(6 & 3)
# print(6 | 3)
# print(6 ^ 3)
# print(3 << 2)
# print(12 >> 2)
