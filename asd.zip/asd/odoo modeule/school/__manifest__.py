{
    'name': 'School',
    'version': '16.9',
    'depends': ['mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/student_views.xml',
        'views/teacher_views.xml',
        'views/department_views.xml'
    ]
}
