{
    'name': 'Hospital Management',
    'version': '16.2',
    'depends': ['mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/doctor_views.xml',
        'views/pacient_views.xml',
        # 'views/department_views.xml'
    ]
}
