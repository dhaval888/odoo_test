import pandas as pd
from openpyxl import load_workbook
from odoo import models, fields, api
import base64, io, csv
from odoo.exceptions import UserError


class ImportRecord(models.TransientModel):
    _name = "import.record"

    csv_file = fields.Binary(string='Select File')
    name = fields.Char(required=True)

    # sale_id = fields.Many2one('sale.order')
    # customer_rec = fields.Many2one('res.partner')
    # product_id = fields.Many2one('product.product')

    # @api.constrains('csv_file')
    # def check_unique_name(self):
    #     for record in self:
    #         if not record.csv_file.endwith('.csv'):
    #             raise UserError('First name & Last name should be unique.')

    # existing_record = self.search(
    #     [('id', '!=', record.id), ('first_name', '=', record.first_name), ('last_name', '=', record.last_name)])
    # if existing_record:

    def import_csv_records(self):
        header_iterator, iterator = 0, 0

        global temp, order_id
        price_unit = 0.0
        price_subtotal = 0.0

        data_dictionary = {}
        final_data_dict = []
        file_reader = []
        data_list = []
        '''Csv file'''
        if self.name.endswith('.csv'):
            data = base64.b64decode(self.csv_file)
            data_file = io.StringIO(data.decode("utf-8"))

            csv_reader = csv.reader(data_file, delimiter=",")
            file_reader.extend(csv_reader)
            dict_keys1 = file_reader[0]
            total_length, header_length = len(file_reader), len(dict_keys1)
            # header_iterator, iterator = 0, 1
            # print(type(dict_keys))

        '''xlsx file'''
        if self.name.endswith('.xlsx'):
            file_data = base64.b64decode(self.csv_file)
            excel_file = io.BytesIO(file_data)
            df = pd.read_excel(excel_file, engine='openpyxl')
            csv_data = df.to_csv(index=False)
            csv_file = io.StringIO(csv_data)
            csv_reader = csv.reader(csv_file, delimiter=",")
            dict_keys = next(csv_reader)

            for row in csv_reader:
                row_dict = dict(zip(dict_keys, row))
                data_list.append(row_dict)

            total_length, header_length = len(data_list), len(dict_keys)

        if self.name.endswith('.xlsx'):
            final_data = data_list
            final_keys = dict_keys
        elif self.name.endswith('.csv'):
            headers = file_reader[0]
            final_data = [dict(zip(dict_keys1, row)) for row in file_reader[1:]]
            final_keys = headers

            total_length -= 1

        else:
            common_log_id = self.env['setu.common.log'].create({'state': 'failure', 'model': 'sale.order'})
            self.env['setu.common.log.line'].create(
                {'state': 'fail', 'log_message': 'Invalid Data', 'common_log_id': common_log_id.id})
            attachment = self.env['ir.attachment'].create(
                {'name': self.name, 'datas': self.csv_file, 'res_id': common_log_id.id,
                 'res_model': 'setu.common.log'})
            common_log_id.message_post(body='File Attachment', attachment_ids=[attachment.id])
            return

        while iterator < total_length:
            for values in final_data[iterator].values():
                data_dictionary[final_keys[header_iterator]] = values
                # print(values)
                if iterator > total_length:
                    break
                header_iterator += 1

            customer_data = data_dictionary.get('customer_name')
            customer_pan = str(data_dictionary.get('pan')) if data_dictionary.get('pan') != "" else ""

            product_name = data_dictionary.get('product_name')
            product_qty = data_dictionary.get('quantity')
            confirm = data_dictionary.get('confirm')
            validate = data_dictionary.get('validate')
            invoice = data_dictionary.get('invoice')

            if product_qty in ["", "0", "0.0"]:
                common_log_id = self.env['setu.common.log'].create({'state': 'failure', 'model': 'sale.order'})
                self.env['setu.common.log.line'].create(
                    {'state': 'fail', 'log_message': 'Check File Type', 'common_log_id': common_log_id.id})
                attachment = self.env['ir.attachment'].create(
                    {'name': self.name, 'datas': self.csv_file, 'res_id': common_log_id.id,
                     'res_model': 'setu.common.log'})
                common_log_id.message_post(body='File Attachment', attachment_ids=[attachment.id])
                break
            """Customer Data"""

            customer_rec = self.env['res.partner'].search([('pan', '=', customer_pan)])
            check_pan = True
            check_name = ""
            if not customer_rec:
                for rec in final_data_dict:
                    if customer_pan == str(rec.get('pan')):
                        check_name = rec.get('customer_name')
                        check_pan = False
                        break
            else:
                check_name = customer_rec.name

            '''first Record 
                dhaval	123	leptop	10
                dhaval	123	book	20
                	    	book	20 

                This comment customer is not in res.partner create record
            '''
            if (not customer_rec) and check_pan:
                if customer_data != "" and customer_pan != "" and product_name != "":
                    final_data_dict.append({'is_cust': False})
                    final_data_dict[iterator]['is_set'] = True

                else:
                    if customer_data == "" and customer_pan == "" and iterator == 0:
                        common_log_id = self.env['setu.common.log'].create({'state': 'failure', 'model': 'sale.order'})
                        self.env['setu.common.log.line'].create(
                            {'state': 'fail', 'raw_number': (iterator + 1), 'log_message': 'Missing Data',
                             'common_log_id': common_log_id.id})
                        attachment = self.env['ir.attachment'].create(
                            {'name': self.name, 'datas': self.csv_file, 'res_id': common_log_id.id,
                             'res_model': 'setu.common.log'})
                        common_log_id.message_post(body='File Attachment', attachment_ids=[attachment.id])
                        break
                        # raise UserError("Invali File Data")

                    if customer_pan == "" and customer_data == "" and product_name != "":
                        temp_pan = ""
                        temp_confirm = ""
                        temp_validate = ""
                        temp_invoice = ""

                        '''pan'''
                        for record in final_data_dict:
                            temp_pan = str(record.get('pan'))
                            # temp_confirm = str(record.get('confirm'))
                            # temp_validate = str(record.get('validate'))
                            # temp_invoice = str(record.get('invoice'))

                        final_data_dict.append({'is_cust': True})
                        final_data_dict[iterator]['is_set'] = False
                        data_dictionary['pan'] = temp_pan
                        # data_dictionary['confirm'] = temp_confirm
                        # data_dictionary['validate'] = temp_validate
                        # data_dictionary['invoice'] = temp_invoice

                    else:
                        common_log_id = self.env['setu.common.log'].create({'state': 'failure', 'model': 'sale.order'})
                        self.env['setu.common.log.line'].create(
                            {'state': 'fail', 'raw_number': (iterator + 1), 'log_message': 'Missing Data',
                             'common_log_id': common_log_id.id})
                        attachment = self.env['ir.attachment'].create(
                            {'name': self.name, 'datas': self.csv_file, 'res_id': common_log_id.id,
                             'res_model': 'setu.common.log'})
                        common_log_id.message_post(body='File Attachment', attachment_ids=[attachment.id])
                        break
                        # raise UserError("Invali File Data")

                '''Customer is alredy create '''
            else:
                if check_name == customer_data:
                    if customer_data != "" and customer_pan != "" and product_name != "":
                        final_data_dict.append({'is_cust': True})
                        final_data_dict[iterator]['is_set'] = True


                    elif customer_pan == "" and product_name != "":
                        if customer_data == "" and customer_pan == "" and product_name != "" and iterator != 1:
                            pass
                        else:
                            common_log_id = self.env['setu.common.log'].create(
                                {'state': 'failure', 'model': 'sale.order'})
                            self.env['setu.common.log.line'].create(
                                {'state': 'fail', 'raw_number': (iterator + 1), 'log_message': 'Missing Data',
                                 'common_log_id': common_log_id.id})
                            attachment = self.env['ir.attachment'].create(
                                {'name': self.name, 'datas': self.csv_file, 'res_id': common_log_id.id,
                                 'res_model': 'setu.common.log'})
                            common_log_id.message_post(body='File Attachment', attachment_ids=[attachment.id])

                            break

                    else:
                        common_log_id = self.env['setu.common.log'].create({'state': 'failure', 'model': 'sale.order'})
                        self.env['setu.common.log.line'].create(
                            {'state': 'fail', 'raw_number': (iterator + 1), 'log_message': 'Missing Data',
                             'common_log_id': common_log_id.id})
                        attachment = self.env['ir.attachment'].create(
                            {'name': self.name, 'datas': self.csv_file, 'res_id': common_log_id.id,
                             'res_model': 'setu.common.log'})
                        common_log_id.message_post(body='File Attachment', attachment_ids=[attachment.id])
                        break

                else:
                    common_log_id = self.env['setu.common.log'].create({'state': 'failure', 'model': 'sale.order'})
                    self.env['setu.common.log.line'].create(
                        {'state': 'fail', 'raw_number': (iterator + 1), 'log_message': 'Missing Data',
                         'common_log_id': common_log_id.id})

                    attachment = self.env['ir.attachment'].create(
                        {'name': self.name, 'datas': self.csv_file, 'res_id': common_log_id.id,
                         'res_model': 'setu.common.log'})
                    common_log_id.message_post(body='File Attachment', attachment_ids=[attachment.id])
                    break

            if header_iterator >= header_length:
                final_data_dict[iterator].update(data_dictionary)
                header_iterator = 0
                iterator += 1
                data_dictionary = {}
        else:
            for i, temp_dict in enumerate(final_data_dict):

                product_id = self.env['product.product'].search([('name', '=', temp_dict.get('product_name'))])
                if not product_id:
                    product_id = self.env['product.product'].create({'name': temp_dict.get('product_name')})

                if not temp_dict.get('is_cust'):
                    cust_rec = self.env['res.partner'].create(
                        {'name': temp_dict.get('customer_name'), 'pan': str(temp_dict.get('pan'))})
                    order_id = self.env['sale.order'].create({'partner_id': cust_rec.id})
                    final_data_dict[i]['o_id'] = order_id.id

                else:
                    cust_rec = self.env['res.partner'].search([('pan', '=', str(temp_dict.get('pan')))])
                    if not temp_dict.get('customer_name'):
                        order_id = self.env['sale.order'].search([('partner_id', '=', cust_rec.id)])
                        if len(order_id) > 1:
                            for i in order_id:
                                temp_id = i
                                break
                            order_id = temp_id
                    else:
                        order_id = self.env['sale.order'].create({'partner_id': cust_rec.id})
                        final_data_dict[i]['o_id'] = order_id.id

                self.env['sale.order.line'].create(
                    {'product_template_id': product_id.id, 'product_id': product_id.id, 'order_id': order_id.id,
                     'name': temp_dict.get('product_name'), 'price_unit': price_unit,
                     'price_subtotal': price_subtotal,
                     'product_uom_qty': temp_dict.get('quantity')})

            for temp_dict in final_data_dict:
                if temp_dict.get('is_set'):
                    order_id = self.env['sale.order'].search([('id', '=', temp_dict.get('o_id'))])
                    # for i in product:
                    #     print(i)
                    # for i in order_id.order_line:
                    #     # print(i.product_template_id.on_hand_id)
                    #     product = self.env['product.template'].search([('name', '=', i.product_template_id.name)])
                    #     print(product.qty_available)

                    if temp_dict.get('invoice') in ['1', 'True', 'TRUE', 'true', '1.0']:
                        order_id.action_confirm()
                        order_id.picking_ids.action_set_quantities_to_reservation()
                        order_id.picking_ids.button_validate()
                        order_id._create_invoices()
                        # order_id.invoice_ids.action_post()

                    elif temp_dict.get('validate') in ['1', 'True', 'TRUE', 'true', '1.0']:
                        order_id.action_confirm()
                        order_id.picking_ids.action_set_quantities_to_reservation()
                        order_id.picking_ids.button_validate()

                    elif temp_dict.get('confirm') in ['1', 'True', 'TRUE', 'true', '1.0']:
                        order_id.action_confirm()

            common_log_id = self.env['setu.common.log'].create({'state': 'success', 'model': 'sale.order'})
            self.env['setu.common.log.line'].create(
                {'state': 'pass', 'log_message': 'Data Successfully Add', 'common_log_id': common_log_id.id})
            attachment = self.env['ir.attachment'].create(
                {'name': self.name, 'datas': self.csv_file, 'res_id': common_log_id.id, 'res_model': 'setu.common.log'})
            common_log_id.message_post(body='File Attachment', attachment_ids=[attachment.id])
