from odoo import api, fields, models, _
from odoo.exceptions import UserError


class SetuOrder(models.Model):
    _name = 'setu.order'
    _rec_name = 'reference'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    reference = fields.Char(copy=False, readonly=True,
                            default=lambda self: _(''))
    order_date = fields.Date(required=True, )
    customer_id = fields.Many2one('setu.customer', required=True, )
    pan = fields.Char(related="customer_id.pan_no", )
    product_id = fields.Many2one('setu.product', required=True, )
    quantity = fields.Float(required=True, )
    product_type = fields.Selection(
        selection=[
            ('incoming', 'Incoming'),
            ('outgoing', 'Outgoing'),
        ], required=True,
    )
    order_type = fields.Selection(
        selection=[
            ('customer', 'Customer'),
            ('vendor', 'Vendor'),
            ('customer and vendor', 'Customer & Vendor'),
        ], required=True,
    )
    purchase_order_validate = fields.Boolean()

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            customer_id = self.env['setu.customer'].search([('id', '=', vals.get('customer_id'))])
            if customer_id.type != vals.get('order_type'):
                raise UserError("Wrong Order Type...")
            if vals.get('reference', _('')) == _(''):
                vals['reference'] = self.env['ir.sequence'].next_by_code('setu.order') or _("New")
        return super(SetuOrder, self).create(vals_list)

    @api.onchange('order_type')
    def _onchange_order_type(self):
        for rec in self:
            if len(rec._origin) > 0:
                customer_id = self.env['setu.customer'].search([('id', '=', rec.customer_id.id)])
                if customer_id.type != rec.order_type:
                    raise UserError("Wrong Order Type...")

    def action_confirm(self):
        for rec in self:
            if (rec.order_type == 'customer' and rec.product_type == 'outgoing') or (
                    rec.order_type == 'vendor' and rec.product_type == 'incoming'):
                raise UserError("Wrong Product Type...")

            if rec.product_type == 'incoming':
                vendor_id = self.env['res.partner'].search([], limit=1)
                purchase_order_id = self.env['purchase.order'].create({'partner_id': vendor_id.id})
                self.env['purchase.order.line'].create(
                    {'product_id': rec.product_id.id, 'name': rec.product_id.display_name, 'product_qty': rec.quantity,
                     'price_unit': 1, 'price_subtotal': rec.quantity * 1, 'order_id': purchase_order_id.id})

                rec.product_id.incoming += rec.quantity
                purchase_order_id.button_confirm()
                purchase_order_id.picking_ids.action_set_quantities_to_reservation()
                purchase_order_id.picking_ids.button_validate()
                rec.product_id.onhand += rec.quantity

            if rec.product_type == 'outgoing':
                new_onhand = rec.product_id.onhand - rec.quantity
                if new_onhand < 0:
                    qty = rec.quantity - rec.product_id.onhand
                    vendor_id = self.env['res.partner'].search([], limit=1)
                    product_product_id = self.env['product.product'].search(
                        [('name', '=', rec.product_id.product_name)])
                    purchase_order_id = self.env['purchase.order'].create({'partner_id': vendor_id.id})
                    self.env['purchase.order.line'].create(
                        {'product_id': product_product_id.id, 'name': product_product_id.display_name,
                         'product_qty': qty,
                         'price_unit': 1, 'price_subtotal': qty * 1, 'order_id': purchase_order_id.id})
                    if rec.purchase_order_validate == True:
                        purchase_order_id.button_confirm()
                        purchase_order_id.picking_ids.action_set_quantities_to_reservation()
                        purchase_order_id.picking_ids.button_validate()
                        rec.product_id.onhand = qty
                else:
                    rec.product_id.outgoing += rec.quantity
                    rec.product_id.onhand -= rec.quantity


class PurchaseOrder(models.Model):
    _inherit = 'stock.picking'

    def button_validate(self):
        res = super(PurchaseOrder, self).button_validate()
        for rec in self:
            print(rec.move_ids_without_package)
            product_product_id = self.env['setu.product'].search(
                [('reference_number', '=', rec.move_ids_without_package.product_id.default_code)])
            product_product_id.incoming += rec.move_ids_without_package.product_uom_qty
            product_product_id.outgoing += rec.move_ids_without_package.product_uom_qty
            product_product_id.onhand = product_product_id.incoming - product_product_id.outgoing
        return res
