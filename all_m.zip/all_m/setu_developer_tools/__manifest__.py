{
    "name": "Developer Tools",
    "description": """
                    Installing this module, user will able to execute python code from OpenERP
                    """,
    "author": "https://www.setuconsulting.com/",
    "version": "16.0",
    "depends": ["base", "web"],
    "data": [
        'security/ir.model.access.csv',
        'view/python_code_view.xml',
        'view/ir_module_views.xml',
    ],

    'assets': {
        'web.assets_backend': [
            'setu_developer_tools/static/src/scss/*',
        ],
    },
    "demo_xml": [],
    "installable": True,
    "license": "LGPL-3",

}
