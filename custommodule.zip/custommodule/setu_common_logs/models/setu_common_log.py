from odoo import fields, models, api


class SetuCommonLog(models.Model):
    _name = 'setu.common.log'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'portal.mixin']
    _description = 'Setu common log'
    _order = "id desc"

    name = fields.Char(string='Sequence')
    model = fields.Char(string='Model')
    state = fields.Selection(string='State', selection=[('success', 'Success'), ('failure', 'Failure'), ('partial', 'Partial')],
                             compute='_compute_state')
    common_log_line_ids = fields.One2many(comodel_name='setu.common.log.line', inverse_name='common_log_id',
                                          string='Common Log Lines')
    company_id = fields.Many2one('res.company', 'Company', default=lambda self: self.env.company.id)

    @api.depends('common_log_line_ids')
    def _compute_state(self):
        """
        Author : Gaurav Vipani | Date: 11th Sep, 2023
        Purpose : Computer state based log line state
        """
        state = ""
        for rec in self:
            if all(state == 'pass' for state in rec.common_log_line_ids.mapped("state")):
                state = 'success'
            elif all(state == 'fail' for state in rec.common_log_line_ids.mapped("state")):
                state = 'failure'
            else:
                state = 'partial'
            rec.state = state

    def create_common_log_book(self, model):
        """
        Author : Gaurav Vipani | Date: 11th Sep, 2023
        Purpose : Create common log book.
        """
        vals = {'state': 'success', 'model': model, 'company_id':self.env.company.id}
        log_book_id = self.create(vals)
        return log_book_id

    def view_success_log(self):
        """
        Author : Gaurav Vipani | Date: 11th Sep, 2023
        Purpose : View success log line.
        """
        action = self.env["ir.actions.act_window"]._for_xml_id("setu_common_logs.setu_common_log_line_view_action")
        action['domain'] = [('common_log_id', '=', self.id), ('state', '=', 'pass')]
        return action

    def view_failed_log(self):
        """
        Author : Gaurav Vipani | Date: 11th Sep, 2023
        Purpose : View fail log line.
        """
        action = self.env["ir.actions.act_window"]._for_xml_id("setu_common_logs.setu_common_log_line_view_action")
        action['domain'] = [('common_log_id', '=', self.id), ('state', '=', 'fail')]
        return action

    @api.model
    def create(self, vals):
        """
        Author : Gaurav Vipani | Date: 11th Sep, 2023
        Purpose : This method is inherited for adding sequence for import log record.
        """
        seq = self.env['ir.sequence'].next_by_code("setu.common.log")
        vals.update({'name': seq})
        return super(SetuCommonLog, self).create(vals)