{
    'name': 'New Sale Extended',
    'version': '16.1',
    'depends': ['sale_management'],
    'data': [
        'security/ir.model.access.csv',
        'wizard/new_sale_order_wizard_view.xml',
        'views/sale_order_view.xml',
        'views/account_views.xml'
    ],
}