from bs4.diagnose import rsentence

from odoo import api, fields, models
from odoo.odoo.tools.populate import compute


class AccountAccount(models.Model):
    _inherit = 'sale.order'

    partner_invoice_id = fields.Many2one()
    partner_shipping_id = fields.Many2one()

    @api.onchange('partner_id')
    def onchange_partner_id(self):
        for records in self:
            domain = [('parent_id', '=', records.partner_id.id)]
            return {'domain': {'partner_invoice_id': domain, 'partner_shipping_id': domain}}



    # @api.depends('partner_id')
    # def _compute_partner_address(self):
    #     for rec in self:
    #         print(rec.partner_id)

# <xpath expr="//page[1]//tree/field[@name='product_id']" position="attributes">
#                  <attribute name="domain">[('product_model_name_id', '=', parent.model_name_id)]</attribute>
#              </xpath>
