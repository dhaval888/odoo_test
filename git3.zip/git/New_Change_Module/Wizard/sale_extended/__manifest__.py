{
    'name': 'Sale Extended',
    'version': '16.1',
    'depends': ['mail', 'sale_management', 'sale'],
    'data': [
        'security/ir.model.access.csv',
        'wizard/sale_wizard_views.xml',
        'views/sale_order_views.xml'
    ]
}
