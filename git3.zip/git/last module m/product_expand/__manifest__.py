{
    'name': 'Product Expand',
    'version': '16.1',
    'depends': ['sale_management', 'base', 'sale', 'account', 'stock'],
    'data': [
        'views/stock_warehouse_orderpoint_view.xml'
    ],
}
