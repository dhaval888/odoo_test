from odoo import models, fields, api


class Account(models.Model):
    _inherit = 'account.payment'
    _description = 'Account Payment'

    order_id = fields.Many2one(comodel_name='sale.order')
