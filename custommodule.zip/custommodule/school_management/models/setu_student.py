from odoo import fields, models, api


class SetuStudent(models.Model):
    _name = "setu.student"
    _rec_name = "name"

    name = fields.Char()

    email = fields.Char()
    phone = fields.Integer()
