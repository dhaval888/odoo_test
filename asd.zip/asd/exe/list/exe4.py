
# [4] Write a Python program to count the number of strings from a given list of strings. The string length is 2 or more and the first and last characters are the same.
# Input : ['abc', 'xyz', 'aba', '1221']
# Output : 2

lst = ['abc', 'xyz', 'aba', '121', '1221']
a = 0
for i in lst:
    if i[0:1] == i[-1]:

        a = a + 1
print(a)

# for i in lst:
#     print(i[0])