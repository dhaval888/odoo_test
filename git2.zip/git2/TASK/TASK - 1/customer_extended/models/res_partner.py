from odoo.exceptions import UserError
from odoo import api, fields, models


class ResPartner(models.Model):
    _inherit = 'res.partner'

    credit_limit = fields.Float(string="Set Credit Limit", compute="_credit_compute", store=True)


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    def action_confirm(self):
        res = super(SaleOrder, self).action_confirm()

        total = 0
        for rec in self:
            sale_ids = self.search([('partner_id.id', '=', rec.partner_id.id)])
            for sale_rec in sale_ids:
                total += sale_rec.amount_total

        if self.partner_id.credit_limit == 0:
            raise UserError("Your Credit limit 0")
        if self.partner_id.credit_limit < 0:
            raise UserError("Your Credit limit negative")
        if total > 1000:
            raise UserError("Your Credit limit is bigger than your sale order amount")

        return res
