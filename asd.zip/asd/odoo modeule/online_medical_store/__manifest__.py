{
    'name': 'Online Medical Store',
    'version': '16.10',
    'depends': ['mail'],
    'data': [
        'security/ir.models.access.csv',
        'views/category_views.xml',
        'views/user_views.xml',
        'views/companies_views.xml',
        'views/contact_views.xml',
        'views/stock_views.xml',
        'views/medicine_views.xml',
    ],
}
