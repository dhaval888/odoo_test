from odoo import api, fields, models, _


class SaleOrder(models.Model):
    _name = 'sale.order.line.extended'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    product_qty = fields.Integer(string="Qty", default="1")
    price = fields.Char(string="Unit Price")
    sub_total = fields.Float(string="Sub Total")

    product_id = fields.Many2one('product.product')
    order_id = fields.Many2one('student')
