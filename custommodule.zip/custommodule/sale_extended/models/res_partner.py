from odoo import models, fields, api


class ResPartner(models.Model):
    _inherit = "res.partner"

    pan = fields.Char(string='Pan')


class TemplateTemplate(models.Model):
    _inherit = "product.template"


    on_hand_id = fields.Many2one('stock.quant')
