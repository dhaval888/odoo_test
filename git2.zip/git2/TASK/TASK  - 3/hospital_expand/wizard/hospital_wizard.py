import base64
import csv
import io

from odoo import models, fields, api


class HospitalWizard(models.TransientModel):
    _name = "hospital.master.data"

    csv_file = fields.Binary(string='Select File')

    def import_csv_records(self):
        data = base64.b64decode(self.csv_file)
        data_file = io.StringIO(data.decode("utf-8"))
        data_dictionary = {}
        file_reader = []
        csv_reader = csv.reader(data_file, delimiter=",")
        file_reader.extend(csv_reader)
        dict_keys = file_reader[0]
        total_length, header_length = len(file_reader), len(dict_keys)
        header_iterator, iterator = 0, 1

        while iterator < total_length:
            for values in file_reader[iterator]:
                data_dictionary[dict_keys[header_iterator]] = values
                if iterator > total_length:
                    break
                header_iterator += 1
            print(data_dictionary)
            if header_iterator >= header_length:
                header_iterator = 0
                iterator += 1
                data_dictionary.clear()