from odoo import api, fields, models, _


class SaleOrder(models.Model):
    _name = 'invoice.line'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    product_id = fields.Many2one('product.product', string="Product")
    name = fields.Char(string="Label")
    quantity = fields.Float(string="Quantity")
    price = fields.Float(string="Price")
    sub_total = fields.Float(string="Subtotal")

    invoice_id = fields.Many2one('invoice')


