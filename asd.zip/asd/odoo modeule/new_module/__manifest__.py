{
    'name': 'New Module',
    'version': '16.10',
    # 'depends': ['mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/customer_views.xml',
        'views/product_views.xml',
    ]
}
