from datetime import datetime
from odoo import api, fields, models
from odoo.exceptions import UserError


class AccountMove(models.Model):
    _inherit = 'account.move'

    @api.model
    def create(self, vals):
        res = super(AccountMove, self).create(vals)
        return res

    def button_draft(self):

        res = super(AccountMove, self).button_draft()

        return res

    # def write(self, vals):
    #     now = datetime.now()
    #     current_date = now.strftime("%Y")
    #     inv_date = str(self.invoice_date)
    #
    #     date_object = datetime.strptime(inv_date, "%Y-%m-%d")
    #     if current_date != date_object.year:
    #
    #         raise UserError('date is never change')

    #     res = super(AccountMove, self).write(vals)
    #     return res

    # year = 0
    # def button_draft(self):
    #     res = super(AccountMove, self).button_draft()
    #     for i in self:
    #         date_object = datetime.strptime(str(i.invoice_date), '%Y-%m-%d')
    #         year = date_object.year
    #     return res

    def _get_last_sequence(self, relaxed=False, with_prefix=None, lock=True):
        res = super(AccountMove, self)._get_last_sequence()
        # sequence_id = self.env['ir.sequence'].search([('prefix', '=', 'INV/')])
        # if sequence_id.use_date_range:
        now = datetime.now()
        current_date = now.strftime("%Y")
        res = f'INV/{current_date}/00000'
        return res

    def action_post(self):
        sequence_id = self.env['ir.sequence'].search([('prefix', '=', 'INV/')])
        now = datetime.now()
        current_date = now.strftime("%m-%d-%Y")
        date_object = datetime.strptime(current_date, '%m-%d-%Y').date()

        # new_date = datetime.strptime(str(self.invoice_date), '%Y-%m-%d')
        # year = new_date.year

        if not self.payment_reference:
            if sequence_id.use_date_range and (
                    sequence_id.date_range_ids.prefix != '' or sequence_id.date_range_ids.suffix != ''):
                if date_object <= sequence_id.date_range_ids.date_to and sequence_id.date_range_ids.date_from <= date_object:
                    step = 0
                    for move in self:
                        step = sequence_id.number_increment
                        size = sequence_id.padding
                        next_number = sequence_id.date_range_ids.number_next_actual
                        new_step_len = len(str(next_number))
                        size -= new_step_len
                        number = '0' * size
                        custom_prifix = sequence_id.date_range_ids.prefix
                        custom_suffix = sequence_id.date_range_ids.suffix
                        if sequence_id.date_range_ids.prefix:
                            move.name = f'{custom_prifix}{number}{next_number}'
                        if sequence_id.date_range_ids.prefix != '' and sequence_id.date_range_ids.suffix == '':
                            move.name = f'{custom_prifix}{number}{next_number}'
                        if sequence_id.date_range_ids.suffix:
                            move.name = f'{custom_prifix}{number}{next_number}{custom_suffix}'
                        move.payment_reference = move.name
                        next_number += step
                        sequence_id.date_range_ids.number_next_actual = next_number

        now = datetime.now()
        current_date = now.strftime("%Y")
        print(current_date)
        inv_date = str(self.invoice_date)

        date_object = datetime.strptime(inv_date, "%Y-%m-%d")
        new_date = str(date_object.year)
        if new_date != current_date:
            self._constrains_date_sequence()

        res = super(AccountMove, self).action_post()
        return res

    # @api.depends('posted_before', 'state', 'journal_id', 'date')
    # def _compute_name(self):
    #
    #     sequence_id = self.env['ir.sequence'].search([('prefix', '=', 'INV/')])
    #     now = datetime.now()
    #     current_date = now.strftime("%m-%d-%Y")
    #     date_object = datetime.strptime(current_date, '%m-%d-%Y').date()
    #
    #     res = super(AccountMove, self)._compute_name()
    #
    #     if len(self._origin) == 1:
    #         if sequence_id.use_date_range == True:
    #             if date_object <= sequence_id.date_range_ids.date_to and sequence_id.date_range_ids.date_from <= date_object:
    #                 for move in self:
    #                     next_number = sequence_id.date_range_ids.number_next_actual
    #
    #                     custom_prifix = sequence_id.date_range_ids.prefix
    #                     # custom_suffix = sequence_id.date_range_ids.suffix
    #
    #                     move.name = f'{custom_prifix}{next_number}'
    #                     next_number += 1
    #     return res


# else:
#     self._compute_name()

# @api.depends('posted_before', 'state', 'journal_id', 'date')
# def _compute_name(self):
#     sequence_id = self.env['ir.sequence'].search([('prefix', '=', 'INV/')])
#     now = datetime.now()
#     current_date = now.strftime("%m-%d-%Y")
#     date_object = datetime.strptime(current_date, '%m-%d-%Y').date()
#
#     res = super(AccountMove, self)._compute_name()
#     if self.state == 'draft':
#         self.name = 'Draft'
#     else:
#         if sequence_id.use_date_range == True:
#             if date_object <= sequence_id.date_range_ids.date_to and sequence_id.date_range_ids.date_from <= date_object:
#                 for move in self:
#                     custom_prifix = sequence_id.date_range_ids.prefix
#                     # custom_suffix = sequence_id.date_range_ids.suffix
#
#                     move.name = f'{custom_prifix}'
#     return res
# print(self)
# for move in self:
#     if move.state == 'draft':
#         move.name = 'Draft'

# else:
#     sequence_id = self.env['ir.sequence'].search([('prefix', '=', 'S')])
#     custom_sequence_name = sequence_id.date_range_ids.prefix
#     move.name = custom_sequence_name
# print(sequence_id.date_range_ids.date_from)
# print(move.name)

# if move.date and not move.posted_before:
#     move.name = f"{move.date}"

# self.filtered(lambda m: not m.name and not m.quick_edit_mode).name = '/'
# self._inverse_name()
# return res

# def _compute_name(self):
#     self = self.sorted(lambda m: (m.date, m.ref or '', m.id))

# Assuming you have a model like this:
class IrSequenceDateRange(models.Model):
    _inherit = 'ir.sequence.date_range'

    prefix = fields.Char()
    suffix = fields.Char()
