from odoo import api, fields, models
import datetime


class Customer(models.Model):
    _name = 'customer'
    _descripion = 'Customer'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Customer Name", copy=False, help='Customer Name')
    age = fields.Char(string="Age", copy=False, help='Customer Age')

    gender = fields.Selection(
        selection=[
            ('male', 'Male'),
            ('female', 'Female'),
        ], default='male', help="Select Gender"
    )

    check_in_time = fields.Datetime(string='Checking Time')
    check_out_time = fields.Datetime(string='Check Out Time')

    price = fields.Float(commpute="_compute_price", store=True)
    admin_id = fields.Many2one(comodel_name='admin', string='Room Category')

    @api.depends('date_of_birth')
    def _compute_price(self):
        today = datetime.date.today()
        for rec in self:
            today = date.today()
            for record in self:
                if record.date_of_birth:
                    record.year = today.year - record.date_of_birth.year
                else:
                    record.year = 0



    @api.model_create_multi
    def create(self, vals):
        for vals_rec in vals:
            vals_rec.update({'price': vals_rec.get('price', 0.0) + 60})
        for new_rec in vals:
            if new_rec.get('price') <= 100:
                new_rec.update({'price': new_rec.get('price', new_rec.get) + 300})
            if new_rec.get('price') >= 100:
                new_rec.update({'price': new_rec.get('price', new_rec.get('price') + 100)})
        res = super().create(vals)
        for rec in res:
            if len(rec.admin_id.customer_ids) >= 1:
                rec.price += 1000
        return res

    def write(self, vals):
        vals.update({'price': vals.get('price', 0.0) + 300})
        if vals.get('admin_id'):
            admin_id = self.env['admin'].browse(vals.get('admin_id'))
            if len(admin_id.customer_ids) >= 1:
                vals.update({'price': vals.get('price', 0.0) + 1000})
        res = super(Customer, self).write(vals)
        return res
