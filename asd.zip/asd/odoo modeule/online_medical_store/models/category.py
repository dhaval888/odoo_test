from odoo import api, fields, models


class Category(models.Model):
    _name = 'category'
    _description = 'Category'
    _rec_name = 'category_name'
    _order = 'category_name desc'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    category_name = fields.Char(string='Category Name', copy=False, required=True, help='Category Name', tracking=True)
    status = fields.Boolean(string='Available', copy=False, required=True, help='Status Available or not',
                            tracking=True)

    stock_ids = fields.One2many('stock', 'category_id')

