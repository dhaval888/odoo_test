{
    'name': 'Office Management',
    'version': '16.6',
    'depends': ['mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/admin_views.xml',
        'views/employee_views.xml'
    ],
}
