{
    "name": "Common Logs",
    "version": "17.0",
    "author": "https://www.setuconsulting.com/",
    "description": """Setu Common Logs""",
    "depends": ["base", "mail", "portal"],
    "data": [
        'security/ir.model.access.csv',
        'security/ir_rule.xml',
        'data/ir_sequence_view.xml',
        'views/setu_common_log_view.xml',
        'views/setu_common_log_line_view.xml',
    ],
    "installable": True,
    "license": "LGPL-3",
}
