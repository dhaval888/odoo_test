from odoo import api, fields, models


class Student(models.TransientModel):
    _name = 'student.wizard'

    name = fields.Char()
    product_name = fields.Char()

    def new_records(self):
        for rec in self:
            global order_id
            partner_id = self.env['res.partner'].search([]).filtered(lambda x: x.name == rec.name)
            product_id = self.env['product.product'].search([]).filtered(lambda x: x.name == rec.product_name)

            if not partner_id:
                new_partner_id = self.env['res.partner'].create({'name': rec.name})
                order_id = self.env['sale.order'].create({'partner_id': new_partner_id.id})
            if partner_id:
                # new_partner_id = self.env['res.partner'].search([]).filtered(lambda x: x.name == rec.first_name)
                order_id = self.env['sale.order'].create({'partner_id': partner_id.id})

            if not product_id:
                new_product_id = self.env['product.product'].create({'name': rec.product_name})
                self.env['sale.order.line'].create(
                    {'product_template_id': new_product_id.id, 'product_id': new_product_id.id, 'order_id': order_id.id,
                     'name': new_product_id.name, 'price_unit': 5, 'price_subtotal': 10, 'product_uom_qty': 2})

            if product_id:
                self.env['sale.order.line'].create(
                    {'product_template_id': product_id.id, 'product_id': product_id.id, 'order_id': order_id.id,
                     'name': product_id.name, 'price_unit': 5, 'price_subtotal': 10, 'product_uom_qty': 2})

            order_id.action_confirm()
            order_id.picking_ids.action_set_quantities_to_reservation()
            # order_id.picking_ids.button_validate()
            # order_id._create_invoices()
            # order_id.invoice_ids.action_post()

