{
    'name': 'MRP Expand',
    'version': '16.1',
    'depends': ['mrp', 'mrp_workorder',],
    'data': []
}