{
    'name': 'Button Extended',
    'version': '16.1',
    'depends': ['sale_management', 'sale'],
    'data': [
        'views/sale_view.xml'
    ]
}
