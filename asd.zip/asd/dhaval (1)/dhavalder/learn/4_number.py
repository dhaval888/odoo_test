# import random
# a = 6# int
# b = 5.2 #float
# c = 5j # complex
# d = "5"
# f = complex(a)
#
# print(f)
# print(type(f))
# print(type(a))
# print(type(b))
# print(type(c))
#
# x = 1
# y = 35656222554887711
# z = -3255522
#
# print(type(x))
# print(type(y))
# print(type(z))
#
# x = 1.10
# y = 1.0
# z = -35.59
#
# print(type(x))
# print(type(y))
# print(type(z))
#
# x = 3e48
# y = 4504e5
# z = 45e26
#
# print(type(x))
# print(type(y))
# print(type(z))
#
# x = 5+5j
# y = 5j
# z = -5j
#
# print(type(x))
# print(type(y))
# print(type(z))
# print(random.randrange(1, 20))


a = 12
b =1.5
c =5j

x = float(a)
y = int(b)
z = complex(a)

print(x,y,z)

x = 102
y = 454685798
z = -45416854

print(type(x))
print(type(y))
print(type(z))

x = 12.2
y = 1245.4564
z = -102.2152

print(type(x))
print(type(y))
print(type(z))

x= 11e45
y = 4545E45
z = -21e454
print(type(x))
print(type(y))
print(type(z))


x = 1j+6j
y = 12j
z = -2j
print(x)
print(type(x))
print(type(y))
print(type(z))
