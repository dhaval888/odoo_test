{
    'name': 'Product Extended',
    'version': '16.1',
    'depends': ['sale_management', 'base', 'sale', 'account', 'stock'],
    'data': [
        'security/ir.model.access.csv',
        'views/product_extended_views.xml',
        'views/sale_order_views.xml',
        'views/product_model_views.xml',
    ],
}
