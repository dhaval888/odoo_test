{
    'name': 'School Management',
    'version': '16.2',
    'data': [
        'security/ir.model.access.csv',
        'views/setu_student_views.xml',
    ],
}
