from odoo import fields, models, api


class Doctor(models.Model):
    _name = "hospital.data"

    name = fields.Char(required=True)

    check_state = fields.Boolean(compute="_compute_check_state", store=True)

    # address fields
    location = fields.Char()
    address_original_first_line = fields.Char()
    district = fields.Char()
    pincode = fields.Char()
    telephone = fields.Char()
    state_id = fields.Integer()
    state = fields.Char()

    @api.depends('state')
    def _compute_check_state(self):
        for record in self:
            if record.state == "":
                record.check_state = True
