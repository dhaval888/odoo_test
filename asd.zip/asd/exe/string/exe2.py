# Write a Python program to get a string made of the first 2 and last 2 characters of a given string. If the string length is less than 2, return the empty string instead.
# Sample String : 'w3school'
# Expected Result : 'w3ol'
st = "w3school.com"
if len(st) <= 2:
    st = ""
    print(st)
else:
    x = (st[0:2])
    y = (st[-2:])
    print(x+y)

