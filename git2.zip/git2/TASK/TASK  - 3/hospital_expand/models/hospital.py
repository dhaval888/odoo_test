from odoo import api, fields, models


class AccountAccount(models.Model):
    _name = "hospital"

    name = fields.Char(string="")
    location = fields.Char(string="")
    address = fields.Char(string="")
    district = fields.Char(string="")
    pincode = fields.Char(string="")
    telephone = fields.Char(string="")

