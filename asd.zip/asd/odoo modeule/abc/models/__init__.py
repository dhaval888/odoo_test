from . import student
from . import teacher
from . import department
