# [5] Write a Python program to remove duplicate number from a list.
# Input: [10,12,20,22,10]
# Output: [10,12,20,22]

lst = [10, 12, 20, 22, 10]

x = []
for i in lst:
    if i not in x:
        x.append(i)
print(x)
