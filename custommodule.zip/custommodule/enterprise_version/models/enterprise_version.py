import base64
import re
from odoo import fields, models, api, Command
from pathlib import Path
import io
import zipfile


class EnterpriseVersion(models.Model):
    _name = "enterprise.version"
    _description = "Enterprise Version"
    _inherit = ['mail.thread', 'mail.activity.mixin', 'portal.mixin']
    _rec_name = 'type'

    # type = fields.Selection(selection=[
    #     ('community', 'Community'),
    #     ('enterprise', 'Enterprise'),
    # ], requred='True', default="community"
    # )

    type = fields.Char(string="type", compute='_compute_version')
    version = fields.Selection(selection=[('15', '15'), ('16', '16'), ('17', '17'), ('18', '18'), ])

    @api.depends('version')
    def _compute_version(self):
        for i in self:
            a = 10
            print(i, self.version)

    list = []
    @api.model_create_multi
    def create(self, vals):
        res = super().create(vals)
        for record in res:
            def zip_folder(folder_path, zip_filename):
                folder_path = Path(folder_path)
                zip_path = Path(zip_filename)
                zip_buffer = io.BytesIO()

                with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    for file in folder_path.rglob('*'):
                        zipf.write(file, file.relative_to(folder_path))
                zip_buffer.seek(0)
                return zip_buffer.getvalue()

            if record.version and record.type:
                folder_to_zip = f'/home/setu52/workspace/odoo/{record.version}.0/custom'

                zip_file_name = f'{record.type}_{record.version}.0.zip'
                zip_file_object = zip_folder(folder_to_zip, zip_file_name)
                # self.list.append(zip_file_name)

                with open(zip_file_name, "rb") as fd:
                    buf = io.BytesIO(fd.read())
                    bytes = buf.getvalue()
                encode_bytes = base64.encodebytes(bytes)

                attachment = self.env['ir.attachment'].create({
                    'name': zip_file_name,
                    'datas': encode_bytes,
                    'res_id': record._origin.id,
                    'res_model': 'enterprise.version',
                })

        return res

    @api.onchange('version')
    def onchange_version(self):
        for record in self:
            def zip_folder(folder_path, zip_filename):
                folder_path = Path(folder_path)
                zip_path = Path(zip_filename)
                zip_buffer = io.BytesIO()

                with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    for file in folder_path.rglob('*'):
                        zipf.write(file, file.relative_to(folder_path))
                zip_buffer.seek(0)
                return zip_buffer.getvalue()

            if record.version and record.type:
                folder_to_zip = f'/home/setu52/workspace/odoo/{record.version}/custom'

                zip_file_name = f'{record.type}_{record.version}.0.zip'
                zip_file_object = zip_folder(folder_to_zip, zip_file_name)

                with open(zip_file_name, "rb") as fd:
                    buf = io.BytesIO(fd.read())
                    bytes = buf.getvalue()
                encode_bytes = base64.encodebytes(bytes)

                attachment_id = self.env['ir.attachment'].search([('res_id', '=', record._origin.id)])
                for i in attachment_id:
                    if i.name.endswith('.zip'):
                        self.list.append(i.name)

                if zip_file_name in self.list:
                    filtered_data = list(filter(lambda data: record.version in data, self.list))
                    filtered_data.sort()
                    print(filtered_data[-1])

                    match = re.search(r'_(\d+)\.(\d+)\.zip', filtered_data[-1])
                    version_number = match.group(2)
                    new_version = int(version_number)
                    new_version += 1
                    new_file_name = f'{record.type}_{record.version}.{new_version}.zip'

                    attachment = self.env['ir.attachment'].create({
                        'name': new_file_name,
                        'datas': encode_bytes,
                        'res_id': record._origin.id,
                        'res_model': 'enterprise.version',
                    })

                else:
                    attachment = self.env['ir.attachment'].create({
                        'name': zip_file_name,
                        'datas': encode_bytes,
                        'res_id': record._origin.id,
                        'res_model': 'enterprise.version',
                    })

                    # record.message_post(
                    #     body="Attachment Created Successfully!",
                    #     attachment_ids=[attachment.id]
                    # )
                    record._origin.message_notify(
                        body="Attachment Created Successfully!",
                        attachment_ids=[attachment.id])

                self.list.clear()

            # if zip_file_name in self.list:
            #     increament = 0
            #     match = re.search(r'_(\d+)\.(\d+)\.zip', zip_file_name)
            #     if match:
            #         version_number = match.group(2)
            #         increament = int(version_number)
            #
            #         filtered_data = list(filter(lambda data: record.version in data, self.list))
            #         filtered_data.sort()
            #         filtered_data[-1]
            #
            #         increament += 1
            #         abc = f'{record.type}_{record.version}.{increament}.zip'
            #
            #         attachment = self.env['ir.attachment'].create({
            #             'name': abc,
            #             'datas': encode_bytes,
            #             'res_id': record._origin.id,
            #             'res_model': 'enterprise.version',
            #         })
            # else:
            #     self.list.append(zip_file_name)
            #     attachment = self.env['ir.attachment'].create({
            #         'name': zip_file_name,
            #         'datas': encode_bytes,
            #         'res_id': record._origin.id,
            #         'res_model': 'enterprise.version',
            #     })

            #  ['community_15.0.zip', 'community_16.0.zip', 'community_17.0.zip', 'community_16.0.zip']
            # attachment_id = self.env['ir.attachment'].search([('res_id', '=', record._origin.id)])
            # version_number = 0
            # for i in attachment_id:
            #     if i.name.endswith('.zip'):
            #         if i.name in self.list:
            #             pass
            # filename = i.name
            # match = re.search(r'_(\d+)\.(\d+)\.zip', filename)
            # if match:
            #     version_number = match.group(2)

            # increament = version
            # increament += 1
            # zip_file_name = f'{record.type}_{record.version}.{increament}.zip'
            # self.list.append(increament)

            #             zip_file_name = f'{record.type}_{record.version}.{increament}.zip'

            # self.list.clear()


            # ======== code ======

# @api.depends('version')
# def _compute_enterprise_version(self):
#     for record in self:
#         def zip_folder(folder_path, zip_filename):
#             folder_path = Path(folder_path)
#             zip_path = Path(zip_filename)
#             zip_buffer = io.BytesIO()
#
#             with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
#                 for file in folder_path.rglob('*'):
#                     zipf.write(file, file.relative_to(folder_path))
#             zip_buffer.seek(0)
#             return zip_buffer.getvalue()
#
#         if record.version and record.type:
#             folder_to_zip = f'/home/setu52/workspace/odoo/{record.version}/custom'
#
#             zip_file_name = f'{record.type}_{record.version}.zip'
#             zip_file_object = zip_folder(folder_to_zip, zip_file_name)
#
#             with open(zip_file_name, "rb") as fd:
#                 buf = io.BytesIO(fd.read())
#                 bytes = buf.getvalue()
#             encode_bytes = base64.encodebytes(bytes)
#
#             attachment_id = self.env['ir.attachment'].search([('res_id', '=', record._origin.id)])
#             # print(attachment_id)
#
#             # for i in attachment_id:
#             #     if i.datas:
#             #         print(attachment_id)
#
#             attachment = self.env['ir.attachment'].create({
#                 'name': zip_file_name,
#                 'datas': encode_bytes,
#                 'res_id': record._origin.id,
#                 'res_model': 'enterprise.version',
#             })
#             # record._origin.message_post(
#             #     body="Attachment Created Successfully!",
#             #     attachment_ids=[attachment.id]
#             # )
#
#             # record.message_notify(
#             #     body="Attachment Created Successfully!",
#             #     attachment_ids=[attachment.id]
#             # )

#     for record in self:
#         zip_buffer = io.BytesIO()
#         def zip_folder(folder_path, zip_filename):
#             folder_path = Path(folder_pa th)
#             zip_path = Path(zip_filename)
#             with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
#                 for file in folder_path.rglob('*'):
#                     zipf.write(file, file.relative_to(folder_path))
#
#             zip_buffer.seek(0)
#             return zip_buffer.getvalue()  # Return the binary data of the ZIP file
#
#         folder_to_zip = '/home/setu52/workspace/odoo/' + record.version + '/custom'
#         zip_file_name = record.type + '_' + record.version + '.zip'
#
#         zip_file_object = zip_folder(folder_to_zip, zip_file_name)
#         seek = zip_buffer.seek(0)
#         # read = zip_buffer.read()
#         # abcd = zip_buffer.getbuffer().tobytes()
#         attachment = self.env['ir.attachment'].create({
#             'name': zip_file_name,
#             'datas': zip_file_object,
#             'res_id': self.id,
#             'res_model': 'enterprise.version',
#         })
# self.message_post(
#     body="Zip File Created Successfully !!",
#     attachment_ids=[attachment.id],
# )

# @api.depends('version')
# def _compute_enterprise_version(self):
#     for record in self:
#         folder_to_zip = f'/home/setu52/workspace/odoo/{record.version}/custom'
#         zip_file_name = f"{record.type}_{record.version}.zip"
#
#         zip_data = self.zip_folder(folder_to_zip)
#
#         attachment = self.env['ir.attachment'].create({
#             'name': zip_file_name,
#             'datas': base64.b64encode(zip_data),
#             'res_id': self.id,
#             'res_model': 'enterprise.version',
#         })
#
#         # self.message_post(
#         #     body="Zip File Created Successfully !!",
#         #     attachment_ids=[attachment.id],  # Attach the attachment
#         # )
#         #
#         self.download_file(attachment)
#         return {
#             'type': 'ir.actions.act_url',
#             'url': '/web/content/%s?download=true' % attachment.id,
#             'target': 'new'
#         }


# =========================== write method ==============

# def write(self, vals):
#     for record in self:
#         def zip_folder(folder_path, zip_filename):
#             folder_path = Path(folder_path)
#             zip_path = Path(zip_filename)
#             zip_buffer = io.BytesIO()
#
#             with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
#                 for file in folder_path.rglob('*'):
#                     zipf.write(file, file.relative_to(folder_path))
#             zip_buffer.seek(0)
#             return zip_buffer.getvalue()
#
#         if record.version and record.type:
#             folder_to_zip = f'/home/setu52/workspace/odoo/{record.version}/custom'
#
#             zip_file_name = f'{record.type}_{record.version}.zip'
#             zip_file_object = zip_folder(folder_to_zip, zip_file_name)
#
#             with open(zip_file_name, "rb") as fd:
#                 buf = io.BytesIO(fd.read())
#                 bytes = buf.getvalue()
#             encode_bytes = base64.encodebytes(bytes)
#             attachment = self.env['ir.attachment'].create({
#                 'name': zip_file_name,
#                 'datas': encode_bytes,
#                 'res_id': record._origin.id,
#                 'res_model': 'enterprise.version',
#             })
#             record.message_post(body="Attachment Created Successfully!", attachment_ids=[attachment.id])
#     res = super(EnterpriseVersion, self).write(vals)
#     return res
