from odoo import api, fields, models


class Doctor(models.Model):
    _name = 'doctor'
    _discription = 'Doctor'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Doctor Name", copy=False, help='Doctor Name')
    experience = fields.Char(string="Doctor Experience(Year)", copy=False, help='Doctor Experience')

    degree = fields.Selection(
        selection=[
            ('m.s', 'M.S'),
            ('m.d', 'M.D'),
            ('b.h.m.s', 'B.H.M.S'),
            ('b.a.m.s', 'B.A.M.S'),
            ('m.b.b.s', 'M.B.B.S'),
        ], default='m.s', string='Degree', help='Doctor Degree',
    )
    salary = fields.Float(string="Salary", help="Salary")

