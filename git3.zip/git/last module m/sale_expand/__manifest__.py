{
    'name': 'Sale Expand',
    'version': '16.1',
    'depends': ['sale_management','base','sale'],
    'data': [
    ],
}
