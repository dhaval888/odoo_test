class Test:
    x = 5


print(Test)


class Test:
    x = 5


t = Test()
print(t.x)


class person():

    def __init__(self, name, age):
        self.name = name
        self.age = age


p = person("virat", '21')
print(p.name)
print(p.age)


class myclass:

    def __init__(self, name, age):
        self.name = name
        self.age = age
        print("i am a contsructor " + name)

    def function(abc):
        print("i am a function "+abc.name)


m = myclass('rohit', 'age')
m.function()

class person():
    def __init__(self,name,age):
        self.name = name
        self.age = age
    def namepri(self):
        print(self.name,self.age)

p =person("virat","33")
p.namepri()


