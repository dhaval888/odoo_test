from odoo import api, fields, models


class Admin(models.Model):
    _name = 'admin'
    _description = 'Admin'
    _rec_name = 'name'
    _order = 'age desc'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Admin Name", help="Admin Name", copy=True, required=True, tracking=True)
    age = fields.Integer(string="Admin Age", help="Admin Age", copy=True, required=True, tracking=True)

    employee_ids = fields.Many2many('employee', 'employee_admin_rel', 'employee', 'admin', string="Employee")
