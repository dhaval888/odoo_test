# #for loop
#
# fruits = ["apple","banana","cherry"]
# for i in fruits:
#     print(i)
#
# for x in "apple":
#     print(x)
#
# for i in "cherry":
#     print(i)
#
# for i in fruits:
#     print(i)
#     if i == "banana":
#         break
#
# for i in fruits:
#     if i == "banana":
#         break
#     print(i)
#
# for i in fruits:
#
#     if i == "banana":
#         continue
#     print(i)
# for x in range(6):
#     print(x,end=" ")
#
# for x in range(2,6):
#     print(x)
#
# for x in range(2,15,3):
#     print(x,end=" ")
#
# for x in range(1,6):
#     print(x)
# else:
#     print("loop is over")
#
# for x in range(1,15):
#     if x == 5:
#         break
#     print(x)
# else:
#     print("loop is over")
#
# x = ["red","big","testy"]
# y = ["apple","banana","cherry"]
#
# for i in x:
#     for j in y:
#         print(i)
#         print(j)
#
# for x in [0, 1, 2]:
#     pass
#
#
# # while loop
#
# i = 1
# while i < 6:
#     print(i)

#     i += 1
# #
# i = 0
# while i < 10 :
#     i += 1
#     if i == 3:
#         continue
#     print(i)

# i = 0
# while i < 10 :
#     i += 1
#     if i == 3:
#         continue
#     print(i)

# i = 1
# while i < 6:
#     print(i)
#     if i == 4:
#         break
#     i = i + 1
# else:
#     print("while loop is over")

