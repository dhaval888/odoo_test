from odoo import api, fields, models, _


class SaleOrder(models.Model):
    _name = 'student'
    _rec_name = 'name'

    name = fields.Char()
    pan_no = fields.Char()
    reference = fields.Char(required=True, copy=False, readonly=True,
                            default=lambda self: _('New'))

    selection = fields.Selection(
        selection=[
            ('draft', 'Draft'),
            ('confirm', 'Confirm'),
            ('done', 'Done'),
        ], default='draft'
    )

    def action_confirm(self):
        for rec in self:
            print(rec)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('reference', _('New')) == _('New'):
                vals['reference'] = self.env['ir.sequence'].next_by_code('student') or _("New")

        return super().create(vals_list)
