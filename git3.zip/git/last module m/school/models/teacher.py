from odoo import api, fields, models


class Teacher(models.Model):
    _name = "teacher"
    _description = "Teacher"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Teacher Name', help='Teacher Name',  tracking=True)
    age = fields.Integer(string='Age', help='Teacher Age',  tracking=True)

    student_ids = fields.One2many('student', 'student_id')
