from odoo import fields, models, api, _
import logging

_logger = logging.getLogger(__name__)


class SetuCommonLogLine(models.Model):

    _name = 'setu.common.log.line'
    _description = 'Setu common log line'

    common_log_id = fields.Many2one(comodel_name='setu.common.log', string='Log Id',required=False)
    source_id = fields.Integer(string='Source')
    destination_id = fields.Integer(string='Destination')
    state = fields.Selection(string='State', selection=[('pass', 'Pass'), ('fail', 'Fail')])
    log_message = fields.Text(string="Message")
    raw_number = fields.Integer(string="Raw")
    company_id = fields.Many2one(comodel_name='res.company', string="Company",
                                 related='common_log_id.company_id', required=True)

    def create_common_log_line(self, common_log_id, raw, log_message, source_id=0, destination_id=0, state='pass'):
        """
        Author : Gaurav Vipani | Date : 11th Sep, 2023
        Purpose : Create comman log line.
        """
        vals = {
            "common_log_id": common_log_id,
            "state": state,
            'raw_number': raw,
            "log_message": log_message
        }
        if source_id:
            vals.update({"source_id": source_id})
        if destination_id:
            vals.update({"destination_id": destination_id})
        _logger.info(_("Raw :{}, Log Book : {}, Source : {}, Destination: {}, State: {}, Log Message: {} "
                       .format(raw, common_log_id, source_id, destination_id, state, log_message)))
        return self.create(vals)
