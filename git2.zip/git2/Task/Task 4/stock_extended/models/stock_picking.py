from odoo import models, api


class StockPicking(models.Model):
    _inherit = 'stock.picking'
    _description = 'Stock Picking'

    # @api.model_create_multi
    # def create(self, vals):
    #     # for rec in vals:
    #     #     sale_id = self.env['stock.picking'].search([('picking_id', '=', self.id)])
    #     self._create_invoices()
    #     res = super(StockPicking, self).create(vals)
    #     print(res)
    #     return res
    #
    # def write(self, vals):
    #     for rec in vals:
    #         sale_id = self.env['stock.picking'].search([()])
    #         res = super(StockPicking, self).write(vals)
    #         return res
    # def button_validate(self):
    #     for records in self:
    #         for moves in records.move_id_without_package:
    #             if moves.product_uom_qtu == moves.quantity_done:
    #                 self.env['stock.move.line'].search([('picking_id', '=', self._origin.id)]).writer(
    #                     {'qty_done': moves.quantity_done}
    #                 )

    # @api.onchange('move_ids_without_package')
    # def onchange_sale_id(self):
    #     for records in self:
    #         for moves in records.move_ids_without_package:
    #             if moves.product_uom_qty == moves.quantity_done:
    #                 self.env['stock.move.line'].search([('picking_id', '=', self._origin.id)]).write(
    #                     {'qty_done': moves.quantity_done})
    #                 self._origin.button_validate()
    #             if moves.product_uom_qty != moves.quantity_done:
    #                 # backorder_confirmation = self.env['stock.backorder.confirmation'].create(
    #                 #     {'pick_ids': records.ids, 'show_transfers': False})
    #
    #                 # backorder_confirmation_line = self.env['stock.backorder.confirmation.line'].create({
    #                 #     'backorder_confirmation_id': backorder_confirmation.id,
    #                 #     'picking_id': backorder_confirmation.pick_ids.id,
    #                 #     'to_backorder': True})
    #
    #                 self.env['stock.move.line'].search([('picking_id', '=', self._origin.id)]).write(
    #                     {'qty_done': moves.quantity_done})
    #
    #                 self._origin.button_validate()
    #                 # backorder_confirmation.with_context(button_validate_picking_ids=self.ids).process()
    #
    #             sale_ids = self.env['sale.order'].browse(records.sale_id.id)
    #             self.env['sale.advance.payment.inv'].create(
    #                 {'sale_order_ids': sale_ids, 'company_id': sale_ids.company_id.id,
    #                  'advance_payment_method': 'delivered'})
    #
    #             sale_ids._create_invoices()
    #             invoice_ids = sale_ids.mapped('invoice_ids') if sale_ids.invoice_ids else 0
    #             account_moves = self.env['account.move'].search([('id', 'in', invoice_ids.ids)])

    # def button_validate(self):
    #     global backorder_confirmation
    #     for records in self:
    #         for moves in records:
    # if moves.product_uom_qty == moves.quantity_done:
    #     self.env['stock.move.line'].search([('picking_id', '=', self._origin.id)]).write(
    #         {'qty_done': moves.quantity_done})
    #     self._origin.button_validate()
    # sale_ids = self.env['sale.order'].browse(records.sale_id.id)

    # if moves.product_uom_qty != moves.quantity_done:
    #     backorder_confirmation = self.env['stock.backorder.confirmation'].create(
    #         {'pick_ids': records.ids, 'show_transfers': False})
    #
    #     backorder_confirmation_line = self.env['stock.backorder.confirmation.line'].create({
    #         'backorder_confirmation_id': backorder_confirmation.id,
    #         'picking_id': backorder_confirmation.pick_ids.id,
    #         'to_backorder': True})
    #
    #     self.env['stock.move.line'].search([('picking_id', '=', self._origin.id)]).write(
    #         {'qty_done': moves.quantity_done})
    #
    # self._origin.button_validate()
    # backorder_confirmation.with_context(button_validate_picking_ids=self.ids).process()

    # sale_ids = self.env['sale.order'].browse(records.sale_id.id)
    # self.env['sale.advance.payment.inv'].create({'sale_order_ids': sale_ids, 'company_id': sale_ids.company_id.id, 'advance_payment_method': 'delivered'})
    #
    # invoice_ids = sale_ids.mapped('invoice_ids') if sale_ids.invoice_ids else 0
    # account_moves = self.env['account.move'].search([('id', 'in', invoice_ids.ids)])
    # sale_ids._create_invoice()
    #
    # backorder_confirmation = self.env['stock.backorder.confirmation.line'].create({
    #     'backorder_confirmation': backorder_confirmation.id,
    # })
    #     res = super(StockPicking, self).button_validate()
    #     return res


class Stock(models.TransientModel):
    _inherit = 'stock.backorder.confirmation'
    _description = 'Stock Backorder Confirmation'

    def process(self):
        res = super(Stock, self).process()

        pickings_to_do = self.env['stock.picking']
        pickings_not_to_do = self.env['stock.picking']
        for line in self.backorder_confirmation_line_ids:
            if line.to_backorder is True:
                pickings_to_do |= line.picking_id
            else:
                pickings_not_to_do |= line.picking_id

        sale_id = pickings_to_do.sale_id
        sale_id._create_invoices()

        return res

    def process_cancel_backorder(self):
        res = super(Stock, self).process_cancel_backorder()
        pickings_to_validate_ids = self.env.context.get('button_validate_picking_ids')
        if pickings_to_validate_ids:
            pickings_to_validate = self.env['stock.picking'].browse(pickings_to_validate_ids)
            self._check_less_quantities_than_expected(pickings_to_validate)

        sale_id = pickings_to_validate.sale_id
        sale_id._create_invoices()

        return res
# @api.onchange('move_ids_without_package')
# def onchange_sale_id(self):
#     for records in self:
#         for moves in records.move_ids_without_package:
#             if moves.product_uom_qty == moves.quantity_done:
#                 self.env['stock.move.line'].search([('picking_id', '=', self._origin.id)]).write(
#                     {'qty_done': moves.quantity_done})
#                 self._origin.button_validate()
#
#             if moves.product_uom_qty != moves.quantity_done:
#                 backorder_confirmation = self.env['stock.backorder.confirmation'].create(
#                     {'pick_ids': records.ids, 'show_transfers': False})
#
#                 backorder_confirmation_line = self.env['stock.backorder.confirmation.line'].create({
#                     'backorder_confirmation_id': backorder_confirmation.id,
#                     'picking_id': backorder_confirmation.pick_ids.id,
#                     'to_backorder': True})
#
#                 self.env['stock.move.line'].search([('picking_id', '=', self._origin.id)]).write(
#                     {'qty_done': moves.quantity_done})
#
#                 self._origin.button_validate()
#                 backorder_confirmation.with_context(button_validate_picking_ids=self.ids).process()
#
#             sale_ids = self.env['sale.order'].browse(records.sale_id.id)
#             self.env['sale.advance.payment.inv'].create(
#                 {'sale_order_ids': sale_ids, 'company_id': sale_ids.company_id.id,
#                  'advance_payment_method': 'delivered'})
#
#             sale_ids._create_invoices()
#             invoice_ids = sale_ids.mapped('invoice_ids') if sale_ids.invoice_ids else 0
#             account_moves = self.env['account.move'].search([('id', 'in', invoice_ids.ids)])

# for account_moves in account_moves:
#     if account_moves.state == 'draft':
#         account_moves.action_post()


# class Stock(models.TransientModel):
#     _inherit = 'stock.backorder.confirmation'
#     _description = 'Stock Backorder Confirmation'
#
#     def process(self):
#         res = super(Stock, self).process()
#
#         print("down")
#         return res
