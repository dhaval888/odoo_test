from odoo import models, fields, api, _
from odoo.exceptions import UserError


class execute_python_code(models.Model):
    _name = "execute.python.code"
    _description = "SCRIPT TOOL"

    name = fields.Char(string='Name', size=1024, required=True)
    code = fields.Text(string='Python Code', required=True)
    result = fields.Text(string='Result', readonly=True)

    def execute_code(self):
        localdict = {'self': self, 'user_obj': self.env.user}
        for obj in self:
            try:
                exec(obj.code, localdict)
                if localdict.get('result', False):
                    self.write({'result': localdict['result']})
                else:
                    self.write({'result': ''})
            except Exception as e:
                raise UserError('Python code is not able to run ! message : {}'.format(e))

    def create_journal_entry(self):
        from odoo.tests import Form
        import random
        journal_id = self.env['account.move'].browse(1)

        invoice_line_ids = []
        for invoice_id in journal_id.invoice_line_ids:
            invoice_line_ids.append((0, 0, {
                'name': invoice_id.name,
                'product_id': invoice_id.product_id.id,
                'account_id': invoice_id.account_id.id,
                'quantity': invoice_id.quantity,
                'price_unit': invoice_id.price_unit,
                'tax_ids': invoice_id.tax_ids.ids,
            }))

        new_invoice_id = self.env['account.move'].with_context(default_move_type='out_invoice').create({
            'name': journal_id.name + '- copy' + str(random.sample(range(1, 1000000000), 1)),
            'partner_id': journal_id.partner_id.id,
            'move_type': 'out_invoice',
            'invoice_date': journal_id.invoice_date,
            'currency_id': journal_id.currency_id.id,
            'journal_id': journal_id.journal_id.id,
            'company_id': journal_id.company_id.id,
            'invoice_payment_term_id': journal_id.invoice_payment_term_id.id,
            'invoice_user_id': journal_id.invoice_user_id.id,
            'extract_remote_id': journal_id.extract_remote_id,
            'payment_reference': journal_id.payment_reference,
            'invoice_line_ids': invoice_line_ids,
        })

        if journal_id.state == 'posted':
            new_invoice_id.with_context(skip_xsd=True).action_post()
            if journal_id.payment_state in ['in_payment', 'paid', 'partial']:
                action_data = new_invoice_id.action_register_payment()
                wizard = Form(self.env['account.payment.register'].with_context(action_data['context'])).save()
                wizard.action_create_payments()
        return journal_id, new_invoice_id
