import pandas as pd

a = {
    'name': ['rohit', 'ms', 'sachin'],
    'age': [36, 45, 34]
}
x = pd.DataFrame(a)
print(x)

a = [1, 2, 5, 6, 84, 5, 12]
b = pd.Series(a)
print(b)

a = [1, 2, 5, 6, 84, 5, 12]
b = pd.Series(a)
print(b[:3])

var = {
    "calories": [420, 380, 390],
    "duration": [50, 40, 45]
}
x = pd.DataFrame(var)

print(x)

day = {"day1": 420, "day2": 380, "day3": 390}

x = pd.Series(day)

print(x)

a = {"name ": "sachin", "age": 35, "jersey": 45}

x = pd.Series(a)
print(x)

a = {"day1": 420, "day2": 380, "day3": 390}

x = pd.Series(a, index=["day1", "day2"])

print(x)

data = {
    "Duration": {"0": 60, "1": 60, "2": 60, "3": 45},
    "Pulse": {"0": 110, "1": 117, "2": 103, "3": 109},
    "Max_pulse": {"0": 130, "1": 145, "2": 135, "3": 175},
    "Calories": {"0": 409, "1": 479, "2": 340, "3": 282}
}

df = pd.DataFrame(data)

print(df)
a = [1, 7, 2]

myvar = pd.Series(a, index=["x", "y", "z"])

print(myvar["y"])

a = {
    "player": ["rohit", "jaspreet", "pandiya"],
    "jersey": [45, 98, 33]
}
x = pd.DataFrame(a)
y = pd.DataFrame(a)
z = pd.Series
print(x)
print(y.loc[0])
print(y.loc[[0, 1]])
print(y.loc[[0, 1, 2]])