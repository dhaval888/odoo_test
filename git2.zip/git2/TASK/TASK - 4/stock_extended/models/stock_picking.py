from odoo import models, api


class StockPicking(models.TransientModel):
    _inherit = 'stock.backorder.confirmation'

    def process(self):
        res = super(StockPicking, self).process()
        sale_id = self.pick_ids.sale_id
        # sale_id = pickings_to_validate.sale_id
        sale_id._create_invoices()
        return res
