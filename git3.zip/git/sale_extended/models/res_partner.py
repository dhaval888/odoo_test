from odoo import fields,models, api
from odoo.exceptions import UserError


class ResPartner(models.Model):
    _inherit = 'res.partner'

    customer_credit_limit = fields.Integer()

    # available_credit = fields.Integer(readonly=True)

    @api.constrains('credit_limit')
    def _check_credit_limit(self):
        for records in self:
            if records.customer_credit_limit < 0:
                raise UserError("Invalid Credit Amount!!!")
