/** @odoo-module **/

import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

const { useState } = hooks;

class SwitchUserMenu extends owl.Component {
    setup() {
        super.setup();
    }

}

SwitchUserMenu.template = "setu_developer_tools.SwitchUserMenu";

export const systrayItem = {
    Component: SwitchUserMenu,
    isDisplayed: (env) => env.services.user.isSystem,
};

registry.category("systray").add("SwitchUserMenuItem", systrayItem, { sequence: 1 });