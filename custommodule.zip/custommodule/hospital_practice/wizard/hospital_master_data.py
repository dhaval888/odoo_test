from odoo import models, fields, api
from odoo.exceptions import UserError
import base64, io, csv


class HospitalMaster(models.TransientModel):
    _name = "hospital.master.data"

    csv_file = fields.Binary(string='Select File')
    file_name = fields.Char()

    def import_csv_records(self):
        data = base64.b64decode(self.csv_file)
        data_file = io.StringIO(data.decode("utf-8"))
        data_dictionary = {}
        file_reader = []
        csv_reader = csv.reader(data_file, delimiter=",")
        file_reader.extend(csv_reader)
        dict_keys = file_reader[0]
        total_length, header_length = len(file_reader), len(dict_keys)
        header_iterator, iterator = 0, 1

        while iterator < total_length:
            for values in file_reader[iterator]:
                data_dictionary[dict_keys[header_iterator]] = values
                if iterator > total_length:
                    break
                header_iterator += 1

            self.env['hospital.data'].create({
                'name': str(data_dictionary.get('Hospital_Name', '')) + "  (" + str(
                    self.env['res.country.state'].search(
                        [('name', '=', data_dictionary.get('State', ''))]).code) + ") ",
                'location': data_dictionary.get('Location', ''),
                'address_original_first_line': data_dictionary.get('Address_Original_First_Line', ''),
                'district': data_dictionary.get('District', ''),
                'state': data_dictionary.get('State', ''),
                'state_id': self.env['res.country.state'].search([('name', '=', data_dictionary.get('State'))]).id,
                'pincode': data_dictionary.get('Pincode', '').replace(" ", "") if " " in data_dictionary.get('Pincode',
                                                                                                             '') else data_dictionary.get(
                    'Pincode', ''),
                'telephone': data_dictionary.get('Telephone', '')
            })
            if header_iterator >= header_length:
                header_iterator = 0
                iterator += 1
                data_dictionary.clear()

    # file = io.BytesIO(base64.decodestring(self.excel_file_for_import))
    # reader = csv.reader(file, delimiter=',')
    # csv.field_size_limit(sys.maxsize)
    # skip_header = True
    # for row in reader:

    # def read_file(self):
    #     if self.excel_file_for_import:
    #         wb = open_workbook(file_contents=base64.decodestring(self.excel_file_for_import))
    #         for s in wb.sheets():
    #             values = []
    #             first_row = []  # Header
    #             for col in range(s.ncols):
    #                 first_row.append(s.cell_value(0, col))
    #             data = []
    #             for row in range(1, s.nrows):
    #                 elm = {}
    #                 for col in range(s.ncols):
    #                     elm[first_row[col]] = s.cell_value(row, col)
    #                 data.append(elm)
    # #                 print data
