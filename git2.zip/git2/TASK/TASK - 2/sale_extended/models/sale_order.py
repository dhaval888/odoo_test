from odoo import fields, models, api


class SaleOrder(models.Model):
    _inherit = "sale.order"

    is_user_international = fields.Boolean()

    @api.onchange('partner_id')
    def onchange_partner_id(self):
        for records in self:
            domain = [('parent_id', '=', records.partner_id.id)]
            return {'domain': {'partner_invoice_id': domain, 'partner_shipping_id': domain}}

    def _domain_user_ids(self):
        groups = self.env.ref('sales_team.group_sale_manager').id
        return [("groups_id", "=", groups)]

    user_id = fields.Many2one(comodel_name="res.users", string="Salesperson", domain=_domain_user_ids)

    # @api.onchange('partner_id')
    # def onchange_partner_id(self):
    #     for records in self:
    #         partners = self.env['res.partner'].browse(records.partner_id.id)
    #         print(f"partners = {partners.email} id= {self.id}")
