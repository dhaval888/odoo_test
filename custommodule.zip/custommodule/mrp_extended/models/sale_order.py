from odoo import api, fields, models
from importlib.resources import _
from odoo.exceptions import UserError


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'
    _description = 'Sale Order Line'

    manufacturing = fields.Float(string="Manufacturing", compute='_compute_manufacturing', )

    @api.depends('order_id')
    def _compute_manufacturing(self):
        for rec in self:
            rec.manufacturing = sum(rec.order_id.mrp_production_ids.filtered(lambda mrp_rec: mrp_rec.state == "done" and rec.product_template_id.name == mrp_rec.product_id.name).mapped('product_qty'))

            # mrp_qty = sum(rec.order_id.mrp_production_ids.filtered(lambda mrp_rec: mrp_rec.state == "done" and rec.product_template_id.name == mrp_rec.product_id.name).mapped('product_qty'))
            # print(mrp_qty)
            # rec.manufacturing = mrp_qty

    def _action_launch_stock_rule(self, previous_product_uom_qty=False):
        temp = self.order_id
        for rec in temp:
            done_qty = rec.mrp_production_ids.filtered(lambda x: x.state == "done")
            print(done_qty)

            if not rec.mrp_production_ids or len(rec.mrp_production_ids) == len(
                    rec.mrp_production_ids.filtered(
                        lambda mrp_rec: mrp_rec.state == "done")) and self.product_uom_qty > sum(
                rec.mrp_production_ids.filtered(lambda mrp_rec: mrp_rec.state == "done").mapped('product_qty')):
                res = super()._action_launch_stock_rule()
                return res

            product_qty = 0
            for rec_val in rec.mrp_production_ids:
                if rec_val.state == 'done' and self.product_id == rec_val.product_id:
                    product_qty += rec_val.product_qty

                if self.product_uom_qty < sum(rec.mrp_production_ids.filtered(
                        lambda mrp_qty: mrp_qty.state == "done" or mrp_qty.state == "to_close").mapped("product_qty")):
                    raise UserError("Invalid Quantity !!")

                # self.manufacturing = product_qty

            rec.mrp_production_ids.filtered(
                lambda mrp_rec: (
                                        mrp_rec.state == "confirmed" or mrp_rec.state == 'draft') and mrp_rec.product_id == self.product_id).write(
                {'product_qty': self.product_uom_qty - product_qty})

    #         name = fields.Char(required=True)
    #
    #         check_state = fields.Boolean(compute="_compute_check_state", store=True)

    # @api.depends('order_line.mrp_production_ids.state')

# class MrpImmediateProduction(models.TransientModel):
#     _inherit = 'mrp.immediate.production'
#
#     def process(self):
#         res = super(MrpImmediateProduction, self).process()
#         ctx = dict(self.env.context)
#         new_val = ctx['button_mark_done_production_ids']
#         print(ctx)
#         sale_id = self.env['mrp.production'].search([('id', '=', new_val)])
#         manufacturing = sale_id.product_qty
#         print(manufacturing)
#
#         order_id = self.env['sale.order'].search([('name', '=', sale_id.origin)])
#         manufacturing_product = order_id.order_line
#         for product in manufacturing_product:
#             print(product.name)
#             if product.product_template_id.name == sale_id.product_id.name:
#                 product.manufacturing += manufacturing
#
#         # order_id = self.env['sale.order'].search([('name', '=', sale_id.origin)]).filtered(lambda mrp_qty: mrp_qty.product_id.name == "done")
#         return res
#
#
# class MrpProductionBackorder(models.TransientModel):
#     _inherit = 'mrp.production.backorder'
#
#     def action_backorder(self):
#
#         res = super(MrpProductionBackorder, self).action_backorder()
#         ctx = dict(self.env.context)
#         new_val = ctx['default_mrp_production_ids']
#         print(new_val)
#
#         sale_id = self.env['mrp.production'].search([('id', '=', new_val)])
#         manufacturing = sale_id.product_qty
#
#         order_id = self.env['sale.order'].search([('name', '=', sale_id.origin)])
#         manufacturing_product = order_id.order_line
#         for product in manufacturing_product:
#             print(product.name)
#             if product.product_template_id.name == sale_id.product_id.name:
#                 product.manufacturing += manufacturing
#
#         # manufacturing_product.filtered(
#         #     lambda mrp_product: mrp_qty.state).mapped("product_qty"))
#         return res


# class MrpProduction(models.Model):
#     _inherit = 'mrp.production'
#
#     @api.model_create_multi
#     def create(self, val):
#         for rec in val:
#             new_val = rec['origin']
#
#         res = super().create(val)
#             # mrp_rec = mrp_id.
#             # print(mrp_rec)
#         mrp_id = self.env['mrp.production'].search([('origin', '=', new_val)])
#         print(mrp_id)
#         for i in mrp_id.filtered(lambda x: x.state == "done"):
#             print(i.product_qty)
#
#         return res


# class MrpProduction(models.Model):
#     _inherit = 'mrp.production'
#
#     _sql_constraints = [
#         ('name_uniq', 'unique(name, company_id)', 'Reference must be unique per Company!'),
#         ('qty_positive', 'check (product_qty < 0)', 'The quantity to produce must be positive!'),
#     ]

# elif i.state != 'done' and self.product_id == i.product_id:
#     self.product_uom_qty -= a
#     i.product_qty = self.product_uom_qty

# else:
#     if rec.mrp_production_ids.state == 'done':
#         pass
#     else:
#         rec.mrp_production_ids.product_qty = self.product_uom_qty
# print(self.product_uom_qty)
# if not self.order_id.mrp_production_ids or len(self.order_id.mrp_production_ids) == len(self.order_id.mrp_production_ids.filtered(lambda x:x.state == "done")):

# def write(self, values):
#     res = super(SaleOrder, self).write(values)
#     print(f"length === {len(self.mrp_production_ids)}, values == {values}")
#     for i in self:
#         qty = i.order_line.product_uom_qty
#         if len(i.mrp_production_ids) == 0:
#             lines = i.env['sale.order.line']
#             if 'product_uom_qty' in values:
#                 lines = i.filtered(lambda r: r.state == 'sale' and not r.is_expense)
#             if 'product_packaging_id' in values:
#                 i.move_ids.filtered(
#                     lambda m: m.state not in ['cancel', 'done']
#                 ).product_packaging_id = values['product_packaging_id']
#             previous_product_uom_qty = {line.id: line.product_uom_qty for line in lines}
#             if lines:
#                 lines._action_launch_stock_rule(previous_product_uom_qty)
#
#         # elif len(i.mrp_production_ids) == 1:
#         #     print("inside")
#         #     i.mrp_production_ids.product_qty = qty
#         else:
#             # i.mrp_production_ids.product_qty += qty
#             print('else pert')
#     return res

# def _action_launch_stock_rule(self):
#     print("hello")
#     res = super(SaleOrder, self)._action_launch_stock_rule()
#     print("hello2")
#     return
#     for rec in self.mrp_production_ids:
#         if len(self.mrp_production_ids) == 0:
#             return res
#         else:
#             print("hello")

# def _action_launch_stock_rule(self):
#     for records in self:
#         if not records.order_id.mrp_production_ids:
#             res = super(SaleOrderLine, self)._action_launch_stock_rule()
#             return res

# @api.model_create_multi
# def create(self, vals):
#
#     print(self, vals)
#
#     res = super(SaleOrder, self).create(vals)
#     print(res)
#     return res

# def write(self, vals):
#     # print(f" manufacturing ids = {self.mrp_production_ids}")
#     # print(picking_id)
#     # print(self.order_line.product_uom_qty)
#     # self.env['mrp.production'].create({'amount': rec.amount})
#     # # print(self.order_line.product_uom_qty)
#     # for rec in vals:
#     #     if len(self.mrp_production_ids) >= 1:
#     #         print("hello")
#     #         self.order_line.product_uom_qty = self.mrp_production_ids.product_qty
#
#     # a = self.order_line.product_uom_qty
#
#     res = super(SaleOrder, self).write(vals)
#     qty = self.order_line.product_uom_qty
#
#     for rec in self.mrp_production_ids:
#         if len(self.mrp_production_ids) == 1:
#             rec.product_qty = qty
#         else:
#             self._action_launch_stock_rule()
#
#     return res

# picking_id = self.env['mrp.production'].search(['picking_ids.id.mrp_production', '=', self.picking_ids.id.mrp_production.ids])
# print(picking_id)
# print(self.id)
# print(vals)
# print(self.picking_ids.id.mrp_prodcution.id)
#
# picking_id = self.env['stock.picking'].search(['sale_id', '!=', self.picking_ids.id])

# def write(self, values):
#
#     res = super(SaleOrder, self).write(values)
#     for i in self:
#         qty = i.order_line.product_uom_qty
#
#         if len(i.mrp_production_ids) == 0:

#             lines = i.env['sale.order.line']
#             if 'product_uom_qty' in values:
#                 lines = i.filtered(lambda r: r.state == 'sale' and not r.is_expense)
#
#             if 'product_packaging_id' in values:
#                 i.move_ids.filtered(
#                     lambda m: m.state not in ['cancel', 'done']
#                 ).product_packaging_id = values['product_packaging_id']
#
#             previous_product_uom_qty = {line.id: line.product_uom_qty for line in lines}
#
#             if lines:
#                 lines._action_launch_stock_rule(previous_product_uom_qty)
#
#         if len(i.mrp_production_ids) == 1:
#             print("inside")
#             i.mrp_production_ids.product_qty = qty
#         else:
#             i.mrp_production_ids.product_qty = qty
#             print('else pert')
#     return res
