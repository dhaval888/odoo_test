{
    "name": 'MRP Extended',
    "version": '16.1',
    "depends": ['mrp'],
    "data": [
        'security/ir.model.access.csv',
        'views/costing_views.xml'
    ],
}