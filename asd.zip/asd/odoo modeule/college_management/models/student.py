from odoo import api, fields, models


class Student(models.Model):
    _name = "student"
    _description = "Student"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='First Name',  copy=False)
    roll_no = fields.Char(string="Roll No", copy=False, help="Roll NO")
    division = fields.Char(string="Division", copy=False, help="Division")
    city = fields.Char(string="City", copy=False, help="City")
    attendence = fields.Boolean(string="Attendence")

    gender = fields.Selection(
        selection=[
            ('male', 'Male'),
            ('female', 'Female')
        ], string="Select Gender"
    )

    teacher_id = fields.Many2one(comodel_name='teacher', string="Teacher Name")

    # student_ids = fields.Many2Many('student', 'student_department_rel', 'student', 'department', string="Student")
