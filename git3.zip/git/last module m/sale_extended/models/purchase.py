from odoo import models, fields, api


class SaleOrder(models.Model):
    _inherit = 'purchase.order'

    sale_order_count = fields.Char()
    purchase_count = fields.Char()
    manufacturing_count = fields.Char()

    def sale_order(self):
        for rec in self:
            self.ensure_one()
            return {
                'type': 'ir.actions.act_window',
                'name': 'Sale Order',
                'view_mode': 'tree,form',
                'view_type': 'form',
                'res_model': 'sale.order',
                'domain': [('partner_id', '=', rec.partner_id.id)],
                'context': "{'create': False}"
            }

    def manufacturing(self):
        for rec in self:
            self.ensure_one()
            return {
                'type': 'ir.actions.act_window',
                'name': 'Manufacturing',
                'view_mode': 'tree,form',
                'view_type': 'form',
                'res_model': 'mrp.production',
                'domain': [('product_id', '=', rec.order_line.product_id.id)],
                'context': "{'create': False}"
            }

    def purchase(self):
        for rec in self:
            self.ensure_one()
            return {
                'type': 'ir.actions.act_window',
                'name': 'Sale Order',
                'view_mode': 'tree,form',
                'view_type': 'form',
                'res_model': 'purchase.order',
                'domain': [('partner_id', '=', rec.partner_id.id)],
                'context': "{'create': False}"
            }
