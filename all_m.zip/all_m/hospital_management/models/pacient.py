from odoo import api, fields, models


class Pacient(models.Model):
    _name = 'pacient'
    _discription = 'Pacient'
    # _rec_name='age'
    # _order = 'gender, age desc'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Pacient Name", help='pacient name', copy=False, )
    age = fields.Char(string="Pacient Age", copy=False, help='Pacient Age', )
    problem = fields.Char(string="Pacient Problem", copy=False,  help="problem",)
    wieght = fields.Float(string="Pacient Wieght", copy=True, help='Pacient Wieght')

    gender = fields.Selection(
        selection=[
            ('male', 'Male'),
            ('female', 'Female'),
        ], default='male', string='Gender', help='Pacient gender'
    )

