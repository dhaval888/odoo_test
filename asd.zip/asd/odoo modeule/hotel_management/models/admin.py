from odoo import api, fields, models


class Admin(models.Model):
    _name = 'admin'
    _descripion = 'Admin'
    _rec_name = 'room'
    # _order = 'date desc'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    new_room = fields.Boolean(string='New Room', help="New Room", copy=False)
    booking = fields.Boolean(string='Booking', help="Booking", copy=False)
    # date = fields.Datetime(string='Booking Dacustomerte', tracking=True)
    sub1 = fields.Float()
    sub2 = fields.Float()
    percentage = fields.Float(compute='_compute_percentage')

    room = fields.Selection(
        selection=[
            ('normal', 'Normal'),
            ('sweet', 'Sweet'),
            ('royal', 'Royal'),
            ('super delex', 'Super Delex'),
        ], string='Room Type', help='Room Type'
    )

    price = fields.Integer(string="Price", help='Price')

    # customer_ids = fields.One2many('customer', 'admin_id')

    customer_ids = fields.Many2many('customer', 'customer_admin_rel', 'customer', 'admin', string='Customer Name')

    @api.onchange('room')
    def onchange_room(self):
        for record in self:
            if record.room == 'normal':
                record.price = 1000
            if record.room == 'sweet':
                record.price = 1500
            if record.room == 'royal':
                record.price = 2000
            if record.room == 'super delex':
                record.price = 3000

    @api.depends('sub1', 'sub2')
    def _compute_percentage(self):
        for record in self:
            total_marks = record.sub1 + record.sub2
            percentage = total_marks / 2
            record.percentage = percentage
