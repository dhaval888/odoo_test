from importlib.resources import _

from odoo import api, fields, models


class SaleOrder(models.TransientModel):
    _inherit = 'account.payment.register'
    _description = 'Account Payment Register'

    # def action_register_payment(self):
    #     print('hello')
    #     res = super(SaleOrder, self).action_register_payment()
    #     print(res)
    #     return res

    # def action_create_payments(self):
    #     res = super(SaleOrder, self).action_create_payments()
    #
    # self.env['hospital.data'].create({
    #     'name': str(data_dictionary.get('Hospital_Name', '')) + "  (" + str(
    #         self.env['res.country.state'].search(
    #             [('name', '=', data_dictionary.get('State', ''))]).code) + ") ",
    #     'location': data_dictionary.get('Location', ''),
    #     'address_original_first_line': data_dictionary.get('Address_Original_First_Line', ''),
    #     'district': data_dictionary.get('District', ''),
    #     'state': data_dictionary.get('State', ''),
    #     'state_id': self.env['res.country.state'].search([('name', '=', data_dictionary.get('State'))]).id,
    #     'pincode': data_dictionary.get('Pincode', '').replace(" ", "") if " " in data_dictionary.get('Pincode',
    #                                                                                                  '') else data_dictionary.get(
    #         'Pincode', ''),
    #     'telephone': data_dictionary.get('Telephone', '')
    #
    #             backorder_confirmation = self.env['stock.backorder.confirmation'].create(
    #                     {'pick_ids': records.ids, 'show_transfers': False})
    #
    #                 backorder_confirmation_line = self.env['stock.backorder.confirmation.line'].create({
    #                     'backorder_confirmation_id': backorder_confirmation.id,
    #                     'picking_id': backorder_confirmation.pick_ids.id,
    #                     'to_backorder': True})
    #
    #
    #     return res
