# Write a Python program to perform  uppercase of the later part lower case of the string.
# Input : 'w3school'
#output : w3scHOOL

st= 'w3school.comas'
x = len(st) // 2
print(st[:x]+st[x:].upper())



# st = ''
# for a in range(len(x)):
#     if a >= y:
#         st += x[a].upper()
#     else:
#         st += x[a]
# print(str(st))
