from odoo import api, fields, models, _


class SaleOrder(models.Model):
    _name = 'invoice'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(required=True, copy=False, readonly=True,
                       default=lambda self: _('New'))
    invoice_date = fields.Date(default=fields.Datetime.now)
    payment_reference = fields.Char('')

    partner_id = fields.Many2one('res.partner', string="Customer")
    invoice_date_due = fields.Date()
    # invoice_payment_term_id = fields.Many2one('account.payment.term')

    currency_id = fields.Many2one('res.currency')

    invoice_line_ids = fields.One2many(comodel_name='invoice.line', inverse_name='invoice_id')

    selection = fields.Selection(
        selection=[
            ('draft', 'Draft'),
            ('post', 'Post'),
        ], default='post', tracking=True,
    )

    def action_confirm(self):
        print(self)

    def post(self):
        for rec in self:
            rec.selection = 'post'

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', _('New')) == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code('invoice') or _("New")

        return super().create(vals_list)

    def write(self, vals):
        for rec in self:
            if rec.selection != 'draft':
                rec.payment_reference = rec.name
        res = super(SaleOrder, self).create(vals)
        return res
