# This is a comment
print("Hello, python!")

print("this is single line comment")  # this is single line comment end of line

#This is multi line comment
#lumti line comment is use code uderstand
#more than one and two line use the
print("this  is multi line comment")
"""
This is multi line comment triple double  quotes
multi line comment is use code understand
more than one and two line use """
print("this  is multi line comment")

'''this is multi line comment triple single quotes
multi line comment is use code understand
more than one line and  two line use 
'''
print("this is multi line comment")