# Write a Python program to calculate the length of a string.
# Sample String : 'w3school'
# Output : 8

st = "w3school.com"
x = 0

for i in st:
    x = x + 1
print(x)

# x = 0
# print(len(st))
