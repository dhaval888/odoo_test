{
    'name': 'Sale Extended',
    'version': '16.1',
    'depends': ['sale_management', 'purchase', 'mrp', 'base', 'sale'],
    'data': [
        'views/sale_order_view.xml',
        'views/manufecture_view.xml',
        'views/purchase_view.xml',
    ],
}
