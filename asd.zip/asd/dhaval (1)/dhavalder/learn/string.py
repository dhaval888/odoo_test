# str = "       Hello, Py,thon     "
# print(str[0:3])
# print(len(str))
# print("py" in str)
# if "py" in str:
#     print("yes py is there")
# else:
#     print('no in there')
# print(str.upper())
# print(str.lower())
# print(str.replace("H","p"))
# print(str.strip(),"hello")
# print(str.split(","))

# a = "hello"
# b = "python"
# print(a +" "+ b)
#
# a = "i am rohit and my age {1} is and height is {0}"
# age = 36
# height = 172
# print(a.format(age,height))
#
# a = "he\nll\'o\' \"py\"th\\on"
# print(a)lo python hello"
# x = "Hel
st = "HeLLo, python p p"
# print(st.capitalize())
# print(st.casefold())
# print(st.center(20,"@"))
# print(st.count("py", 5, 50))
# print(st.endswith("py",0,8))
# print(st.startswith("Lo ",3,12))
# print(st.expandtabs(9))
# print(st.find("y",8,19))
# print(st.index("o",5,20))
# print(st.isalnum())
# print(st.isalpha())
# print(st.isdecimal())
# print(st.isdigit())
# print(st.isidentifier())
# print((st.isprintable()))
# print(st.isspace())
# print(st.istitle())
# print(st.title())
# print(st.isupper())
# print("".join(st))
# print(st.ljust(20),"hello",)
# print(st.rjust(20))
# print(st.partition("py"))
# print(st.rpartition("p"))
# print(st.rfind("p"))
# print(st.rindex("p"))
# a = "     hello    "
# print(a.rstrip(),"heelo")
# print(st.rsplit("py"))
# print(st.splitlines())
# print(st.swapcase())
# a="hello"
# print(a.zfill(10))


# print(x.capitalize())
# print(x.casefold())
# print(x.center(11,"@"))
# print(x.count("hello",0,11))
# print(x.encode())
# print(x.endswith(","))
# print(x.expandtabs(2))
# print(x.find("o",6,15))
# print(x.index("py"))
#
# print(x.isalnum())
# print(x.isalpha())
# print(x.isascii())
# print(x.isidentifier())
# print(x.isprintable())
# print(x.isspace())
# print(x.istitle())
# a = "#".join(x)
# b = x.ljust(15)
# print(b,"hello")
# print(x.isnumeric())
# print(a)
# x = "Hello python hello"
# print(x.partition("python"))
# print(x.rfind("py"))
# print(x.rindex("py"))
# print(x.rjust(20))
# print(x.rpartition("python"))
# print(x.splitlines())
# print(x.startswith(" "))
# print(x.swapcase())

# print(x.title())
# print(x.translate())
# c = "50"
# print(c.zfill(5))
#
# x = "123"
# print(x.isdecimal())
# print(x.isdigit())
#
# txt = "Hello Sam!"
# mytable = str.maketrans("S", "P")
# print(txt.translate(mytable))
