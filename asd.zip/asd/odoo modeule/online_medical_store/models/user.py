from odoo import api, fields, models


class User(models.Model):
    _name = 'user'
    _description = 'User'
    _rec_name = 'first_name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    first_name = fields.Char(string='First Name', help='First Name', copy=False, required=True)
    last_name = fields.Char(string='Last Name', help='Last Name', copy=False, required=True)
    email = fields.Char(string='Email', help='Email', copy=False, required=True, tracking=True)
    phone_no = fields.Char(string='Phone_no', help='Phone Number', copy=True, required=True, tracking=True)
    address = fields.Char(string='Address', help='Address', copy=True, required=True, tracking=True)
    pincode = fields.Char(string='Pincode', help='Pincode', copy=True, required=True, tracking=True)
    user_name = fields.Char(string='User Name', help='User Name', copy=True, required=True, tracking=True)
    password = fields.Char(string='Password', help='Password', copy=True, required=True, tracking=True)
