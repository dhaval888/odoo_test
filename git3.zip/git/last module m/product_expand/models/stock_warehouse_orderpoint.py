from odoo import models, fields, api
from datetime import datetime, timedelta


class SaleOrder(models.Model):
    _inherit = 'stock.warehouse.orderpoint'

    sold_thirty = fields.Integer(string="30")
    sold_sixty = fields.Integer(string="60")
    sold_ninety = fields.Integer(string="90")
    sold_one_twenty = fields.Integer(string="120")
    sold_one_fifty = fields.Integer(string="150", compute="_compute_sold_count")

    # compute="_compute_sold_count")

    # current_date = datetime.now()
    #
    # date_30_days_ago = current_date - timedelta(days=30)
    #
    # print("Current date:", current_date.strftime('%Y-%m-%d'))
    # print("Date 30 days ago:", date_30_days_ago.strftime('%Y-%m-%d'))

    # current_date = datetime.now()
    # thirty_day_ago = current_date - timedelta(days=29)
    #
    # current_date.strftime('%Y-%m-%d')
    # day_30_ago = thirty_day_ago.strftime('%Y-%m-%d')
    # print(day_30_ago)

    @api.depends('product_id')
    def _compute_sold_count(self):

        current_date = datetime.now()
        thirty_day_ago = current_date - timedelta(days=30 - 1)
        sixty_day_ago = thirty_day_ago - timedelta(days=30 - 1)
        ninety_day_ago = sixty_day_ago - timedelta(days=30 - 1)
        one_twenty_day_ago = ninety_day_ago - timedelta(days=30 - 1)
        one_fifty__day_ago = one_twenty_day_ago - timedelta(days=30 - 1)

        new_current_date = current_date.strftime('%Y-%m-%d')
        day_30_ago = thirty_day_ago.strftime('%Y-%m-%d')
        day_60_ago = sixty_day_ago.strftime('%Y-%m-%d')
        day_90_ago = ninety_day_ago.strftime('%Y-%m-%d')
        day_120_ago = one_twenty_day_ago.strftime('%Y-%m-%d')
        day_150_ago = one_fifty__day_ago.strftime('%Y-%m-%d')

        for rec in self:

            order_line_rec_ids = self.env['sale.order.line'].search([('product_id', '=', rec.product_id.id)])

            rec.sold_thirty = rec.sold_sixty = rec.sold_ninety = rec.sold_one_twenty = rec.sold_one_fifty = 0

            for order_line_rec in order_line_rec_ids:

                if rec.location_id.warehouse_id == order_line_rec.warehouse_id:
                    product_quantity = order_line_rec.product_uom_qty
                    new_order_line_date = order_line_rec.create_date.strftime('%Y-%m-%d')

                    if new_current_date >= new_order_line_date and new_order_line_date >= day_30_ago:
                        rec.sold_thirty += product_quantity

                    if day_30_ago >= new_order_line_date and new_order_line_date >= day_60_ago:
                        rec.sold_sixty += product_quantity

                    if day_60_ago >= new_order_line_date and new_order_line_date >= day_90_ago:
                        rec.sold_ninety += product_quantity

                    if day_90_ago >= new_order_line_date and new_order_line_date >= day_120_ago:
                        rec.sold_one_twenty += product_quantity

                    if day_120_ago >= new_order_line_date and new_order_line_date >= day_150_ago:
                        rec.sold_one_fifty += product_quantity

            # else:
            #     rec.sold_one_fifty = 0
            #     values_assign = rec.sold_one_fifty
            #     rec.sold_one_fifty = values_assign

        # a = 10
        # .filtered(
        #     lambda order_line: current_date == )
        # filtered(lambda mrp_rec: mrp_rec.state == "done"))

        # sale_ids = self.env['sale.order'].search([])
        # sale_id = 12314

        # for sale_rec in sale_ids:
        #     for
        # i in sale_rec.order_line:
        # if reorder_rec.product_id == i.product_id:
        #     reorder_rec.sold_thirty += i.product_uom_qty
        # else:
        #     reorder_rec.sold_thirty = 0
        # print(i.id, reorder_rec)
        #
        # print(sale_rec)
        # print(reorder_rec)

        # if reorder_rec.product_id.name == sale_rec.product_id.name:
