from odoo import api, fields, models, _


class SaleOrder(models.Model):
    _name = 'test'
    _rec_name = 'teacher_name'

    teacher_name = fields.Char(string="Name",)
    age = fields.Char(string="Age")

    product_qty = fields.Integer(string="Qty")
    price = fields.Char(string="Unit Price")
    sub_total = fields.Float(string="Sub Total")

    student_id = fields.Many2one('student')
    product_id = fields.Many2one('product.product')

    # @api.depends('sub_total')
    # def _compute_subtotal(self):
    #     for rec in self:
    #         teacher_name = 'anc'



