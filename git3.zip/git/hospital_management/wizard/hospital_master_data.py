from odoo import models, fields, api
from odoo.exceptions import UserError
import base64
import io
import csv


class HospitalMaster(models.TransientModel):
    _name = "hospital.master.data"

    excel_file_for_import = fields.Binary(string='File for upload')
    file_name = fields.Char()

    @api.constrains("excel_file_for_import")
    def check_file_type(self):
        if not self.file_name.endswith(".csv"):
            raise UserError("Please Upload a Valid File !!")

    def import_csv_records(self):
        data = base64.b64decode(self.excel_file_for_import)
        data_file = io.StringIO(data.decode("utf-8"))
        data_dictionary = {}
        file_reader = []
        csv_reader = csv.reader(data_file, delimiter=",")
        file_reader.extend(csv_reader)
        dict_keys = file_reader[0]
        total_length, header_length = len(file_reader), len(dict_keys)
        header_iterator, iterator = 0, 1

        while iterator < total_length:
            for values in file_reader[iterator]:
                data_dictionary[dict_keys[header_iterator]] = values
                if iterator > total_length:
                    break
                header_iterator += 1

            self.env['hospital.data'].create({
                'name': str(data_dictionary.get('Hospital_Name', '')) + "  (" + str(self.env['res.country.state'].search(
                    [('name', '=', data_dictionary.get('State', ''))]).code) + ") ",
                'location': data_dictionary.get('Location', ''),
                'address_original_first_line': data_dictionary.get('Address_Original_First_Line', ''),
                'district': data_dictionary.get('District', ''),
                'state_id': self.env['res.country.state'].search([('name', '=', data_dictionary.get('State'))]).id,
                'pincode': data_dictionary.get('Pincode', '').replace(" ", "") if " " in data_dictionary.get('Pincode', '') else data_dictionary.get(
                    'Pincode', ''),
                'telephone': data_dictionary.get('Telephone', '')
            })

            if header_iterator >= header_length:
                header_iterator = 0
                iterator += 1
                data_dictionary.clear()
