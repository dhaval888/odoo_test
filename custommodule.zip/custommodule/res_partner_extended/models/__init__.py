# from . import res_partner
from . import customer
# from . import product