from . import sale_order





#     def _domain_user_ids(self):
#             group_ids = []
#             category = self.env['ir.module.category'].search([('name', '=', 'Sales')])
#             groups = self.env['res.groups'].search(
#                 [('category_id', 'in', category.ids), ('name', '=', 'Administrator')])
#             for group in groups.users:
#                 print(f"id = {group.id} name= {group.name}")
#                 group_ids.append(groups.ids)
#                 return group.ids
#             print(f"group_ids = {group_ids}")
#
#     user_id = fields.Many2one(
#         comodel_name='res.users',
#         string="Salesperson",
#         domain=lambda self: "[('groups_id', '=', {}), ('share', '=', False), ('company_ids', '=', company_id)]".format(
#             self._domain_user_ids()
#         ))