from odoo import api, fields, models


class Department(models.Model):
    _name = 'department'
    _discription = 'Department'
    _rec_name = 'department_name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    department_name = fields.Char(string="Department Name", help="Department Name", copy=True, required=True, )

    # department_category = fields.Char(string="Department Category", help="Department Category", copy=True,
    #                                   required=True)

    # doctor_ids = fields.One2many('doctor', 'department_id')
    doctor_ids = fields.Many2many('doctor', 'doctor_department', 'doctor_id', 'department_id', string="Doctor")
