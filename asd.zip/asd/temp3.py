st= 'w3school.comas'
x = len(st) // 2
print(st[:x]+st[x:].upper())
