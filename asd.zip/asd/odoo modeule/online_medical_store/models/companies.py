from odoo import api, fields, models


class Companies(models.Model):
    _name = 'companies'
    _description = 'Companies'
    _rec_name = 'companies_name'
    # _order = 'companies_name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    companies_name = fields.Char(string='Companies Name', help='Companies Name', tracking=True)
    status = fields.Boolean(string='Available', help='Status Available or not', tracking=True)

    stock_ids = fields.One2many('stock', 'companies_id')
