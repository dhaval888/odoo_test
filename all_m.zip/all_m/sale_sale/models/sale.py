from odoo import api, fields, models


class SaleSale(models.Model):
    _name = 'custom.sale'

    customer_name = fields.Char()
    sale_create_date = fields.Date()

