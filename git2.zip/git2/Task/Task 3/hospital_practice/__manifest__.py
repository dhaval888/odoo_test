{
    'name': 'Hospital Practice',
    'version': '16.1',
    'depends': ['base'],
    'data': [
            'security/ir.model.access.csv',
            'wizard/hospital_master_data_views.xml',
            'views/hospital_data_views.xml',
             'views/res_country_state_views.xml'
    ]
}