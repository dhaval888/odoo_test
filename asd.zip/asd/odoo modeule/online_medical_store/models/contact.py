from odoo import api, fields, models


class Contact(models.Model):
    _name = 'contact'
    _description = 'Contact'
    _rec_name = 'email'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Contact Name', help='Contact Name')
    mobile = fields.Char(string='Contact mobile', help='Contact mobile')
    email = fields.Char(string='Contact Email', help='Contact Email', tracking=True)

    messages = fields.Char(string='Contact Messages', help='Contact Messages')

    # user_id = fields.Many2one(comodel_name='user', string='User Name')
    # medicine_id = fields.Many2one(comodel_name='Medicine', string='Medicine Name')
